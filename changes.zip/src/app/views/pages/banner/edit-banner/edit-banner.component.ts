import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';
import { CountryService } from '../../country/country.service';
import { BrandService } from '../../brand/brand.service';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';
import { AppConfig } from '../../../../core/_base/crud/utils/app-config';
import { BannerService } from '../banner.service';

@Component({
  selector: 'kt-edit-banner',
  templateUrl: './edit-banner.component.html',
  styleUrls: ['./edit-banner.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class EditBannerComponent implements OnInit {

  banner: any;
  bannerForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = true;
  cities: any[];
  brands: any[];
  offers: any[];
  bannerCategories: any[];
  filesToUpload: Array<File> = [];
  country_id: string = AppConfig.country_id;

  constructor(public dialogRef: MatDialogRef<EditBannerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService,
    private ed: EncryptionDecryptionService,
    private cs: CountryService,
    private bs: BrandService,
    private bns: BannerService,
    private cdr: ChangeDetectorRef) {
  }


  ngOnInit() {
    this.banner = this.data.data;
    this.getCitiesByCountry();
    this.getBannerCategories();
    this.initForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.createForm();
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges();
    });
  }

	/**
	 * On destroy
	 */
  ngOnDestroy() {
    // if (this.componentSubscriptions) {
    //   this.componentSubscriptions.unsubscribe();
    // }
  }
  initForm() {
    this.bannerForm = this.fb.group({
      title: ['', Validators.required],
      city_id: ['', Validators.required],
      brand_id: ['', Validators.required],
      offer_id: ['', Validators.required],
      category_id: ['', Validators.required],
      bannerImage: [null, Validators.required],

    });
  }
  createForm() {
    this.bannerForm = this.fb.group({
      title: [this.banner.title, Validators.required],
      city_id: [this.banner.city_id, Validators.required],
      brand_id: [this.banner.link.brand_id, Validators.required],
      offer_id: [this.banner.link.offer_id, Validators.required],
      category_id: [this.banner.category_id, Validators.required],
      bannerImage: [null, Validators.required],

    });
    if (this.banner._id !== undefined)
      this.getCity(this.banner.city_id);

  }
  getCitiesByCountry() {
    this.cs.getCitiesByCountry(this.ed.encryptValue(this.country_id)).subscribe((res) => {
      if (res && res['data'].length != 0) {
        this.cities = res['data'][0]['city']
      }
    });
  }
  getBannerCategories() {
    this.bns.getAllBannerCategories().subscribe((res) => {
      // console.log(res)
      if (res['data'] && res['data'].length != 0) {
        this.bannerCategories = res['data'];
        for (let i = 0; i < this.bannerCategories.length; i++) {
          this.bannerCategories[i]['_id'] = this.ed.decryptValue(this.bannerCategories[i]['_id'])
        }
      }
    });
  }
    getCity(city_id: string) {
      this.brands = []
      this.offers = []
      // this.filterCities.push(this.getFilter(this.countries, val)[0])
      this.bs!.getBrands(city_id).subscribe(res => {
        // console.log(res)
        if (res['data'] && res['data'].length !== 0) {
          this.brands = res['data'];
          for (let i = 0; i < this.brands.length; i++) {
            this.brands[i]['_id'] = this.ed.decryptValue(this.brands[i]['_id'])
          }
          if (this.banner._id !== undefined)
            this.getBrand(this.banner.link.brand_id);

        }
      },
        err => {
          console.log(err)
        })
    }
  getBrand(brand_id: string) {
    this.offers = []
    this.offers = this.getFilter(this.brands, brand_id)[0]['offer']
    // console.log(this.offers)
    if (this.banner._id !== undefined) {
      this.bannerForm.get('brand_id').setValue(this.banner.link.brand_id)
      this.bannerForm.get('offer_id').setValue(this.banner.link.offer_id)
    }

  }
  getFilter(opt: any[], val: string) {
    if (opt != undefined)
      return opt.filter(item => item._id == val);
  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  getTitle(): string {
    if (this.banner._id !== undefined) {
      return `Edit Banner '${this.banner.title}'`;
    }

    return 'New Banner';
  }
  onFileChange(event) {
    if (event.target.files.length > 0) {
      // this.filesToUpload = <Array<File>>event.target.files;
      let file = event.target.files[0];
      // console.log(this.filesToUpload);
      this.bannerForm.get('bannerImage').setValue(file);

    }


  }
  removeFile() {
    this.bannerForm.get('bannerImage').setValue(null);
  }

  isControlInvalid(controlName: string): boolean {
    const control = this.bannerForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareBanner() {
    let input = new FormData();
    // const files: Array<File> = this.filesToUpload;
    // console.log(files);

    // for (let i = 0; i < files.length; i++) {
    //   input.append("bannerImage", files[i], files[i]['name']);
    // }
    input.append('title', this.bannerForm.get('title').value);
    input.append('city_id', this.bannerForm.get('city_id').value);
    input.append('brand_id', this.bannerForm.get('brand_id').value);
    input.append('offer_id', this.bannerForm.get('offer_id').value);
    input.append('category_id', this.bannerForm.get('category_id').value);
    input.append('bannerImage', this.bannerForm.get('bannerImage').value);
    return input;
  }

	/**
	 * On Submit
	 */
  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.bannerForm.controls;
    if (this.bannerForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedBanner = this.prepareBanner();
    // console.log(editedBanner)

    if (this.banner._id !== undefined) {
      this.updateBanner(editedBanner);
    } else {
      this.createBanner(editedBanner);
    }
  }

  updateBanner(_banner) {
    this.dialogRef.close({ _banner, isEdit: true })
  }

  createBanner(_banner) {
    this.dialogRef.close({ _banner, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }


}
