// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_BANNERS_URL = `${AppConfig.API_ENDPOINT}/banner`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class BannerService {


  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createBanner(data: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_BANNERS_URL}/create`, data, { headers: httpHeaders });
  }
  getAllBanners() {
    return this.http.get(`${API_BANNERS_URL}/get`);
  }
  updateBanner(data: any, bannerId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_BANNERS_URL}/update/${bannerId}`, data, { headers: httpHeader });
  }
  deleteBanner(bannerId: string) {
    const url = `${API_BANNERS_URL}/remove/${bannerId}`;
    return this.http.delete(url);
  }
  createBannerCategory(data: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_BANNERS_URL}Category/create`, data, { headers: httpHeaders });
  }
  getAllBannerCategories() {
    return this.http.get(`${API_BANNERS_URL}Category/get`);
  }
  updateBannerCategory(data: any, bannerCategoryId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_BANNERS_URL}Category/update/${bannerCategoryId}`, data, { headers: httpHeader });
  }
  deleteBannerCategory(bannerCategoryId: string) {
    const url = `${API_BANNERS_URL}Category/remove/${bannerCategoryId}`;
    return this.http.delete(url);
  }

}
