import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../../core/_base/crud';
import { EncryptionDecryptionService } from '../../../../../core/_base/layout/services/encryption-decryption.service';
import { CountryService } from '../../../country/country.service';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'kt-edit-banner-category',
  templateUrl: './edit-banner-category.component.html',
  styleUrls: ['./edit-banner-category.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class EditBannerCategoryComponent implements OnInit {

  bannerCategory: any;
  bannerCategoryForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = true;
  countries: any[];
  filterCities: any[];

  constructor(public dialogRef: MatDialogRef<EditBannerCategoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService,
    private ed: EncryptionDecryptionService,
    private cs: CountryService,
    private cdr: ChangeDetectorRef) {
  }


  ngOnInit() {
    this.bannerCategory = this.data.data;
    this.initForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.createForm();
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges();
    });
  }

	/**
	 * On destroy
	 */
  ngOnDestroy() {
    // if (this.componentSubscriptions) {
    //   this.componentSubscriptions.unsubscribe();
    // }
  }
  initForm() {
    this.bannerCategoryForm = this.fb.group({
      name: ['', Validators.required]
    });
  }
  createForm() {
    this.bannerCategoryForm = this.fb.group({
      name: [this.bannerCategory.name, Validators.required]

    });
  }

  getTitle(): string {
    if (this.bannerCategory._id !== undefined) {
      return `Edit Banner Category '${this.bannerCategory.name}'`;
    }

    return 'New Banner Category';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.bannerCategoryForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }

  prepareBannerCategory() {
    const controls = this.bannerCategoryForm.controls;
    const _bannerCategory = {
      name: ''
    };
    // _bannerCategory._id = this.bannerCategory._id;
    _bannerCategory.name = controls['name'].value;

    return _bannerCategory;
  }
	/**
	 * On Submit
	 */
  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.bannerCategoryForm.controls;
    if (this.bannerCategoryForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedBannerCategory = this.prepareBannerCategory();
    console.log(editedBannerCategory)

    if (this.bannerCategory._id !== undefined) {
      this.updateBannerCategory(editedBannerCategory);
    } else {
      this.createBannerCategory(editedBannerCategory);
    }
  }
  updateBannerCategory(_bannerCategory) {
    this.dialogRef.close({ _bannerCategory, isEdit: true })
  }
  createBannerCategory(_bannerCategory) {
    this.dialogRef.close({ _bannerCategory, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
