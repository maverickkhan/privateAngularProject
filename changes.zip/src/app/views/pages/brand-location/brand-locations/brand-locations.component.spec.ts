import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandLocationsComponent } from './brand-locations.component';

describe('BrandLocationsComponent', () => {
  let component: BrandLocationsComponent;
  let fixture: ComponentFixture<BrandLocationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandLocationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandLocationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
