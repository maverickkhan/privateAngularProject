import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-brand-locations',
  templateUrl: './brand-locations.component.html',
  styleUrls: ['./brand-locations.component.scss']
})
export class BrandLocationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
