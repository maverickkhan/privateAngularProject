import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrandLocationComponent } from './brand-location.component';
import { BrandLocationsComponent } from './brand-locations/brand-locations.component';
import {RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: BrandLocationComponent,
    children: [
      {
        path: 'all',
        component: BrandLocationsComponent
      }
    ]
  }
];

@NgModule({
  declarations: [BrandLocationComponent, BrandLocationsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class BrandLocationModule { }
