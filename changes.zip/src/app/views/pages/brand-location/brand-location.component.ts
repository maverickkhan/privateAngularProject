import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-brand-location',
  templateUrl: './brand-location.component.html',
  styleUrls: ['./brand-location.component.scss']
})
export class BrandLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
