import { TestBed } from '@angular/core/testing';

import { BrandLocationService } from './brand-location.service';

describe('BrandLocationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BrandLocationService = TestBed.get(BrandLocationService);
    expect(service).toBeTruthy();
  });
});
