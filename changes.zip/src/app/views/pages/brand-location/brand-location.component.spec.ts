import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandLocationComponent } from './brand-location.component';

describe('BrandLocationComponent', () => {
  let component: BrandLocationComponent;
  let fixture: ComponentFixture<BrandLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrandLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
