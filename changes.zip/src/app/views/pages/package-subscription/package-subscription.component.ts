import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-package-subscription',
  templateUrl: './package-subscription.component.html',
  styleUrls: ['./package-subscription.component.scss']
})
export class PackageSubscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
