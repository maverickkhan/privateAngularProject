import { TestBed } from '@angular/core/testing';

import { PackageSubscriptionService } from './package-subscription.service';

describe('PackageSubscriptionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PackageSubscriptionService = TestBed.get(PackageSubscriptionService);
    expect(service).toBeTruthy();
  });
});
