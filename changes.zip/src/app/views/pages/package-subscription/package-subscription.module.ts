import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PackageSubscriptionComponent } from './package-subscription.component';
import { PackageSubscriptionsComponent } from './package-subscriptions/package-subscriptions.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: PackageSubscriptionComponent,
    children: [
      {
        path: 'all',
        component: PackageSubscriptionsComponent
      }
    ]
  }
];

@NgModule({
  declarations: [PackageSubscriptionComponent, PackageSubscriptionsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class PackageSubscriptionModule { }
