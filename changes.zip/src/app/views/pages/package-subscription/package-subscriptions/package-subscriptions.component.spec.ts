import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PackageSubscriptionsComponent } from './package-subscriptions.component';

describe('PackageSubscriptionsComponent', () => {
  let component: PackageSubscriptionsComponent;
  let fixture: ComponentFixture<PackageSubscriptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PackageSubscriptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PackageSubscriptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
