import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-package-subscriptions',
  templateUrl: './package-subscriptions.component.html',
  styleUrls: ['./package-subscriptions.component.scss']
})
export class PackageSubscriptionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
