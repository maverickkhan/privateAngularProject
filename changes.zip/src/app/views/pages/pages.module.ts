// Angular
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
// NgBootstrap
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// Partials
import { PartialsModule } from '../partials/partials.module';
// Pages
import { CoreModule } from '../../core/core.module';
import { MailModule } from './apps/mail/mail.module';
import { ECommerceModule } from './apps/e-commerce/e-commerce.module';
import { UserManagementModule } from './user-management/user-management.module';
import { MyPageComponent } from './my-page/my-page.component';
import { BrandModule } from './brand/brand.module';
import { BrandLocationModule } from './brand-location/brand-location.module';
import { CategoryModule } from './category/category.module';
import { CityModule } from './city/city.module';
import { CountryModule } from './country/country.module';
import { CustomerModule } from './customer/customer.module';
import { CustomerPackageRequestModule } from './customer-package-request/customer-package-request.module';
import { OfferModule } from './offer/offer.module';
import { PackageModule } from './package/package.module';
import { TrendingBrandModule } from './trending-brand/trending-brand.module';
import { ScreenModule } from './screen/screen.module';
import { PackageSubscriptionModule } from './package-subscription/package-subscription.module';
import { PromoCodeModule } from './promo-code/promo-code.module';
import { BannerModule } from './banner/banner.module';
import { AreaModule } from './area/area.module';
import { AdminModule } from './admin/admin.module';
import { ActivationCodeModule } from './activation-code/activation-code.module';
import { NotificationModule } from './notification/notification.module';
import { CollectionModule } from './collection/collection.module';
import { FeedbackModule } from './feedback/feedback.module';
import { TransactionsModule } from './transactions/transaction.module';
import { ReportModule } from './report/report.module';

@NgModule({
	declarations: [MyPageComponent],
	exports: [],
	imports: [
		CommonModule,
		HttpClientModule,
		FormsModule,
		NgbModule,
		CoreModule,
		PartialsModule,
		MailModule,
		ECommerceModule,
		UserManagementModule,
		BrandModule,
		BrandLocationModule,
		CategoryModule,
		CityModule,
		CountryModule,
		CustomerModule,
		CustomerPackageRequestModule,
		OfferModule,
		PackageModule,
		TrendingBrandModule,
		ScreenModule,
		PackageSubscriptionModule,
		PromoCodeModule,
		BannerModule,
		AreaModule,
		ReportModule,
		AdminModule,
		ActivationCodeModule,
		NotificationModule,
		CollectionModule,
		FeedbackModule,
		TransactionsModule
	],
	providers: []
})
export class PagesModule {
}
