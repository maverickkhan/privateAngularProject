import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_NOTIFICATIONS_URL = `${AppConfig.API_ENDPOINT}/notification`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})

export class NotificationService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createNotification(data: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_NOTIFICATIONS_URL}/create`, data, { headers: httpHeaders });
  }


  getAllNotifications() {
    return this.http.get(`${API_NOTIFICATIONS_URL}/get`);
  }
}
