import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';
import { PackageService } from '../../package/package.service';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';
import { CountryService } from '../../country/country.service';
import { BrandService } from '../../brand/brand.service';
import { CollectionService } from '../../collection/collection.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-edit-notification',
  templateUrl: './edit-notification.component.html',
  styleUrls: ['./edit-notification.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})

export class EditNotificationComponent implements OnInit {

  notification: any;
  notificationForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;
  countries: any[] = [];
  collections: any[] = [];
  brands: any[] = [];
  brandLocations: any[] = [];
  filterCities: any[];
  selectedState: string = "";

  constructor(public dialogRef: MatDialogRef<EditNotificationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private ps: PackageService,
    private ed: EncryptionDecryptionService,
    private cs: CountryService,
    public bs: BrandService,
    private cls: CollectionService,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.notification = this.data.notification;
    this.createForm();
    this.getAllCountries();
    this.getAllCollections();
    this.getBrands();

  }

  ngOnDestroy() {

  }

  createForm() {
    this.notificationForm = this.fb.group({
      title: [this.notification.title, Validators.required],
      message: [this.notification.message, Validators.required],
      screen_id: [this.notification.action.screen_id],
      brand_id_action: [this.notification.action.brand_id_action],
      collection_id: [this.notification.action.collection_id],
      link: [this.notification.action.link],
      // brand_id: [this.notification.brand_id, Validators.required],
      brandlocation_id: [this.notification.brandlocation_id],
      country: ['', Validators.required],
      city_id: [this.notification.city_id, Validators.required],
      // base: [this.notification.fliter.city.citytype.base, Validators.required],
      // real: [this.notification.fliter.city.citytype.real, Validators.required],
      start_date: [this.notification.fliter.city.daterangetransaction.start_date, Validators.required],
      end_date: [this.notification.fliter.city.daterangetransaction.end_date, Validators.required],
      // offer_id: [this.notification.fliter.city.offertransaction.offer_id, Validators.required],
      // minimumofferavail: [this.notification.fliter.city.offertransaction.minimumofferavail, Validators.required],
      is_reoccurring: [this.notification.is_reoccurring, Validators.required],
      crontask_start_date: [this.notification.crontask_start_date, Validators.required],
      icon: [null, Validators.required],
      image: [null, Validators.required],
    });
  }
  getAllCountries() {
    this.cs!.getAllCountries().subscribe(res => {
      this.countries = res['data'];
      // console.log(this.countries)
      for (let i = 0; i < this.countries.length; i++) {
        this.countries[i]['_id'] = this.ed.decryptValue(this.countries[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  getAllCollections() {
    this.cls!.getAllCollections().subscribe(res => {
      this.collections = res['data'];
      console.log(this.collections)
      for (let i = 0; i < this.collections.length; i++) {
        this.collections[i]['_id'] = this.ed.decryptValue(this.collections[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  getCountry(val) {
    this.filterCities = []
    this.filterCities.push(this.getFilter(this.countries, val)[0])
  }
  getBrands() {
    this.bs!.getAllBrands().subscribe(res => {
      this.brands = res['data'];
      console.log(this.brands)
      for (let i = 0; i < this.brands.length; i++) {
        this.brands[i]['_id'] = this.ed.decryptValue(this.brands[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  getLocations(brand_id) {
    console.log(brand_id)
    this.bs!.getLocationsByBrand(brand_id).subscribe(res => {
      this.brandLocations = res['data'];
      console.log(this.brandLocations)
      for (let i = 0; i < this.brandLocations.length; i++) {
        this.brandLocations[i]['_id'] = this.ed.decryptValue(this.brandLocations[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  onFileChangeIcon(event) {
    if (event.target.files.length > 0) {
      let file = event.target.files[0];
      console.log(file);
      this.notificationForm.get('icon').setValue(file);
    }
  }
  removeIconFile() {
    this.notificationForm.get('icon').setValue(null);
  }
  onFileChangeImage(event) {
    if (event.target.files.length > 0) {
      let file = event.target.files[0];
      console.log(file);
      this.notificationForm.get('image').setValue(file);

    }
  }
  removeImageFile() {
    this.notificationForm.get('image').setValue(null);
  }
  changeState(value) {
    console.log(value);
    this.selectedState = value;
    if (value == 'b') {
      this.notificationForm.get('brand_id_action').setValue('');
      this.notificationForm.get('brandlocation_id').setValue('');
    }
    else if (value == 'c')
      this.notificationForm.get('collection_id').setValue('');
    else if (value == 's')
      this.notificationForm.get('screen_id').setValue('');
    else if (value == 'l')
      this.notificationForm.get('link').setValue('');
  }
  getFilter(opt: any[], val: string) {
    // if (opt != undefined)
    return opt.filter(item => item._id == val);
  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  getTitle(): string {
    if (this.notification._id !== undefined) {
      return `Edit Notification '${this.notification.name}'`;
    }
    return 'Generate Notification';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.notificationForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareNotification() {


    let input = new FormData();
    input.append('title', this.notificationForm.get('title').value);
    input.append('message', this.notificationForm.get('message').value);
    input.append('screen_id', this.notificationForm.get('screen_id').value);
    input.append('brand_id_action', this.notificationForm.get('brand_id_action').value);
    input.append('collection_id', this.notificationForm.get('collection_id').value);
    input.append('link', this.notificationForm.get('link').value);
    // input.append('brand_id', this.notificationForm.get('brand_id').value);
    input.append('brandlocation_id', this.notificationForm.get('brandlocation_id').value);
    input.append('city_id', this.notificationForm.get('city_id').value);
    // input.append('base', this.notificationForm.get('base').value);
    // input.append('real', this.notificationForm.get('real').value);
    let sd = new Date(this.notificationForm.get('start_date').value);
    input.append('start_date', sd.getFullYear() + '-' + (sd.getMonth() + 1) + '-' + sd.getDate());
    let ed = new Date(this.notificationForm.get('end_date').value);
    input.append('end_date', ed.getFullYear() + '-' + (ed.getMonth() + 1) + '-' + ed.getDate());
    // input.append('offer_id', this.notificationForm.get('offer_id').value);
    // input.append('minimumofferavail', this.notificationForm.get('minimumofferavail').value);
    input.append('is_reoccurring', this.notificationForm.get('is_reoccurring').value);
    let csd = new Date(this.notificationForm.get('crontask_start_date').value);
    input.append('crontask_start_date', csd.getFullYear() + '-' + (csd.getMonth() + 1) + '-' + csd.getDate());
    input.append('icon', this.notificationForm.get('icon').value);
    input.append('image', this.notificationForm.get('image').value);
    return input;

  }


  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.notificationForm.controls;

    if (this.notificationForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedNotification = this.prepareNotification();
    if (this.notification._id !== undefined) {
      this.updateNotification(editedNotification);
    } else {
      this.createNotification(editedNotification);
    }
  }

  updateNotification(_notification) {
    this.dialogRef.close({ _notification, isEdit: true })
  }

  createNotification(_notification) {
    this.dialogRef.close({ _notification, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
