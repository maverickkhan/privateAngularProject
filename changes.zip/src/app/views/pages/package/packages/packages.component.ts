
import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatSnackBar, MatDialog, Sort } from '@angular/material';
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
import { EditPackageComponent } from '../edit-package/edit-package.component';
import { PackageService } from '../package.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'kt-packages',
  templateUrl: './packages.component.html',
  styleUrls: ['./packages.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PackagesComponent implements OnInit {

  displayedColumns = ['no', 'name', 'price', 'status', 'actions'];
  //dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
  // dataSource = ELEMENT_DATA;
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selection = new SelectionModel<Element>(true, []);
  packagesResult: any = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';
  private subscriptions: Subscription[] = [];

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private layoutUtilsService: LayoutUtilsService,
    private ps: PackageService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    this.Init();
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  Init() {
    this.isLoadingResults = true;
    this.ps!.getAllPackages().subscribe(res => {
      this.resultsLength = res['data'].length;
      this.packagesResult = res['data'];
      this.dataSource.data = res['data'];
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }

  ngOnDestroy() {
    this.subscriptions.forEach(el => el.unsubscribe());
  }


  deletePackage(_item) {

    const _title: string = 'Package Delete';
    const _description: string = 'Are you sure to permanently delete this Package?';
    const _waitDesciption: string = 'Package is deleting...';
    const _deleteMessage = 'Package has been deleted';

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.ps.deletePackage(_item['_id']).subscribe((res) => {
        if (res['success'] == true) {

          this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
          this.Init();
        }

        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
      });
    });
  }

  addPackage() {
    const newPackage = {
      name: '',
      price: 0,
      city_id: '',
      country_id: '',
      is_expirable: {
        is_expire: false,
        start_at: '',
        end_at: ''
      }
    };
    this.editPackage(newPackage);
  }


  editPackage(data) {
    let _saveMessage = "Package has been";
    _saveMessage += data._id !== undefined ? ' updated' : ' created';
    const _messageType = data._id !== undefined ? MessageType.Update : MessageType.Create;
    const dialogRef = this.dialog.open(EditPackageComponent, { data: { data } });
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      if (res['isEdit'] == true) {

        this.ps.updatePackage(res['_package'], data['_id']).subscribe((res) => {
          if (res['success'] == true) {
            this.layoutUtilsService.showActionNotification(_saveMessage, _messageType);
            this.Init();
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], _messageType);
        });
      }
      else {
        this.ps.createPackage(res['_package']).subscribe(res => {
          console.log(res)
          if (res['success'] == true) {
            this.layoutUtilsService.showActionNotification(_saveMessage, _messageType);
            this.Init();
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], _messageType);
        });
      }
    });
  }


  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case false:
        return 'danger';
      case true:
        return 'success';
      // case 2:
      //   return 'metal';
    }
    return '';
  }


  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Active';
      case false:
        return 'Deactivated';
      // case 2:
      //   return 'Pending';
    }
    return '';
  }

  getItemCssClassByType(status: number = 0): string {
    switch (status) {
      case 0:
        return 'accent';
      case 1:
        return 'primary';
      case 2:
        return '';
    }
    return '';
  }


  getItemTypeString(status: number = 0): string {
    switch (status) {
      case 0:
        return 'Business';
      case 1:
        return 'Individual';
    }
    return '';
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.packagesResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'name': return compare(a.name, b.name, isAsc);
        case 'price': return compare(a.price, b.price, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }


}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
