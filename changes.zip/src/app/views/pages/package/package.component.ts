import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-package',
  templateUrl: './package.component.html',
  styleUrls: ['./package.component.scss']
})
export class PackageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
