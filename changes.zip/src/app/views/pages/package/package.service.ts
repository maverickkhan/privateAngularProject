// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_PACKAGES_URL = `${AppConfig.API_ENDPOINT}/package`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class PackageService {


  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createPackage(data: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_PACKAGES_URL}/create`, data, { headers: httpHeaders });
  }
  getAllPackages() {
    return this.http.get(`${API_PACKAGES_URL}/get`);
  }

  updatePackage(data: any, packageId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_PACKAGES_URL}/update/${packageId}`, data, { headers: httpHeader });
  }

  deletePackage(packageId: string) {
    const url = `${API_PACKAGES_URL}/remove/${packageId}`;
    return this.http.delete(url);
  }

}
