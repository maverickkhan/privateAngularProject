import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';
import { CountryService } from '../../country/country.service';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'kt-edit-package',
  templateUrl: './edit-package.component.html',
  styleUrls: ['./edit-package.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class EditPackageComponent implements OnInit {

  package: any;
  packageForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = true;
  countries: any[];
  filterCities: any[];

  constructor(public dialogRef: MatDialogRef<EditPackageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService,
    private ed: EncryptionDecryptionService,
    private cs: CountryService,
    private cdr: ChangeDetectorRef) {
  }


  ngOnInit() {
    this.package = this.data.data;
    this.getAllCountries();
    this.initForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.createForm();
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges();
    });
  }

	/**
	 * On destroy
	 */
  ngOnDestroy() {
    // if (this.componentSubscriptions) {
    //   this.componentSubscriptions.unsubscribe();
    // }
  }
  initForm() {
    this.packageForm = this.fb.group({
      name: ['', Validators.required],
      price: [0, Validators.required],
      country: ['', Validators.required],
      city: ['', Validators.required],
      start_at: [''],
      end_at: [''],
      is_expire: ['']

    });
  }
  createForm() {
    this.packageForm = this.fb.group({
      name: [this.package.name, Validators.required],
      price: [this.package.price, Validators.required],
      country: [this.package.country_id, Validators.required],
      city: [this.package.city_id, Validators.required],
      start_at: [this.package.is_expirable.start_at],
      end_at: [this.package.is_expirable.end_at],
      is_expire: [this.package.is_expirable.is_expire]

    });
    if (this.package._id !== undefined)
      this.getCountry(this.package.country_id)


  }
  getAllCountries() {
    this.cs!.getAllCountries().subscribe(res => {
      this.countries = res['data'];
      // console.log(this.countries)
      for (let i = 0; i < this.countries.length; i++) {
        this.countries[i]['_id'] = this.ed.decryptValue(this.countries[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  getCountry(val) {
    this.filterCities = []
    this.filterCities.push(this.getFilter(this.countries, val)[0])
  }
  getFilter(opt: any[], val: string) {
    if (opt != undefined)
      return opt.filter(item => item._id == val);
  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  getTitle(): string {
    if (this.package._id !== undefined) {
      return `Edit Package '${this.package.name}'`;
    }

    return 'New Package';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.packageForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  preparePackage() {
    const controls = this.packageForm.controls;
    const _package = {
      name: '',
      price: 0,
      country_id: '',
      city_id: '',
      start_at: '',
      end_at: '',
      is_expire: ''

    };
    // _package._id = this.package._id;
    _package.name = controls['name'].value;
    _package.price = controls['price'].value;
    _package.country_id = controls['country'].value;
    _package.city_id = controls['city'].value;
    if (controls['start_at'].value == '')
      _package.start_at = controls['start_at'].value;
    else {
      let sd = new Date(controls['start_at'].value);
      _package.start_at = sd.getFullYear() + '-' + (sd.getMonth() + 1) + '-' + sd.getDate();
    }
    if (controls['end_at'].value == '')
      _package.end_at = controls['end_at'].value;
    else {
      let ed = new Date(controls['end_at'].value);
      _package.end_at = ed.getFullYear() + '-' + (ed.getMonth() + 1) + '-' + ed.getDate();
    }

    _package.is_expire = controls['is_expire'].value;



    return _package;
  }

	/**
	 * On Submit
	 */
  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.packageForm.controls;
    if (this.packageForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedPackage = this.preparePackage();
    console.log(editedPackage)

    if (this.package._id !== undefined) {
      this.updatePackage(editedPackage);
    } else {
      this.createPackage(editedPackage);
    }
  }

  updatePackage(_package) {
    this.dialogRef.close({ _package, isEdit: true })
  }

  createPackage(_package) {
    this.dialogRef.close({ _package, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
