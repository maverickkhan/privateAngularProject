import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_CUSTOMERS_URL = `${AppConfig.API_ENDPOINT}/customer`;
const API_BRAND_URL = `${AppConfig.API_ENDPOINT}/brand/get`

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  getAllCustomers(payload) {
    const userToken = localStorage.getItem('token');
    const httpHeaders = new HttpHeaders();
    httpHeaders.append('Authorization', 'Bearer ' + userToken);
    return this.http.get(`${API_CUSTOMERS_URL}/get?start_date=${payload.start_date}&end_date=${payload.end_date}`,{
      headers:httpHeaders
    });
  }
  getAllBrand(){
    return this.http.get(`${API_BRAND_URL}`)
  }
  offerdetail(payload){
    return this.http.get(`${AppConfig.API_ENDPOINT}/statistics/getAvailOfferBrand?start_date=${payload.start_date}&end_date=${payload.end_date}&brand_id=${payload._id}`)
  }
}
