import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatSnackBar, MatDialog, Sort } from '@angular/material';
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
import { CustomerService } from '../customer.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import moment = require('moment');
import * as XLSX from 'xlsx';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,

})

export class CustomersComponent implements OnInit {

  displayedColumns = ['no', 'first_name',  'email', 'phone', 'status'];
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = false;
  isRateLimitReached = false;
  customersResult: any = [];
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  offer_start_dates
  offer_end_dates
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private layoutUtilsService: LayoutUtilsService,
    private cs: CustomerService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    // this.Init();
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  viewAll(){
    let payload = {
      start_date : moment(this.offer_start_dates).format('YYYY-MM-DD') ,
      end_date : moment(this.offer_end_dates).format('YYYY-MM-DD') 
    }
    console.log(payload);
    
    this.isLoadingResults = true;
    debugger
    this.cs!.getAllCustomers(payload).subscribe(res => {
      this.resultsLength = res['data'].length;
      this.customersResult = res['data'];
      this.dataSource.data = res['data'];
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }
  // Init() {
  //   this.isLoadingResults = true;
  //   this.cs!.getAllCustomers().subscribe(res => {
  //     this.resultsLength = res['data'].length;
  //     this.customersResult = res['data'];
  //     this.dataSource.data = res['data'];
  //     this.isLoadingResults = false;
  //     this.isRateLimitReached = false;
  //   },
  //     err => {
  //       console.log(err)
  //       this.isLoadingResults = false;
  //       this.isRateLimitReached = true;
  //     })
  // }

  ngOnDestroy() {
  }

export(){
  let filterData = this.dataSource.data.map((x : any, ind)=>{
    return {
      "No" : (ind +1),
      "Name" : x.first_name,
      "Email" : x.email,
      "Phone" : x.phone
    }
  })
  var wscols = [
    {wch:6},
    {wch:20},
    {wch:80},
    {wch:20},
    {wch:20},
];
  const workSheet = XLSX.utils.json_to_sheet(filterData);
  workSheet['!cols'] = wscols
    const workBook: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, workSheet, 'SheetName');
    XLSX.writeFile(workBook, 'Customers-Report.xlsx');
}
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.customersResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'first_name': return compare(a.first_name, b.first_name, isAsc);
        case 'last_name': return compare(a.last_name, b.last_name, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }

  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case false:
        return 'danger';
      case true:
        return 'success';
      // case 2:
      //   return 'metal';
    }
    return '';
  }


  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Active';
      case false:
        return 'Deactivated';
      // case 2:
      //   return 'Pending';
    }
    return '';
  }

  getItemCssClassByUsage(status: boolean = false): string {
    switch (status) {
      case true:
        return 'accent';
      case false:
        return 'primary';
      // case 2:
      //   return '';
    }
    return '';
  }


  getUsageTypeString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Used';
      case false:
        return 'Available';
    }
    return '';
  }
}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}