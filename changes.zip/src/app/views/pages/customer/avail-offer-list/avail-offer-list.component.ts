import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { CustomerService } from '../customer.service';
import moment = require('moment');
import * as CryptoJS from 'crypto-js';
import { MatTableDataSource, MatPaginator, MatSort, Sort } from '@angular/material';
import * as XLSX from 'xlsx';


@Component({
  selector: 'kt-avail-offer-list',
  templateUrl: './avail-offer-list.component.html',
  styleUrls: ['./avail-offer-list.component.scss']
})
export class AvailOfferListComponent implements OnInit {
  stateCtrl = new FormControl();
  displayedColumns = ['no', 'first_name',  'email', 'phone'];
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = false;
  isRateLimitReached = false;
  customersResult: any = [];
  pageSize = 10;
 
  pageSizeOptions = [5, 10, 25, 100];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';
  filteredStates: Observable<State[]>;
  states : any = []
  offer_start_dates
  offer_end_dates
  value
  values
  statesLength 
  stateStatus : boolean = false;
  enc_key = "@big-bang123"
  constructor(private cs : CustomerService ) { 
    // this.filteredStates = this.stateCtrl.valueChanges
    //   .pipe(
    //     startWith(''),
    //     map(state => state ? this._filterStates(state.name) : this.states.slice())
    //   );
    this.cs.getAllBrand().toPromise().then((res : any)=>{
            this.states = res.data
            this.statesLength = res['data'].length;
            
    }).catch((err)=>{

    })
  }
  ngOnInit() {
    
   


    this.filteredStates = this.stateCtrl.valueChanges
    .pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.name),
      map(name => name ? this._filter(name) : this.states.slice())
    );
}

  // private _filterStates(value: string): State[] {
  //   const filterValue = value.toLowerCase();
  //   return this.states.filter(state => state.name.toLowerCase().indexOf(filterValue) === 0);
  // }
  // displayFn(user: State): string {
  //   return user && user.name ? user.name : '';
  // }
  decryptValue(ciphertext) {

    var reb64 = CryptoJS.enc.Hex.parse(ciphertext);
    var bytes = reb64.toString(CryptoJS.enc.Base64);
    var decrypt = CryptoJS.AES.decrypt(bytes, this.enc_key);
    var plaintext = decrypt.toString(CryptoJS.enc.Utf8);
    return plaintext;
    


  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.customersResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'first_name': return compare(a.first_name, b.first_name, isAsc);
        case 'last_name': return compare(a.last_name, b.last_name, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }


displayFn(user: State): string {
  return user && user.name ? user.name : '';
}

private _filter(name: string): State[] {
  const filterValue = name.toLowerCase();

  return this.states.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
    
  }
geturl(icon){
  return `https://bigbang.pk:8000/${icon}`
}

viewAll(){
  console.log(this.stateCtrl)
  let payload = {
    start_date : moment(this.offer_start_dates).format('YYYY-MM-DD') ,
    end_date : moment(this.offer_end_dates).format('YYYY-MM-DD'),
    _id : this.decryptValue(this.stateCtrl.value._id)
    

  }
  this.cs.offerdetail(payload).toPromise().then((res : any)=>{
    this.resultsLength = res['data'].length;
    this.customersResult = res['data'];
    this.dataSource.data = res['data'];
    this.isLoadingResults = false;
    this.isRateLimitReached = false;
  }).catch((err)=>{

  })
}
export(){
  let filterData = this.dataSource.data.map((x : any, ind)=>{
    return {
      "No" : (ind +1),
      "Name" : x.first_name,
      "Email" : x.email,
      "Phone" : x.phone
    }
  })
  var wscols = [
    {wch:6},
    {wch:20},
    {wch:80},
    {wch:20},
    {wch:20},
];
  const workSheet = XLSX.utils.json_to_sheet(filterData);
  workSheet['!cols'] = wscols
    const workBook: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, workSheet, 'SheetName');
    XLSX.writeFile(workBook, 'Avail-offers-Report.xlsx');
}
}
export interface State {
  _id: string;
  name: string;
  icon : string
}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}