import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailOfferListComponent } from './avail-offer-list.component';

describe('AvailOfferListComponent', () => {
  let component: AvailOfferListComponent;
  let fixture: ComponentFixture<AvailOfferListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvailOfferListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvailOfferListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
