import * as XLSX from 'xlsx'
export class MonthlyTableReport{
    static exportToExcel(tableId : string ,name?: String){
        let timeSpan = new Date().toISOString();
        let prefix = name || "MonthlyReport";
        let fileName = `${prefix}-${timeSpan}`;
        let targetTableElm = document.getElementById(tableId);
        let wb = XLSX.utils.table_to_book(targetTableElm, <XLSX.Table2SheetOpts>{ sheet: prefix });
        XLSX.writeFile(wb, `${fileName}.xlsx`);
      }
    }
