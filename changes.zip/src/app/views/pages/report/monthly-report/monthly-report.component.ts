import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import moment = require('moment');
import { ReportService } from '../report.service';
import { MatTableDataSource, MatSort, MatPaginator,Sort } from '@angular/material';
import { MonthlyTableReport } from './monthly-table-utils';
import * as XLSX from 'xlsx';

@Component({
  selector: 'kt-monthly-report',
  templateUrl: './monthly-report.component.html',
  styleUrls: ['./monthly-report.component.scss']
})
export class MonthlyReportComponent implements OnInit {
  displayedColumns = ['no', 'name', 'description', 'phone_number','created_at'];
  dataSource = new MatTableDataSource();
  isLoadingResults = false;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selectedYear 
  selectedMonth 
  brandResult : any = []
  resultsLength : any = []
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('TABLE') table :ElementRef
  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';
  constructor(private rs : ReportService) {

   }
  
  
  ngOnInit() {
    
   
    
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  getYear(value){
this.selectedYear = value 
console.log(this.selectedYear);
 }
  getMonth(value){
this.selectedMonth = value  }

view(){
  let payload ={
    year : this.selectedYear,
    month:this.selectedMonth
  }
  console.log(payload);
  

  // this.rs.getReport().subscribe(res=>{
  //   console.log(res)
  // })


  this.isLoadingResults = true;
  this.rs!.getReport(payload.year,payload.month).subscribe(res => {
    console.log(res)
    this.resultsLength = res['data'].length;
   this.brandResult = res['data']
    this.dataSource.data = res['data'];
    this.isLoadingResults = false;
    this.isRateLimitReached = false;
  },
    err => {
      console.log(err)
      this.isLoadingResults = false;
      this.isRateLimitReached = true;
    })
}
createAt(value){
  return moment(value).format('DD MMM YYYY')
}
applyFilter(filterValue: string) {
  filterValue = filterValue.trim();
  filterValue = filterValue.toLowerCase();
  this.dataSource.filter = filterValue;
}
sortData(sort: Sort) {
  const data = this.brandResult.slice();
  if (!sort.active || sort.direction == '') {
    this.dataSource.data = data;
    return;
  }
  if (sort.active == "no") {
    this.dataSource.data.reverse();
    return;
  }
  this.dataSource.data = data.sort((a, b) => {
    let isAsc = sort.direction == 'asc';
    switch (sort.active) {
      case 'name': return compare(a.name, b.name, isAsc);
      case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
      default: return 0;
    }
  });
}
export(){
  let filterdata = this.dataSource.data.map((x: any,ind)=>{
    return {
      "No": (ind+1),
      "Name" : x.name,
      "Description" : x.description,
      "Phone Number" : x.phone_number,
      "Created At" : moment(x.timestamps.created_at).format('DD MMM YYYY')      
    }
  })
  var wscols = [
    {wch:6},
    {wch:20},
    {wch:80},
    {wch:20},
    {wch:20},
];

  const workSheet = XLSX.utils.json_to_sheet(filterdata);
  workSheet['!cols'] = wscols
    const workBook: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, workSheet, 'SheetName');
    XLSX.writeFile(workBook, 'Monthly-Report.xlsx');
}


}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

