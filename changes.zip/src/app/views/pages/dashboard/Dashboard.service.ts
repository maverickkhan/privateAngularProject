import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_DASHBOARD_URL = `${AppConfig.API_ENDPOINT}/`;

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }


  getDasbboardCardStatistics() {
    return this.http.get(`${API_DASHBOARD_URL}statistics/get`);
  }

  getTransactionStatistics() {
    return this.http.get(`${API_DASHBOARD_URL}statistics/getOffersStatistics`);
  }

}
