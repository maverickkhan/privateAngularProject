import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OfferComponent } from './offer.component';
import { OffersComponent } from './offers/offers.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: OfferComponent,
    children: [
      {
        path: 'all',
        component: OffersComponent
      }
    ]
  }
];

@NgModule({
  declarations: [OfferComponent, OffersComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
  ]
})
export class OfferModule { }
