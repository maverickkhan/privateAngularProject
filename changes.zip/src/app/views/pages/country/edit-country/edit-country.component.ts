import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-edit-country',
  templateUrl: './edit-country.component.html',
  styleUrls: ['./edit-country.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})

export class EditCountryComponent implements OnInit {
  country: any;
  countryForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;

  constructor(public dialogRef: MatDialogRef<EditCountryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.country = this.data.country;
    this.createForm();
  }


  ngOnDestroy() {

  }



  createForm() {
    this.countryForm = this.fb.group({
      name: [this.country.name, Validators.required],
    });
  }

  getTitle(): string {
    if (this.country._id !== undefined) {
      return `Edit Country '${this.country.name}'`;
    }

    return 'New Country';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.countryForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareCountry() {
    const controls = this.countryForm.controls;
    const _country = {
      name: '',
    };
    // _country._id = this.country._id;
    _country.name = controls['name'].value;
    // if (this.country._id !== undefined)
    //   input.append('_id', this.country._id);

    return _country;
  }


  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.countryForm.controls;

    if (this.countryForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedCountry = this.prepareCountry();
    if (this.country._id !== undefined) {
      this.updateCountry(editedCountry);
    } else {
      this.createCountry(editedCountry);
    }
  }

  updateCountry(_country) {
    this.dialogRef.close({ _country, isEdit: true })
  }

  createCountry(_country) {
    this.dialogRef.close({ _country, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
