import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})
export class CountryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
