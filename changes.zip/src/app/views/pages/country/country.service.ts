// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_COUNTRIES_URL = `${AppConfig.API_ENDPOINT}/country`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class CountryService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createCountry(country: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_COUNTRIES_URL}/create`, country, { headers: httpHeaders });
  }

  getAllCountries() {
    return this.http.get(`${API_COUNTRIES_URL}/get`);
  }

  getCountryById(countryId) {
    return this.http.get(API_COUNTRIES_URL + `/${countryId}`);
  }

  updateCountry(country: any, countryId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_COUNTRIES_URL}/update/${countryId}`, country, { headers: httpHeader });
  }


  deleteCountry(countryId: string) {
    const url = `${API_COUNTRIES_URL}/remove/${countryId}`;
    return this.http.delete(url);
  }
  getCitiesByCountry(country, search = "") {
    return this.http.get(`${AppConfig.API_ENDPOINT}/city/get?id=${country}&search=${search}`);
  }
}
