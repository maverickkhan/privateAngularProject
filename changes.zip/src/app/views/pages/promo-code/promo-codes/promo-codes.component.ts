
import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatSnackBar, MatDialog, Sort } from '@angular/material';
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
import { EditPromoCodeComponent } from '../edit-promo-code/edit-promo-code.component';
import { PromoCodeService } from '../promo-code.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'kt-promo-codes',
  templateUrl: './promo-codes.component.html',
  styleUrls: ['./promo-codes.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PromoCodesComponent implements OnInit {

  displayedColumns = ['no', 'code', 'validity', 'status', 'actions'];
  //dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
  // dataSource = ELEMENT_DATA;
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selection = new SelectionModel<Element>(true, []);
  promoCodesResult: any = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';
  private subscriptions: Subscription[] = [];

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private layoutUtilsService: LayoutUtilsService,
    private ps: PromoCodeService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    this.Init();
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  Init() {
    this.isLoadingResults = true;
    this.ps!.getAllPromoCodes().subscribe(res => {
      this.resultsLength = res['data'].length;
      this.promoCodesResult = res['data'];
      this.dataSource.data = res['data'];
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }

  ngOnDestroy() {
    this.subscriptions.forEach(el => el.unsubscribe());
  }


  deletePromoCode(_item) {

    const _title: string = 'Promo Code Delete';
    const _description: string = 'Are you sure to permanently delete this Promo Code?';
    const _waitDesciption: string = 'Promo Code is deleting...';
    const _deleteMessage = 'Promo Code has been deleted';

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.ps.deletePromoCode(_item['_id']).subscribe((res) => {
        if (res['success'] == true) {

          this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
          this.Init();
        }

        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
      });
    });
  }

  addPromoCode() {
    const newPromoCode = {
      code: '',
      validity: '',
      package_id: '',
      reg_active: false,
      start_date: '',
      end_date: ''
    };
    this.editPromoCode(newPromoCode);
  }


  editPromoCode(data) {
    let _saveMessage = "Promo Code has been";
    _saveMessage += data._id !== undefined ? ' updated' : ' created';
    const _messageType = data._id !== undefined ? MessageType.Update : MessageType.Create;
    const dialogRef = this.dialog.open(EditPromoCodeComponent, { data: { data } });
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      if (res['isEdit'] == true) {

        // this.ps.updatePromoCode(res['_promoCode'], data['_id']).subscribe((res) => {
        //   if (res['success'] == true) {
        //     this.layoutUtilsService.showActionNotification(_saveMessage, _messageType);
        //     this.Init();
        //   }
        //   else
        //     this.layoutUtilsService.showActionNotification(res['message'], _messageType);
        // });
      }
      else {
        this.ps.createPromoCode(res['_promoCode']).subscribe(res => {
          console.log(res)
          if (res['success'] == true) {
            this.layoutUtilsService.showActionNotification(_saveMessage, _messageType);
            this.Init();
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], _messageType);
        });
      }
    });
  }


  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case false:
        return 'danger';
      case true:
        return 'success';
      // case 2:
      //   return 'metal';
    }
    return '';
  }


  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Active';
      case false:
        return 'Deactivated';
      // case 2:
      //   return 'Pending';
    }
    return '';
  }

  getItemCssClassByType(status: number = 0): string {
    switch (status) {
      case 0:
        return 'accent';
      case 1:
        return 'primary';
      case 2:
        return '';
    }
    return '';
  }


  getItemTypeString(status: number = 0): string {
    switch (status) {
      case 0:
        return 'Business';
      case 1:
        return 'Individual';
    }
    return '';
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.promoCodesResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'code': return compare(a.code, b.code, isAsc);
        case 'validity': return compare(a.validity, b.validity, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }

}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
