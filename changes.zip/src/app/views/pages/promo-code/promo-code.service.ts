// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_PROMO_CODES_URL = `${AppConfig.API_ENDPOINT}/promocode`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class PromoCodeService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createPromoCode(data: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_PROMO_CODES_URL}/create`, data, { headers: httpHeaders });
  }
  getAllPromoCodes() {
    return this.http.get(`${API_PROMO_CODES_URL}/get`);
  }
  // updatePromoCode(data: any, promoCodeId) {
  //   const httpHeader = this.httpUtils.getHTTPHeaders();
  //   return this.http.put(`${API_PROMO_CODES_URL}/update/${promoCodeId}`, data, { headers: httpHeader });
  // }
  deletePromoCode(promoCodeId: string) {
    const url = `${API_PROMO_CODES_URL}/remove/${promoCodeId}`;
    return this.http.delete(url);
  }

}
