import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-promo-code',
  templateUrl: './promo-code.component.html',
  styleUrls: ['./promo-code.component.scss']
})
export class PromoCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
