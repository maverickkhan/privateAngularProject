import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';
import { PackageService } from '../../package/package.service';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'kt-edit-promo-code',
  templateUrl: './edit-promo-code.component.html',
  styleUrls: ['./edit-promo-code.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})

export class EditPromoCodeComponent implements OnInit {

  promoCode: any;
  promoCodeForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = true;
  packages: any[];

  constructor(public dialogRef: MatDialogRef<EditPromoCodeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService,
    private ed: EncryptionDecryptionService,
    private ps: PackageService,
    private cdr: ChangeDetectorRef) {
  }


  ngOnInit() {
    this.promoCode = this.data.data;
    this.getAllPackages();
    this.initForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.createForm();
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges();
    });
  }

	/**
	 * On destroy
	 */
  ngOnDestroy() {
    // if (this.componentSubscriptions) {
    //   this.componentSubscriptions.unsubscribe();
    // }
  }
  initForm() {
    this.promoCodeForm = this.fb.group({
      code: ['', Validators.required],
      validity: ['', Validators.required],
      package_id: ['', Validators.required],
      reg_active: [false, Validators.required],
      start_date: ['', Validators.required],
      end_date: ['', Validators.required]

    });
  }
  createForm() {
    this.promoCodeForm = this.fb.group({
      code: [this.promoCode.code, Validators.required],
      validity: [this.promoCode.validity, Validators.required],
      package_id: [this.promoCode.package_id, Validators.required],
      reg_active: [this.promoCode.reg_active, Validators.required],
      start_date: [this.promoCode.start_date, Validators.required],
      end_date: [this.promoCode.end_date, Validators.required]

    });


  }
  getAllPackages() {
    this.ps!.getAllPackages().subscribe(res => {
      this.packages = res['data'];
      // console.log(this.packages)
      for (let i = 0; i < this.packages.length; i++) {
        this.packages[i]['_id'] = this.ed.decryptValue(this.packages[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }

  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  getTitle(): string {
    if (this.promoCode._id !== undefined) {
      return `Edit Promo Code '${this.promoCode.name}'`;
    }

    return 'New Promo Code';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.promoCodeForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  preparePromoCode() {
    const controls = this.promoCodeForm.controls;
    const _promoCode = {
      code: '',
      validity: '',
      package_id: '',
      reg_active: false,
      start_date: '',
      end_date: ''

    };
    // _promoCode._id = this.promoCode._id;
    _promoCode.code = controls['code'].value;
    _promoCode.validity = controls['validity'].value;
    _promoCode.package_id = controls['package_id'].value;

    if (controls['start_date'].value == '')
      _promoCode.start_date = controls['start_date'].value;
    else {
      let sd = new Date(controls['start_date'].value);
      _promoCode.start_date = sd.getFullYear() + '-' + (sd.getMonth() + 1) + '-' + sd.getDate();
    }
    if (controls['end_date'].value == '')
      _promoCode.end_date = controls['end_date'].value;
    else {
      let ed = new Date(controls['end_date'].value);
      _promoCode.end_date = ed.getFullYear() + '-' + (ed.getMonth() + 1) + '-' + ed.getDate();
    }

    _promoCode.reg_active = controls['reg_active'].value;



    return _promoCode;
  }

	/**
	 * On Submit
	 */
  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.promoCodeForm.controls;
    if (this.promoCodeForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedPromoCode = this.preparePromoCode();
    console.log(editedPromoCode)

    if (this.promoCode._id !== undefined) {
      this.updatePromoCode(editedPromoCode);
    } else {
      this.createPromoCode(editedPromoCode);
    }
  }

  updatePromoCode(_promoCode) {
    this.dialogRef.close({ _promoCode, isEdit: true })
  }

  createPromoCode(_promoCode) {
    this.dialogRef.close({ _promoCode, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }


}
