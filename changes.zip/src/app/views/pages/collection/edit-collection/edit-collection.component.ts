
import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-edit-collection',
  templateUrl: './edit-collection.component.html',
  styleUrls: ['./edit-collection.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})

export class EditCollectionComponent implements OnInit {

  collection: any;
  collectionForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;
  filesToUpload: Array<File> = [];


  constructor(public dialogRef: MatDialogRef<EditCollectionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.collection = this.data.collection;
    this.createForm();
  }

  ngOnDestroy() {

  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      this.filesToUpload = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUpload);
      this.collectionForm.get('banner').setValue(this.filesToUpload);

    }


  }
  removeFile() {
    this.collectionForm.get('banner').setValue(null);
  }
  createForm() {
    this.collectionForm = this.fb.group({
      name: [this.collection.name, Validators.required],
      banner: [null, Validators.required],

    });
  }

  getTitle(): string {
    if (this.collection._id !== undefined) {
      return `Edit Collection '${this.collection.name}'`;
    }

    return 'New Collection';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.collectionForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareCollection() {
    // const controls = this.collectionForm.controls;
    // const _collection = {
    //   _id: '',
    //   name: '',
    //   bgcolor: '',
    //   banner: ''

    // };
    // _collection._id = this.collection._id;
    // _collection.name = controls['name'].value;
    // _collection.bgcolor = controls['bgcolor'].value;
    // _collection.banner = controls['banner'].value;
    let input = new FormData();
    const files: Array<File> = this.filesToUpload;
    console.log(files);

    for (let i = 0; i < files.length; i++) {
      input.append("banner", files[i], files[i]['name']);
    }
    // if (this.collection._id !== undefined)
    //   input.append('_id', this.collection._id);

    input.append('name', this.collectionForm.get('name').value);
    // input.append('banner', this.collectionForm.get('banner').value);
    return input;

    // return _collection;
  }


  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.collectionForm.controls;

    if (this.collectionForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedCollection = this.prepareCollection();
    if (this.collection._id !== undefined) {
      this.updateCollection(editedCollection);
    } else {
      this.createCollection(editedCollection);
    }
  }

  updateCollection(_collection) {
    this.dialogRef.close({ _collection, isEdit: true })
  }

  createCollection(_collection) {
    this.dialogRef.close({ _collection, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
