// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_COLLECTIONS_URL = `${AppConfig.API_ENDPOINT}/collections`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class CollectionService {


  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createCollection(collection: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_COLLECTIONS_URL}/create`, collection, { headers: httpHeaders });
  }

  getAllCollections() {
    return this.http.get(`${API_COLLECTIONS_URL}/get`);
  }

  updateCollection(collection: any, collectionId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_COLLECTIONS_URL}/update/${collectionId}`, collection, { headers: httpHeader });
  }

  deleteCollection(collectionId: string) {
    const url = `${API_COLLECTIONS_URL}/remove/${collectionId}`;
    return this.http.delete(url);
  }
  addBrandToCollection(brands: any, collectionId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_COLLECTIONS_URL}/addBrandsToCollection/${collectionId}`, brands, { headers: httpHeader });
  }

}
