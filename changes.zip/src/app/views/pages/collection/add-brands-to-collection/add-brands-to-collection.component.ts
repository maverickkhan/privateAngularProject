import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';
import { MatChipInputEvent } from '@angular/material';
import { ENTER, COMMA } from '@angular/cdk/keycodes';
import { BrandService } from '../../brand/brand.service';
import { CountryService } from '../../country/country.service';
import { AppConfig } from '../../../../core/_base/crud/utils/app-config';

@Component({
  selector: 'kt-add-brands-to-collection',
  templateUrl: './add-brands-to-collection.component.html',
  styleUrls: ['./add-brands-to-collection.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class AddBrandsToCollectionComponent implements OnInit {

  brands: any;
  brandsForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = true;
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = true;
  separatorKeysCodes = [ENTER, COMMA];
  cities: any[];
  brandsArray: any[];
  country_id: string = AppConfig.country_id;

  constructor(public dialogRef: MatDialogRef<AddBrandsToCollectionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService,
    private ed: EncryptionDecryptionService,
    private cs: CountryService,
    private bs: BrandService,
    private cdr: ChangeDetectorRef) {
  }


  ngOnInit() {
    this.getCitiesByCountry();
    this.brands = this.data.brands;
    console.log(this.brands);
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges();
    });
  }
  getCitiesByCountry() {
    this.cs.getCitiesByCountry(this.ed.encryptValue(this.country_id)).subscribe((res) => {
      if (res && res['data'].length != 0) {
        this.cities = res['data'][0]['city']
      }
    });
  }
  getCity(city_id: string) {
    this.bs!.getBrands(city_id).subscribe(res => {
      // console.log(res)
      if (res['data'] && res['data'].length !== 0) {
        this.brandsArray = res['data'];
        // for (let i = 0; i < this.brands.length; i++) {
        //   this.brands[i]['_id'] = this.ed.decryptValue(this.brands[i]['_id'])
        // }

      }
    },
      err => {
        console.log(err)
      })
  }
	/**
	 * On destroy
	 */
  ngOnDestroy() {

  }


  getTitle(): string {
    return 'Add Brands To Collection';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.brandsForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareBrands() {
    return this.brands;
  }

	/**
	 * On Submit
	 */
  onSubmit() {
    // this.hasFormErrors = false;
    // const controls = this.brandsForm.controls;
    // if (this.brandsForm.invalid) {
    //   Object.keys(controls).forEach(controlName =>
    //     controls[controlName].markAsTouched()
    //   );

    //   this.hasFormErrors = true;
    //   return;
    // }

    const editedBrands = this.prepareBrands();
    console.log(editedBrands)
    this.createBrands(editedBrands);

  }
  createBrands(_brands) {
    this.dialogRef.close({ _brands, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }
  addBrand() {
    this.brands.push({
      "description": "",
      "brand_id": "",
      "name": "",
      "icon": "",
      "specialties": []
    })
  }
  deleteBrand(index: number) {
    this.brands.splice(index, 1);
  }

  addTag(event: MatChipInputEvent, brand: number): void {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.brands[brand].specialties.push(
        {
          speciality_name: value.trim()
        });
    }
    if (input) {
      input.value = '';
    }
  }

  removeTag(brand: number, tag: number): void {
    this.brands[brand].specialties.splice(tag, 1);
  }
}
