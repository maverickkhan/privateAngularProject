import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_FEEDBACKS_URL = `${AppConfig.API_ENDPOINT}/feedback`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})

export class FeedbackService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  getAllFeedbacks() {
    return this.http.get(`${API_FEEDBACKS_URL}/get`);
  }
}
