import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatSnackBar, MatDialog, Sort } from '@angular/material';
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
import { FeedbackService } from '../feedback.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-feedbacks',
  templateUrl: './feedbacks.component.html',
  styleUrls: ['./feedbacks.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,

})

export class FeedbacksComponent implements OnInit {


  displayedColumns = ['no', 'customer_name', "customer_email", 'customer_phone', 'type', 'feedback', 'status'];
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  feedbacksResult: any = [];
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private layoutUtilsService: LayoutUtilsService,
    private fs: FeedbackService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    this.Init();
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  Init() {
    this.isLoadingResults = true;
    this.fs!.getAllFeedbacks().subscribe(res => {
      this.resultsLength = res['data'].length;
      this.feedbacksResult = res['data'];
      this.dataSource.data = res['data'];
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }

  ngOnDestroy() {
  }


  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.feedbacksResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'customer_name': return compare(a.customer_name, b.customer_name, isAsc);
        case 'type': return compare(a.type, b.type, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }

  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case false:
        return 'danger';
      case true:
        return 'success';
      // case 2:
      //   return 'metal';
    }
    return '';
  }


  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Active';
      case false:
        return 'Deactivated';
      // case 2:
      //   return 'Pending';
    }
    return '';
  }

  getItemCssClassByUsage(status: boolean = false): string {
    switch (status) {
      case true:
        return 'accent';
      case false:
        return 'primary';
      // case 2:
      //   return '';
    }
    return '';
  }


  getUsageTypeString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Used';
      case false:
        return 'Available';
    }
    return '';
  }


}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}