import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-admins',
  templateUrl: './admins.component.html',
  styleUrls: ['./admins.component.scss']
})
export class AdminsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
