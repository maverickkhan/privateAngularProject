// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_CITIES_URL = `${AppConfig.API_ENDPOINT}/city`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class CityService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createCity(city: any, countryId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_CITIES_URL}/create/${countryId}`, city, { headers: httpHeaders });
  }

  getAllCities(countryId: string = '', search: string = '') {
    return this.http.get(`${API_CITIES_URL}/get?search=${search}&id=${countryId}`);
  }
  getCityById(cityId) {
    return this.http.get(API_CITIES_URL + `/${cityId}`);
  }


  updateCity(city: any, cityId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_CITIES_URL}/update/${cityId}`, city, { headers: httpHeader });
  }



  deleteCity(city: any, countryId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    const options = {
      headers: httpHeaders,
      body: {
        city_id: city['_id']
      },
    };
    const url = `${API_CITIES_URL}/remove/${countryId}`;
    return this.http.delete(url, options);
  }

}
