import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatSnackBar, MatDialog, Sort } from '@angular/material';
import { debounceTime, distinctUntilChanged, tap, skip, delay, take } from 'rxjs/operators';
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
import { EditCityComponent } from '../edit-city/edit-city.component';
import { CityService } from '../city.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'kt-cities',
  templateUrl: './cities.component.html',
  styleUrls: ['./cities.component.scss']
})

export class CitiesComponent implements OnInit {

  displayedColumns = ['no', 'city_name', 'status', 'actions'];
  //dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
  // dataSource = ELEMENT_DATA;
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  dataSource = new MatTableDataSource();
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selection = new SelectionModel<any>(true, []);
  citiesResult: any = [];
  countryId: string = '';
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('searchInput') searchInput: ElementRef;
  filterStatus: string = '';
  filterType: string = '';
  private subscriptions: Subscription[] = [];

  constructor(
    public dialog: MatDialog,
    public snackBar: MatSnackBar,
    private layoutUtilsService: LayoutUtilsService,
    private cs: CityService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.countryId = id;
        console.log(id)
        this.Init(this.countryId);

      } else {

      }
    });

  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  Init(countryId: string) {
    this.isLoadingResults = true;
    this.dataSource.data = [];
    this.resultsLength = 0;
    this.citiesResult = [];
    this.cs!.getAllCities(countryId).subscribe(res => {
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
      if (res['data'] && res['data'].length != 0) {
        this.resultsLength = res['data'][0]['city'].length;
        this.citiesResult = res['data'][0]['city'];
        this.dataSource.data = res['data'][0]['city'];
      }
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }

  ngOnDestroy() {
    this.subscriptions.forEach(el => el.unsubscribe());
  }





  deleteCity(_item) {

    const _title: string = 'City Delete';
    const _description: string = 'Are you sure to permanently delete this city?';
    const _waitDesciption: string = ' City is deleting...';
    const _deleteMessage = 'City has been deleted';

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.cs.deleteCity(_item, this.countryId).subscribe((res) => {
        if (res['success'] == true) {

          this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
          this.Init(this.countryId);
        }

        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
      });
    });
  }

  addCity() {
    const newCity = {
      city_name: '',
    };
    this.editCity(newCity);
  }


  editCity(city) {
    let _saveMessage = "City has been";
    _saveMessage += city._id !== undefined ? ' updated' : ' created';
    const _messageType = city._id !== undefined ? MessageType.Update : MessageType.Create;
    const dialogRef = this.dialog.open(EditCityComponent, { data: { city } });
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      if (res['isEdit'] == true) {

        this.cs.updateCity(res['_city'], this.countryId).subscribe((res) => {
          if (res['success'] == true) {
            this.layoutUtilsService.showActionNotification(_saveMessage, _messageType);
            this.Init(this.countryId);
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], _messageType);
        });
      }
      else {
        this.cs.createCity(res['_city'], this.countryId).subscribe(res => {
          console.log(res)
          if (res['success'] == true) {
            this.layoutUtilsService.showActionNotification(_saveMessage, _messageType);
            this.Init(this.countryId);
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], _messageType);
        });
      }
    });
  }



  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case false:
        return 'danger';
      case true:
        return 'success';
      // case 2:
      //   return 'metal';
    }
    return '';
  }


  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Active';
      case false:
        return 'Deactivated';
      // case 2:
      //   return 'Pending';
    }
    return '';
  }

  getItemCssClassByType(status: number = 0): string {
    switch (status) {
      case 0:
        return 'accent';
      case 1:
        return 'primary';
      case 2:
        return '';
    }
    return '';
  }


  getItemTypeString(status: number = 0): string {
    switch (status) {
      case 0:
        return 'Business';
      case 1:
        return 'Individual';
    }
    return '';
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.citiesResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'city_name': return compare(a.city_name, b.city_name, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }
  goToAreas(_city) {
    this.router.navigate([`demo1/area/${this.countryId}/${_city['_id']}`]);
  }

}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
