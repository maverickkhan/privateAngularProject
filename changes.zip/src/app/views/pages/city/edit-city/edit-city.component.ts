import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';

@Component({
  selector: 'kt-edit-city',
  templateUrl: './edit-city.component.html',
  styleUrls: ['./edit-city.component.scss']
})
export class EditCityComponent implements OnInit {

  city: any;
  cityForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;
  filesToUpload: Array<File> = [];


  constructor(public dialogRef: MatDialogRef<EditCityComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.city = this.data.city;
    this.createForm();
  }


  ngOnDestroy() {
 
  }


  createForm() {
    this.cityForm = this.fb.group({
      city_name: [this.city.city_name, Validators.required],
    });
  }

  getTitle(): string {
    if (this.city._id !== undefined) {
      return `Edit city '${this.city.city_name}'`;
    }

    return 'New city';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.cityForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareCity() {
    const controls = this.cityForm.controls;
    const _city = {
      city_name: '',

    };
    if (this.city._id !== undefined)
      _city['city_id'] = this.city._id;
    _city.city_name = controls['city_name'].value;
    // _city.bgcolor = controls['bgcolor'].value;
    // _city.icon = controls['icon'].value;

    return _city;
  }

	/**
	 * On Submit
	 */
  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.cityForm.controls;

    if (this.cityForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedCity = this.prepareCity();
    if (this.city._id !== undefined) {
      this.updateCity(editedCity);
    } else {
      this.createCity(editedCity);
    }
  }

  updateCity(_city) {
    this.dialogRef.close({ _city, isEdit: true })
  }

  createCity(_city) {
    this.dialogRef.close({ _city, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
