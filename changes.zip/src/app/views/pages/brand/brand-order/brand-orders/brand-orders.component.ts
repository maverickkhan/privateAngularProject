
import { Component, OnInit, ElementRef, ViewChild, Input, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, Sort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { debounceTime, distinctUntilChanged, tap, delay } from 'rxjs/operators';
import { QueryParamsModel, LayoutUtilsService, MessageType } from '../../../../../core/_base/crud';
import { BrandService } from '../../brand.service';
import { EncryptionDecryptionService } from '../../../../../core/_base/layout/services/encryption-decryption.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-brand-orders',
  templateUrl: './brand-orders.component.html',
  styleUrls: ['./brand-orders.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class BrandOrdersComponent implements OnInit {


  @Input() brandId: string;
  dataSource = new MatTableDataSource();
  displayedColumns = ['no', 'order_number', 'customer_name', 'order_status', 'grand_total'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('searchInput') searchInput: ElementRef;
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selection = new SelectionModel<any>(true, []);
  brandOrdersResult: any[] = [];

  private componentSubscriptions: Subscription;


  constructor(
    public dialog: MatDialog,
    public bs: BrandService,
    private layoutUtilsService: LayoutUtilsService,
    private ed: EncryptionDecryptionService, ) { }


  ngOnInit() {

    this.Init(this.brandId);


  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy() {
    if (this.componentSubscriptions) {
      this.componentSubscriptions.unsubscribe();
    }
  }

  Init(brandId: string) {

    this.isLoadingResults = true;
    this.bs!.getOrdersByBrand(this.ed.decryptValue(brandId)).subscribe(res => {
      this.resultsLength = res['data'].length;
      this.brandOrdersResult = res['data'];
      this.dataSource.data = res['data'];
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.brandOrdersResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'order_number': return compare(a.order_number, b.order_number, isAsc);
        case 'customer_name': return compare(a.customer_name, b.customer_name, isAsc);
        case 'order_status': return compare(a.order_status, b.order_status, isAsc);
        case 'grand_total': return compare(a.grand_total, b.grand_total, isAsc);
        default: return 0;
      }
    });
  }

}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}