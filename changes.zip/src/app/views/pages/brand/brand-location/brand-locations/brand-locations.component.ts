import { Component, OnInit, ElementRef, ViewChild, Input, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, Sort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { debounceTime, distinctUntilChanged, tap, delay } from 'rxjs/operators';
import { QueryParamsModel, LayoutUtilsService, MessageType } from '../../../../../core/_base/crud';
import { EditBrandLocationComponent } from '../edit-brand-location/edit-brand-location.component';
import { BrandService } from '../../brand.service';
import { EncryptionDecryptionService } from '../../../../../core/_base/layout/services/encryption-decryption.service';
import { AppConfig } from '../../../../../core/_base/crud/utils/app-config';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-brand-locations',
  templateUrl: './brand-locations.component.html',
  styleUrls: ['./brand-locations.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class BrandLocationsComponent implements OnInit {

  @Input() brandId: string;
  dataSource = new MatTableDataSource();
  displayedColumns = ['no', 'code', 'address', 'status', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('searchInput') searchInput: ElementRef;
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selection = new SelectionModel<any>(true, []);
  brandLocationsResult: any[] = [];
  country_id: string = AppConfig.country_id;
  city_id: string = '';
  cities = [];

  private componentSubscriptions: Subscription;


  constructor(
    public dialog: MatDialog,
    public bs: BrandService,
    private ed: EncryptionDecryptionService,
    private layoutUtilsService: LayoutUtilsService) { }


  ngOnInit() {
    this.getCitiesByCountry();
  }
  getCitiesByCountry() {
    this.bs.getCitiesByCountry(this.ed.encryptValue(this.country_id)).subscribe((res) => {
      if (res && res['data'].length != 0) {
        this.cities = res['data'][0]['city']
        if (this.cities.length != 0) {
          this.city_id = this.cities[0]['_id'];
          this.getBrandLocationsByCity(this.cities[0]['_id']);
        }
      }
    });
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy() {
    if (this.componentSubscriptions) {
      this.componentSubscriptions.unsubscribe();
    }
  }

  getBrandLocationsByCity(city_id: string) {
    this.city_id = city_id;
    this.isLoadingResults = true;
    this.resultsLength = 0;
    this.brandLocationsResult = [];
    this.dataSource.data = [];
    this.bs!.getBrandLocationsByCity(this.brandId, city_id).subscribe(res => {
      console.log(res)
      if (res['data'] && res['data'].length !== 0) {
        this.resultsLength = res['data'][0].location.length;
        this.brandLocationsResult = res['data'][0].location;
        this.dataSource.data = res['data'][0].location;
        this.isLoadingResults = false;
        this.isRateLimitReached = false;
      }
      else {
        this.isLoadingResults = false;
        this.isRateLimitReached = false;
      }

    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }




  deleteLocation(_item: any) {
    const _title: string = 'Location Delete';
    const _description: string = 'Are you sure to permanently delete this Location?';
    const _waitDesciption: string = 'Location is deleting...';
    const _deleteMessage = `Location has been deleted`;

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.bs.deleteBrandLocation(this.ed.encryptValue(_item['_id'])).subscribe((res) => {
        if (res['success'] == true) {
          this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
          this.getBrandLocationsByCity(this.city_id);
        }
        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
      });

      // this.loadLocationsList();
    });
  }


  addLocation() {
    const dialogRef = this.dialog.open(EditBrandLocationComponent, {
      data: {
        isNew: true,
        brandId: this.brandId
      },
      width: '990px'
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res.isUpdated) {
        this.getBrandLocationsByCity(this.city_id);
      }
    });
  }


  editLocation(item: any) {
    const _item = Object.assign({}, item);
    const dialogRef = this.dialog.open(EditBrandLocationComponent, {
      data: {
        isNew: false,
        location: _item
      },
      width: '990px'
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res.isUpdated) {
        this.getBrandLocationsByCity(this.city_id);
      }
    });

  }
  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case true:
        return 'success';
      case false:
        return 'metal';
    }
    return '';
  }
  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Activated';
      case false:
        return 'Deactivated';
    }
    return '';
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.brandLocationsResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }
}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

