import { ChangeDetectorRef } from '@angular/core';
import { Component, Inject, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { CountryService } from '../../../country/country.service';
import { BrandService } from '../../brand.service';
import { EncryptionDecryptionService } from '../../../../../core/_base/layout/services/encryption-decryption.service';
import { LayoutUtilsService, MessageType } from '../../../../../core/_base/crud';

@Component({
  selector: 'kt-edit-brand-location',
  templateUrl: './edit-brand-location.component.html',
  styleUrls: ['./edit-brand-location.component.scss']
})
export class EditBrandLocationComponent implements OnInit {


  locationEditForm: FormGroup;
  viewLoading: boolean = true;
  loadingAfterSubmit: boolean = false;
  countries: any[];
  filterCities: any[];
  filterAreas: any[];
  periods = ['AM', 'PM'];
  hours: any[];
  minutes: any[];
  constructor(
    public dialogRef: MatDialogRef<EditBrandLocationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private cs: CountryService,
    public bs: BrandService,
    private layoutUtilsService: LayoutUtilsService,
    private ed: EncryptionDecryptionService,
    private cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.hours = this.bs.getHours();
    this.minutes = this.bs.getMins();
    this.getAllCountries();
    this.initForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.initlocationForm();
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges(); // Remove this line
    }); // Remove this line
  }

  initForm() {

    this.locationEditForm = this.fb.group({
      code: ['', [Validators.required]],
      lat: ['', [Validators.required]],
      lng: ['', [Validators.required]],
      country: ['', [Validators.required]],
      city: ['', [Validators.required]],
      area: ['', [Validators.required]],
      address: ['', [Validators.required]],
      mondayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      mondayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      tuesdayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      tuesdayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      wednesdayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      wednesdayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      thursdayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      thursdayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      fridayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      fridayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      saturdayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      saturdayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      sundayOpenTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),
      sundayCloseTimings: this.fb.group({
        hr: ['', [Validators.required]],
        min: ['', [Validators.required]],
        format: ['', [Validators.required]],
      }),

    });
  }
  initlocationForm() {
    if (this.data['location']) {

      this.locationEditForm = this.fb.group({
        code: [this.data['location'].code, [Validators.required]],
        lat: [this.data['location'].geometry.coordinates[1], [Validators.required]],
        lng: [this.data['location'].geometry.coordinates[0], [Validators.required]],
        country: [this.data['location'].country_id, [Validators.required]],
        city: [this.data['location'].city_id, [Validators.required]],
        area: [this.data['location'].area_id, [Validators.required]],
        address: [this.data['location'].address, [Validators.required]],
        mondayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.mon.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.mon.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.mon.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        mondayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.mon.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.mon.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.mon.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        tuesdayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.tue.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.tue.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.tue.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        tuesdayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.tue.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.tue.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.tue.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        wednesdayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.wed.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.wed.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.wed.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        wednesdayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.wed.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.wed.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.wed.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        thursdayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.thu.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.thu.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.thu.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        thursdayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.thu.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.thu.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.thu.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        fridayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.fri.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.fri.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.fri.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        fridayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.fri.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.fri.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.fri.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        saturdayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.sat.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.sat.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.sat.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        saturdayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.sat.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.sat.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.sat.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        sundayOpenTimings: this.fb.group({
          hr: [this.data['location'].timings.sun.open.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.sun.open.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.sun.open.split(":")[1].split(" ")[1], [Validators.required]],
        }),
        sundayCloseTimings: this.fb.group({
          hr: [this.data['location'].timings.sun.close.split(":")[0], [Validators.required]],
          min: [this.data['location'].timings.sun.close.split(":")[1].split(" ")[0], [Validators.required]],
          format: [this.data['location'].timings.sun.close.split(":")[1].split(" ")[1], [Validators.required]],
        }),

      });
      this.locationEditForm.controls['code'].disable();
      this.getCountry(this.data['location'].country_id);
      this.getCity(this.data['location'].city_id);
    }
    else {

      this.locationEditForm = this.fb.group({
        code: ['', [Validators.required]],
        lat: ['', [Validators.required]],
        lng: ['', [Validators.required]],
        country: ['', [Validators.required]],
        city: ['', [Validators.required]],
        area: ['', [Validators.required]],
        address: ['', [Validators.required]],
        mondayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        mondayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        tuesdayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        tuesdayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        wednesdayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        wednesdayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        thursdayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        thursdayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        fridayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        fridayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        saturdayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        saturdayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        sundayOpenTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),
        sundayCloseTimings: this.fb.group({
          hr: ['', [Validators.required]],
          min: ['', [Validators.required]],
          format: ['', [Validators.required]],
        }),

      });
    }

  }

  getAllCountries() {
    this.cs!.getAllCountries().subscribe(res => {
      this.countries = res['data'];
      // console.log(this.countries)
      for (let i = 0; i < this.countries.length; i++) {
        this.countries[i]['_id'] = this.ed.decryptValue(this.countries[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  getCountry(val) {
    // if (val.length == 0)
    //   this.brandForm.get('child').setValue([''])
    this.filterCities = []
    this.filterAreas = []
    // for (let i = 0; i < val.length; i++) {
    this.filterCities.push(this.getFilter(this.countries, val)[0])
    // }
  }
  getCity(val) {
    // if (val.length == 0)
    //   this.brandForm.get('child').setValue([''])
    this.filterAreas = []
    for (let i = 0; i < this.filterCities.length; i++) {
      this.filterAreas.push(this.getFilter(this.filterCities[i]['cities'], val)[0])
    }
  }
  getFilter(opt: any[], val: string) {
    // if (opt != undefined)
    return opt.filter(item => item._id == val);
  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  onNoClick(): void {
    this.dialogRef.close({ isUpdated: false });
  }

  save() {
    const controls = this.locationEditForm.controls;

    if (this.locationEditForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      return;
    }

    this.loadingAfterSubmit = true;
    this.viewLoading = true;
    let location = {
      code: '',
      lat: '',
      lng: '',
      // country: '',
      // city: '',
      // area: '',
      area_id: '',
      brand_id: '',
      address: '',
      mondayOpenTimings: '',
      mondayCloseTimings: '',
      tuesdayOpenTimings: '',
      tuesdayCloseTimings: '',
      wednesdayOpenTimings: '',
      wednesdayCloseTimings: '',
      thursdayOpenTimings: '',
      thursdayCloseTimings: '',
      fridayOpenTimings: '',
      fridayCloseTimings: '',
      saturdayOpenTimings: '',
      saturdayCloseTimings: '',
      sundayOpenTimings: '',
      sundayCloseTimings: '',
    };
    location.code = controls['code'].value
    location.lat = controls['lat'].value
    location.lng = controls['lng'].value
    location.area_id = controls['area'].value
    location.address = controls['address'].value
    location.mondayOpenTimings = controls['mondayOpenTimings'].value.hr + ':' + controls['mondayOpenTimings'].value.min + ' ' + controls['mondayOpenTimings'].value.format;
    location.mondayCloseTimings = controls['mondayCloseTimings'].value.hr + ':' + controls['mondayCloseTimings'].value.min + ' ' + controls['mondayCloseTimings'].value.format;
    location.tuesdayOpenTimings = controls['tuesdayOpenTimings'].value.hr + ':' + controls['tuesdayOpenTimings'].value.min + ' ' + controls['tuesdayOpenTimings'].value.format;
    location.tuesdayCloseTimings = controls['tuesdayCloseTimings'].value.hr + ':' + controls['tuesdayCloseTimings'].value.min + ' ' + controls['tuesdayCloseTimings'].value.format;
    location.wednesdayOpenTimings = controls['wednesdayOpenTimings'].value.hr + ':' + controls['wednesdayOpenTimings'].value.min + ' ' + controls['wednesdayOpenTimings'].value.format;
    location.wednesdayCloseTimings = controls['wednesdayCloseTimings'].value.hr + ':' + controls['wednesdayCloseTimings'].value.min + ' ' + controls['wednesdayCloseTimings'].value.format;
    location.thursdayOpenTimings = controls['thursdayOpenTimings'].value.hr + ':' + controls['thursdayOpenTimings'].value.min + ' ' + controls['thursdayOpenTimings'].value.format;
    location.thursdayCloseTimings = controls['thursdayCloseTimings'].value.hr + ':' + controls['thursdayCloseTimings'].value.min + ' ' + controls['thursdayCloseTimings'].value.format;
    location.fridayOpenTimings = controls['fridayOpenTimings'].value.hr + ':' + controls['fridayOpenTimings'].value.min + ' ' + controls['fridayOpenTimings'].value.format;
    location.fridayCloseTimings = controls['fridayCloseTimings'].value.hr + ':' + controls['fridayCloseTimings'].value.min + ' ' + controls['fridayCloseTimings'].value.format;
    location.saturdayOpenTimings = controls['saturdayOpenTimings'].value.hr + ':' + controls['saturdayOpenTimings'].value.min + ' ' + controls['saturdayOpenTimings'].value.format;
    location.saturdayCloseTimings = controls['saturdayCloseTimings'].value.hr + ':' + controls['saturdayCloseTimings'].value.min + ' ' + controls['saturdayCloseTimings'].value.format;
    location.sundayOpenTimings = controls['sundayOpenTimings'].value.hr + ':' + controls['sundayOpenTimings'].value.min + ' ' + controls['sundayOpenTimings'].value.format;
    location.sundayCloseTimings = controls['sundayCloseTimings'].value.hr + ':' + controls['sundayCloseTimings'].value.min + ' ' + controls['sundayCloseTimings'].value.format;
    console.log(location)
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false;
      this.closeDialog(location);
    }); // Remove this line
  }


  closeDialog(location) {

    if (this.data['isNew']) {
      location['brand_id'] = this.ed.decryptValue(this.data['brandId']);
      this.bs.addBrandLocation(location).subscribe((res) => {
        if (res['success'] == true) {
          const saveMessage = `Location has been created`;
          this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Create, 10000, true, true);
          this.dialogRef.close({
            isUpdated: true
          });
        }
        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Create, 10000, true, true);
      });
    }
    else {
      location['brand_id'] = this.data['location']['brand_id'];
      this.bs.updateBrandLocation(location, this.ed.encryptValue(this.data['location']['_id'])).subscribe((res) => {

        if (res['success'] == true) {
          const saveMessage = `Location has been updated`;
          this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Update, 10000, true, true);
          this.dialogRef.close({
            isUpdated: true
          });
        }
        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Update, 10000, true, true);
      });
    }
  }


  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.locationEditForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }


}
