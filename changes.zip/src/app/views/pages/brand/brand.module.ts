// Angular
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
// Fake API Angular-in-memory
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
// Translate Module
import { TranslateModule } from '@ngx-translate/core';
// UI
import { PartialsModule } from '../../partials/partials.module';
// Core
import { FakeApiService } from '../../../core/_base/layout';
// Auth
import { ModuleGuard } from '../../../core/auth';
// Core => Utils
import {
  HttpUtilsService,
  TypesUtilsService,
  InterceptService,
  LayoutUtilsService
} from '../../../core/_base/crud';
// Shared
import {
  ActionNotificationComponent,
  DeleteEntityDialogComponent,
  FetchEntityDialogComponent,
  UpdateStatusDialogComponent
} from '../../partials/content/crud';
// Components
import { BrandComponent } from './brand.component';
import { BrandsComponent } from './brands/brands.component';
import { EditBrandSpecialityComponent } from './brand-speciality/edit-brand-speciality/edit-brand-speciality.component';
import { MaterialFileInputModule } from 'ngx-material-file-input';
// Material
import {
  MatInputModule,
  MatPaginatorModule,
  MatProgressSpinnerModule,
  MatSortModule,
  MatTableModule,
  MatSelectModule,
  MatMenuModule,
  MatProgressBarModule,
  MatButtonModule,
  MatCheckboxModule,
  MatDialogModule,
  MatTabsModule,
  MatNativeDateModule,
  MatCardModule,
  MatRadioModule,
  MatIconModule,
  MatDatepickerModule,
  MatAutocompleteModule,
  MAT_DIALOG_DEFAULT_OPTIONS,
  MatSnackBarModule,
  MatTooltipModule,
  MatChipsModule
} from '@angular/material';
import { environment } from '../../../../environments/environment';
import { CoreModule } from '../../../core/core.module';
import { NgbProgressbarModule, NgbProgressbarConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgxPermissionsModule } from 'ngx-permissions';
import { BrandEditComponent } from './brand-edit/brand-edit.component';
import { BrandSpecialitiesComponent } from './brand-speciality/brand-specialities/brand-specialities.component';
import { BrandFacilitiesComponent } from './brand-facility/brand-facilities/brand-facilities.component';
import { EditBrandFacilityComponent } from './brand-facility/edit-brand-facility/edit-brand-facility.component';
import { BrandLocationsComponent } from './brand-location/brand-locations/brand-locations.component';
import { EditBrandLocationComponent } from './brand-location/edit-brand-location/edit-brand-location.component';
import { BrandOffersComponent } from './brand-offer/brand-offers/brand-offers.component';
import { EditBrandOfferComponent } from './brand-offer/edit-brand-offer/edit-brand-offer.component';
import { BrandOrdersComponent } from './brand-order/brand-orders/brand-orders.component';

const routes: Routes = [
  {
    path: '',
    component: BrandComponent,
    children: [
      {
        path: 'all',
        component: BrandsComponent
      },
      {
        path: 'add',
        component: BrandEditComponent
      },
      // {
      //   path: 'edit',
      //   component: BrandEditComponent
      // },
      {
        path: 'edit/:state/:id',
        component: BrandEditComponent
      },
    ]
  }
];

@NgModule({
  imports: [
    MatDialogModule,
    CommonModule,
    HttpClientModule,
    PartialsModule,
    NgxPermissionsModule.forChild(),
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    TranslateModule.forChild(),
    MatButtonModule,
    MatMenuModule,
    MatSelectModule,
    MatInputModule,
    MatTableModule,
    MatAutocompleteModule,
    MatRadioModule,
    MatIconModule,
    MatNativeDateModule,
    MatProgressBarModule,
    MatDatepickerModule,
    MatCardModule,
    MatPaginatorModule,
    MatSortModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    MatTabsModule,
    MatTooltipModule,
    NgbProgressbarModule,
    environment.isMockEnabled ? HttpClientInMemoryWebApiModule.forFeature(FakeApiService, {
      passThruUnknownUrl: true,
      dataEncapsulation: false
    }) : [],
    MaterialFileInputModule,
    MatChipsModule,
  ],
  providers: [
    ModuleGuard,
    InterceptService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptService,
      multi: true
    },
    {
      provide: MAT_DIALOG_DEFAULT_OPTIONS,
      useValue: {
        hasBackdrop: true,
        panelClass: 'kt-mat-dialog-container__wrapper',
        height: 'auto',
        width: '900px'
      }
    },
    TypesUtilsService,
    LayoutUtilsService,
    HttpUtilsService,
    TypesUtilsService,
    LayoutUtilsService
  ],
  entryComponents: [
    ActionNotificationComponent,
    DeleteEntityDialogComponent,
    FetchEntityDialogComponent,
    UpdateStatusDialogComponent,
    EditBrandSpecialityComponent,
    EditBrandFacilityComponent,
    EditBrandLocationComponent,
    EditBrandOfferComponent
  ],
  declarations: [BrandComponent, BrandsComponent, BrandEditComponent, EditBrandSpecialityComponent, BrandSpecialitiesComponent, BrandFacilitiesComponent, EditBrandFacilityComponent, BrandLocationsComponent, EditBrandLocationComponent, BrandOffersComponent, EditBrandOfferComponent, BrandOrdersComponent],
})
export class BrandModule { }
