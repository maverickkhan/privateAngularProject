import { ChangeDetectorRef } from '@angular/core';
import { Component, Inject, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-edit-brand-speciality',
  templateUrl: './edit-brand-speciality.component.html',
  styleUrls: ['./edit-brand-speciality.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EditBrandSpecialityComponent implements OnInit {

  specialityEditForm: FormGroup;
  viewLoading: boolean = true;
  loadingAfterSubmit: boolean = false;
  filesToUploadForIcon: Array<File> = [];

  constructor(
    public dialogRef: MatDialogRef<EditBrandSpecialityComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.initspecialityForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges(); // Remove this line
    }); // Remove this line
  }


  initspecialityForm() {
    const specName: string = this.data.name;
    this.specialityEditForm = this.fb.group({
      name: [specName, [Validators.required]],
      icon: [null, [Validators.required]]
    });
  }


  onNoClick(): void {
    this.dialogRef.close({ isUpdated: false });
  }
  onFileChangeForIcon(event) {
    if (event.target.files.length > 0) {
      this.filesToUploadForIcon = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUploadForIcon);
      this.specialityEditForm.get('icon').setValue(this.filesToUploadForIcon);

    }
  }
  removeFileForIcon() {
    this.specialityEditForm.get('icon').setValue(null);
  }

  save() {
    const controls = this.specialityEditForm.controls;

    if (this.specialityEditForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      return;
    }

    this.loadingAfterSubmit = true;
    this.viewLoading = true;

    // const specName = controls['name'].value;
    let input = new FormData();
    const iconFiles: Array<File> = this.filesToUploadForIcon;
    console.log(iconFiles);
    input.append('speciality_name', this.specialityEditForm.get('name').value);
    for (let i = 0; i < iconFiles.length; i++) {
      input.append("speciality_icon", iconFiles[i], iconFiles[i]['name']);
    }
    /* Server loading imitation. Remove this on real code */
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false;
      this.closeDialog(input);
    }); // Remove this line
  }


  closeDialog(spec) {
    this.dialogRef.close({
      isUpdated: true,
      spec: spec
    });
  }


  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.specialityEditForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }


}
