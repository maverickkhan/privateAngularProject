import { ChangeDetectorRef } from '@angular/core';
import { Component, Inject, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatChipInputEvent } from '@angular/material';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { CountryService } from '../../../country/country.service';
import { BrandService } from '../../brand.service';
import { EncryptionDecryptionService } from '../../../../../core/_base/layout/services/encryption-decryption.service';
import { ENTER, COMMA } from '@angular/cdk/keycodes';
import moment = require('moment');

@Component({
  selector: 'kt-edit-brand-offer',
  templateUrl: './edit-brand-offer.component.html',
  styleUrls: ['./edit-brand-offer.component.scss']
})
export class EditBrandOfferComponent implements OnInit {

  offerEditForm: FormGroup;
  viewLoading: boolean = true;
  loadingAfterSubmit: boolean = false;
  countries: any[];
  locations: any[];
  packages: any[];
  filterCities: any[];
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = true;
  separatorKeysCodes = [ENTER, COMMA];
  daysInWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  constructor(
    public dialogRef: MatDialogRef<EditBrandOfferComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private cs: CountryService,
    public bs: BrandService,
    private ed: EncryptionDecryptionService,
    private cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
   this.getAllCountries();
   this.getLocations(this.data.brandId);
   this.initForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.initofferForm();
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges(); // Remove this line
    }); // Remove this line
  }

  initForm() {
    this.offerEditForm = this.fb.group({
      title: ['', [Validators.required]],
      sub_title: ['', [Validators.required]],
      offer_description: ['', [Validators.required]],
      offer_end_date: [moment().add(1,"years").format("YYYY-MM-DD")],
      offer_start_date: [moment().format("YYYY-MM-DD")],
      per_day_number_of_avails: [0, [Validators.required]],
      couponcode: [''],
      weburl: [''],
      country_id: "5d6f8cf82c94f35475f82401",
      city_id: ['', [Validators.required]],
      address_id: ['', [Validators.required]],
      package_id: ['', [Validators.required]],
      days: [[]],
      tags: [[]],
      is_flat_discount: [false],
      actual_amount: [0],
      discounted_amount: [0],
      discounted_percent: [0],
      is_hyper: [false],
      number_of_unit: [0],
      hyper_amount: [0],
      hyper_save_amount: [0],
      start_datetime: [moment().format("YYYY-MM-DD")],
      expair_datetime: [moment().add(5,"years").format("YYYY-MM-DD")],
      is_baga: [false],
      baga_amount: [0],
      baga_save_amount: [0],
      is_deliverable: [false],
      is_other: [false],
      is_premium: [false],
      in_store :[false],
      terms_and_condition: ['', [Validators.required]],
      image: [null]
    });
  }
  initofferForm() {
    if (this.data['offer']) {
      this.offerEditForm = this.fb.group({

        title: [this.data['offer'].title, [Validators.required]],
        sub_title: [this.data['offer'].sub_title, [Validators.required]],
        offer_description: [this.data['offer'].offer_description, [Validators.required]],
        couponcode: [this.data['offer'].online_store.couponcode],
        weburl: [this.data['offer'].online_store.weburl],
        country_id: [this.data['offer'].country_id],
        // country_id: [''],
        city_id: [this.data['offer'].city_id, [Validators.required]],
        offer_start_date: [this.data['offer'].offer_start_date],
        offer_end_date: [this.data['offer'].offer_end_date],
        per_day_number_of_avails: [this.data['offer'].per_day_number_of_avails, [Validators.required]],
        address_id: [this.data['offer'].address_id, [Validators.required]],
        package_id: [this.data['offer'].package_id, [Validators.required]],
        days: [this.data['offer'].days],
        tags: [this.data['offer'].tags],
        is_flat_discount: [this.data['offer'].flat_discount.is_flat_discount],
        actual_amount: [this.data['offer'].flat_discount.actual_amount],
        discounted_amount: [this.data['offer'].flat_discount.discounted_amount],
        discounted_percent: [this.data['offer'].flat_discount.discounted_percent],
        is_hyper: [this.data['offer'].hyper.is_hyper],
        number_of_unit: [this.data['offer'].hyper.number_of_unit],
        hyper_amount: [this.data['offer'].hyper.amount],
        hyper_save_amount: [this.data['offer'].hyper.save_amount],
        start_datetime: [this.data['offer'].hyper.start_datetime],
        expair_datetime: [this.data['offer'].hyper.expair_datetime],
        is_baga: [this.data['offer'].baga.is_baga],
        baga_amount: [this.data['offer'].baga.amount],
        baga_save_amount: [this.data['offer'].baga.save_amount],
        is_deliverable: [this.data['offer'].is_deliverable],
        is_other: [this.data['offer'].is_other],
        is_premium: [this.data['offer'].is_premium],
        in_store :[this.data['offer'].in_store],
        terms_and_condition: [this.data['offer'].terms_and_condition, [Validators.required]],
        image: [null]


      });
      this.getCountry(this.data['offer'].country_id);
      this.getPackages(this.data['offer'].city_id);
      this.getPackagesByOffer(this.data['offer']._id);
    }
    else {
      this.offerEditForm = this.fb.group({
        title: ['', [Validators.required]],
        sub_title: ['', [Validators.required]],
        offer_description: ['', [Validators.required]],
        offer_end_date: [moment().add(1,"years").format("YYYY-MM-DD")],
        offer_start_date: [moment().format("YYYY-MM-DD")],
        per_day_number_of_avails: [0, [Validators.required]],
        couponcode: [''],
        weburl: [''],
        country_id: '5d6f8cf82c94f35475f82401',
        city_id: ['', [Validators.required]],
        address_id: ['', [Validators.required]],
        package_id: ['', [Validators.required]],
        days: [[]],
        tags: [[]],
        is_flat_discount: [false],
        actual_amount: [0],
        discounted_amount: [0],
        discounted_percent: [0],
        is_hyper: [false],
        number_of_unit: [0],
        hyper_amount: [0],
        hyper_save_amount: [0],
        start_datetime: [moment().format("YYYY-MM-DD")],
        expair_datetime: [moment().add(5,"years").format("YYYY-MM-DD")],
        is_baga: [false],
        baga_amount: [0],
        baga_save_amount: [0],
        is_deliverable: [false],
        is_other: [false],
        is_premium: [false],
        in_store :[false],
        terms_and_condition: ['', [Validators.required]],
        image: [null]
      });
    }



console.log(this.offerEditForm.value)

  }
  onFileChange(event) {
    if (event.target.files.length > 0) {
      let file = event.target.files[0];
      console.log(file);
      this.offerEditForm.get('image').setValue(file);

    }


  }
  removeFile() {
    this.offerEditForm.get('image').setValue(null);
  }
  addTag(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.offerEditForm.get('tags').value.push(value.trim());
    }
    if (input) {
      input.value = '';
    }
  }
  removeTag(tag: any): void {
    const index = this.offerEditForm.get('tags').value.indexOf(tag);
    if (index >= 0) {
      this.offerEditForm.get('tags').value.splice(index, 1);
    }
  }

  getAllCountries() {
    this.cs!.getAllCountries().subscribe(res => {
      this.countries = res['data'];
      // console.log(this.countries)
      for (let i = 0; i < this.countries.length; i++) {
        this.countries[i]['_id'] = this.ed.decryptValue(this.countries[i]['_id'])
      }
      this.filterCities = []
      this.filterCities.push(this.getFilter(this.countries, this.countries[0]['_id'])[0])
    },
      err => {
        console.log(err)
      })
  }
  getCountry(val) {
    // if (val.length == 0)
    //   this.brandForm.get('child').setValue([''])
    this.filterCities = []
    // for (let i = 0; i < val.length; i++) {
    this.filterCities.push(this.getFilter(this.countries, val)[0])
    // }
  }
  getPackages(city_id) {
    console.log(city_id)
    this.bs!.getPackagesByCity(city_id).subscribe(res => {
      this.packages = res['data'];
      this.packages.push({_id: "5d443bf55f4c96224cd23061",name: "Refer"})
      this.packages.push({_id: "5c8b7bc33e28ae1170483bc8",name: "Free For Customer"})
      console.log(this.packages,"Packesss")

      // for (let i = 0; i < this.countries.length; i++) {
      //   this.countries[i]['_id'] = this.ed.decryptValue(this.countries[i]['_id'])
      // }
    },
      err => {
        console.log(err)
      })
  }
  getPackagesByOffer(offer_id) {
    console.log(offer_id)
    this.bs!.getPackagesByOffer(offer_id).subscribe(res => {
      let packages = res['data'];
      let packageIds = [];
      console.log(packages)
      for (let i = 0; i < packages.length; i++) {
        packages[i]['_id'] = this.ed.decryptValue(packages[i]['_id'])
        packageIds.push(packages[i]['_id'])
      }
      console.log(packageIds)
      this.offerEditForm.get('package_id').setValue(packageIds)
    },
      err => {
        console.log(err)
      })

  }
  getLocations(brand_id) {
    console.log(brand_id)
    this.bs!.getLocationsByBrand(brand_id).subscribe(res => {
      this.locations = res['data'];
      console.log(this.locations)
      for (let i = 0; i < this.locations.length; i++) {
        this.locations[i]['_id'] = this.ed.decryptValue(this.locations[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }

  getFilter(opt: any[], val: string) {
    if (opt != undefined)
      return opt.filter(item => item._id == val);
      else
      return []
  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  onNoClick(): void {
    this.dialogRef.close({ isUpdated: false });
  }

  changeCheckBox($event,fieldName){
    if(fieldName == "is_flat_discount"){
      this.offerEditForm.get('is_flat_discount').setValue(true)
      this.offerEditForm.get('is_hyper').setValue(false)
      this.offerEditForm.get('is_baga').setValue(false)
    }else if(fieldName == "is_hyper"){
      this.offerEditForm.get('is_flat_discount').setValue(false)
      this.offerEditForm.get('is_hyper').setValue(true)
      this.offerEditForm.get('is_baga').setValue(false)
    }else if(fieldName == "is_baga"){
      this.offerEditForm.get('is_flat_discount').setValue(false)
      this.offerEditForm.get('is_hyper').setValue(false)
      this.offerEditForm.get('is_baga').setValue(true)
    }
  }

  save() {
    const controls = this.offerEditForm.controls;
    console.log(controls)
    if (this.offerEditForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      return;
    }

    this.loadingAfterSubmit = true;
    this.viewLoading = true;

    let input = new FormData();
    if (!this.data['isNew'])
      input.append('offer_id', this.data['offer']._id);

    input.append('title', this.offerEditForm.get('title').value);
    input.append('sub_title', this.offerEditForm.get('sub_title').value);
    input.append('offer_description', this.offerEditForm.get('offer_description').value);
    let oed = new Date(this.offerEditForm.get('offer_end_date').value);
    input.append('offer_end_date', oed.getFullYear() + '-' + (oed.getMonth() + 1) + '-' + oed.getDate());
    let osd = new Date(this.offerEditForm.get('offer_start_date').value);
    input.append('offer_start_date', osd.getFullYear() + '-' + (osd.getMonth() + 1) + '-' + osd.getDate());
    input.append('per_day_number_of_avails', this.offerEditForm.get('per_day_number_of_avails').value);
    input.append('couponcode', this.offerEditForm.get('couponcode').value);
    input.append('weburl', this.offerEditForm.get('weburl').value);
    input.append('country_id', this.offerEditForm.get('country_id').value);
    input.append('city_id', this.offerEditForm.get('city_id').value);
    input.append('package_id', JSON.stringify(this.offerEditForm.get('package_id').value));
    input.append('address_id', JSON.stringify(this.offerEditForm.get('address_id').value));
    input.append('days', JSON.stringify(this.offerEditForm.get('days').value));
    input.append('tags', JSON.stringify(this.offerEditForm.get('tags').value));
    input.append('is_flat_discount', this.offerEditForm.get('is_flat_discount').value);
    input.append('actual_amount', this.offerEditForm.get('actual_amount').value);
    input.append('discounted_amount', this.offerEditForm.get('discounted_amount').value);
    input.append('discounted_percent', this.offerEditForm.get('discounted_percent').value);
    input.append('is_hyper', this.offerEditForm.get('is_hyper').value);
    input.append('number_of_unit', this.offerEditForm.get('number_of_unit').value);
    input.append('hyper_amount', this.offerEditForm.get('hyper_amount').value);
    input.append('hyper_save_amount', this.offerEditForm.get('hyper_save_amount').value);
    let hsd = new Date(this.offerEditForm.get('start_datetime').value);
    input.append('start_datetime', hsd.getFullYear() + '-' + (hsd.getMonth() + 1) + '-' + hsd.getDate());
    let hed = new Date(this.offerEditForm.get('expair_datetime').value);
    input.append('expair_datetime', hed.getFullYear() + '-' + (hed.getMonth() + 1) + '-' + hed.getDate());
    input.append('is_baga', this.offerEditForm.get('is_baga').value);
    input.append('amount', this.offerEditForm.get('baga_amount').value);
    input.append('save_amount', this.offerEditForm.get('baga_save_amount').value);
    input.append('is_deliverable', this.offerEditForm.get('is_deliverable').value);
    input.append('is_other', this.offerEditForm.get('is_other').value);
    input.append('is_premium', this.offerEditForm.get('is_premium').value);
    input.append('in_store', this.offerEditForm.get('in_store').value);
    input.append('terms_and_condition', this.offerEditForm.get('terms_and_condition').value);
    input.append("image", this.offerEditForm.get('image').value);

    // return input;

    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false;
      this.closeDialog(input);
    }); // Remove this line
  }


  closeDialog(offer) {
    this.dialogRef.close({
      isUpdated: true,
      offer: offer
    });
  }


  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.offerEditForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }

}
