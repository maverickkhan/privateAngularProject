import { Component, OnInit, ElementRef, ViewChild, Input, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { LayoutUtilsService, MessageType } from '../../../../../core/_base/crud';
import { EditBrandOfferComponent } from '../edit-brand-offer/edit-brand-offer.component';
import { BrandService } from '../../brand.service';
import { EncryptionDecryptionService } from '../../../../../core/_base/layout/services/encryption-decryption.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-brand-offers',
  templateUrl: './brand-offers.component.html',
  styleUrls: ['./brand-offers.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class BrandOffersComponent implements OnInit {
  @Input() brandId: string;
  dataSource = new MatTableDataSource();
  displayedColumns = ['no', 'title', 'offer_description', 'status', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('searchInput') searchInput: ElementRef;
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  brandOffersResult: any[] = [];
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];

  constructor(
    public dialog: MatDialog,
    public bs: BrandService,
    private ed: EncryptionDecryptionService,
    private layoutUtilsService: LayoutUtilsService) { }


  ngOnInit() {
    this.Init(this.brandId);
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  ngOnDestroy() {

  }


  Init(brandId: string) {

    this.isLoadingResults = true;
    this.bs!.getBrandById(brandId).subscribe(res => {
      this.resultsLength = res['data'][0].offer.length;
      this.brandOffersResult = res['data'][0].offer
      this.dataSource.data = res['data'][0].offer;
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })


  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  deleteOffer(_item: any) {
    const _title: string = 'Offer Delete';
    const _description: string = 'Are you sure to permanently delete this Offer?';
    const _waitDesciption: string = 'Offer is deleting...';
    const _deleteMessage = `Offer has been deleted`;

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.bs.deleteBrandOffer(_item, this.brandId).subscribe((res) => {
        if (res['success'] == true) {
          this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
          this.Init(this.brandId);
        }
        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
      });
    });
  }

  addOffer() {
    const dialogRef = this.dialog.open(EditBrandOfferComponent, {
      data: {
        isNew: true,
        brandId: this.ed.decryptValue(this.brandId)
      },
      width: '990px'
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res.isUpdated) {
        // res['offer']['brand_id'] = this.ed.decryptValue(this.brandId);
        this.bs.addBrandOffer(res['offer'], this.brandId).subscribe((res) => {
          if (res['success'] == true) {
            const saveMessage = `Offer has been created`;
            this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Create, 10000, true, true);
            this.Init(this.brandId);
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], MessageType.Create, 10000, true, true);
        });


      }
    });
  }


  editOffer(item: any) {
    const _item = Object.assign({}, item);
    const dialogRef = this.dialog.open(EditBrandOfferComponent, {
      data: {
        isNew: false,
        offer: _item,
        brandId: this.ed.decryptValue(this.brandId)
      },
      width: '990px'
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res.isUpdated) {
        // res['offer']['brand_id'] = _item['brand_id'];
        this.bs.updateBrandOffer(res['offer'], this.brandId).subscribe((res) => {

          if (res['success'] == true) {
            const saveMessage = `Offer has been updated`;
            this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Update, 10000, true, true);
            this.Init(this.brandId);
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], MessageType.Update, 10000, true, true);
        });
      }
    });

  }
  getItemCssClassByStatus(status: boolean = false): string {
    switch (status) {
      case true:
        return 'success';
      case false:
        return 'metal';
    }
    return '';
  }
  getItemStatusString(status: boolean = false): string {
    switch (status) {
      case true:
        return 'Activated';
      case false:
        return 'Deactivated';
    }
    return '';
  }
  sortData(sort: Sort) {
    const data = this.brandOffersResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'title': return compare(a.title, b.title, isAsc);
        case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
        default: return 0;
      }
    });
  }
}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
