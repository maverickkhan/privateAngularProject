
import { Component, OnInit, ElementRef, ViewChild, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, Sort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { debounceTime, distinctUntilChanged, tap, delay } from 'rxjs/operators';
import { SubheaderService } from '../../../../core/_base/layout';
import { LayoutUtilsService, MessageType, QueryParamsModel } from '../../../../core/_base/crud';
import { BrandService } from '../brand.service';

@Component({
	// tslint:disable-next-line:component-selector
	selector: 'kt-brands',
	templateUrl: './brands.component.html',
	styleUrls: ['./brands.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class BrandsComponent implements OnInit, OnDestroy {
	//dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
	// dataSource = ELEMENT_DATA;
	// dataSource = new MatTableDataSource(ELEMENT_DATA);
	dataSource = new MatTableDataSource();
	// displayedColumns = ['no', 'name', 'description', 'phone_number', 'webUrl', 'status', 'actions'];
	displayedColumns = ['no', 'name', 'phone_number', 'webUrl', 'status', 'actions'];

	@ViewChild(MatPaginator) paginator: MatPaginator;
	@ViewChild('sort1') sort: MatSort;
	@ViewChild('searchInput') searchInput: ElementRef;

	filterStatus: string = '';
	filterCondition: string = '';
	lastQuery: QueryParamsModel;

	resultsLength = 0;
	isLoadingResults = true;
	isRateLimitReached = false;
	pageSize = 10;
	pageSizeOptions = [5, 10, 25, 100];
	brandsResult: any[] = [];

	selection = new SelectionModel<any>(true, []);
	private subscriptions: Subscription[] = [];

	constructor(public dialog: MatDialog,
		private activatedRoute: ActivatedRoute,
		private router: Router,
		private subheaderService: SubheaderService,
		private layoutUtilsService: LayoutUtilsService,
		private bs: BrandService,

	) { }


	ngOnInit() {
		this.Init();
		this.subheaderService.setTitle('Brands');
	}
	Init() {
		this.isLoadingResults = true;
		this.bs!.getAllBrands().subscribe(res => {
			this.resultsLength = res['data'].length;
			this.brandsResult = res['data'];
			this.dataSource.data = res['data'];
			this.isLoadingResults = false;
			this.isRateLimitReached = false;
		},
			err => {
				console.log(err)
				this.isLoadingResults = false;
				this.isRateLimitReached = true;
			})
	}

	ngOnDestroy() {
		this.subscriptions.forEach(el => el.unsubscribe());
	}

	ngAfterViewInit() {
		this.dataSource.paginator = this.paginator;
		this.dataSource.sort = this.sort;
	}


	deleteBrand(_item) {
		const _title: string = 'Brand Delete';
		const _description: string = 'Are you sure to permanently delete this Brand?';
		const _waitDesciption: string = 'Brand is deleting...';
		const _deleteMessage = `Brand has been deleted`;

		const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
		dialogRef.afterClosed().subscribe(res => {
			if (!res) {
				return;
			}
			this.bs.deleteBrand(_item['_id']).subscribe((res) => {
				if (res['success'] == true) {

					this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
					this.Init();
				}
				else
					this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
			});
		});
	}


	editBrand(id) {
		this.router.navigate(['../edit/b', id], { relativeTo: this.activatedRoute });
	}
	goToBrandOffers(id) {
		this.router.navigate(['../edit/of', id], { relativeTo: this.activatedRoute });
	}
	goToBrandLocations(id) {
		this.router.navigate(['../edit/l', id], { relativeTo: this.activatedRoute });
	}
	goToBrandOrders(id) {
		this.router.navigate(['../edit/or', id], { relativeTo: this.activatedRoute });
	}
	goToBrandSpecialities(id) {
		this.router.navigate(['../edit/s', id], { relativeTo: this.activatedRoute });
	}
	goToBrandFacilities(id) {
		this.router.navigate(['../edit/f', id], { relativeTo: this.activatedRoute });
	}
	getItemStatusString(status: boolean = false): string {
		switch (status) {
			case true:
				return 'Activated';
			case false:
				return 'Deactivated';
		}
		return '';
	}


	getItemCssClassByStatus(status: boolean = false): string {
		switch (status) {
			case true:
				return 'success';
			case false:
				return 'metal';
		}
		return '';
	}


	getItemConditionString(condition: number = 0): string {
		switch (condition) {
			case 0:
				return 'New';
			case 1:
				return 'Used';
		}
		return '';
	}


	getItemCssClassByCondition(condition: number = 0): string {
		switch (condition) {
			case 0:
				return 'accent';
			case 1:
				return 'primary';
		}
		return '';
	}
	applyFilter(filterValue: string) {
		filterValue = filterValue.trim();
		filterValue = filterValue.toLowerCase();
		this.dataSource.filter = filterValue;
	}
	sortData(sort: Sort) {
		const data = this.brandsResult.slice();
		if (!sort.active || sort.direction == '') {
			this.dataSource.data = data;
			return;
		}
		if (sort.active == "no") {
			this.dataSource.data.reverse();
			return;
		}
		this.dataSource.data = data.sort((a, b) => {
			let isAsc = sort.direction == 'asc';
			switch (sort.active) {
				case 'name': return compare(a.name, b.name, isAsc);
				case 'status': return compare(a.status.is_activated, b.status.is_activated, isAsc);
				default: return 0;
			}
		});
	}
}

function compare(a, b, isAsc) {
	return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}