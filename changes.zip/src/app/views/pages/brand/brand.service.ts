import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_BRANDS_URL = `${AppConfig.API_ENDPOINT}/brand`;

@Injectable({
  providedIn: 'root'
})
export class BrandService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }


  createBrand(brand: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_BRANDS_URL}/create`, brand, { headers: httpHeaders });
  }

  getAllBrands() {
    return this.http.get(`${API_BRANDS_URL}/get`);
  }

  getBrandById(brandId) {
    return this.http.get(API_BRANDS_URL + `/get?id=${brandId}`);
  }

  updateBrand(brand: any, brandId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_BRANDS_URL}/update/${brandId}`, brand, { headers: httpHeader });
  }
  addBrandSpeciality(speciality: any, brandId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_BRANDS_URL}specialties/create/${brandId}`, speciality, { headers: httpHeader });
  }
  deleteBrandSpeciality(speciality: any, brandId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    const options = {
      headers: httpHeaders,
      body: {
        speciality_id: speciality['_id']
      },
    };
    const url = `${API_BRANDS_URL}specialties/remove/${brandId}`;
    return this.http.delete(url, options);
  }
  addBrandFacility(facility: any, brandId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_BRANDS_URL}facilities/create/${brandId}`, facility, { headers: httpHeader });
  }
  deleteBrandFacility(facility: any, brandId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    const options = {
      headers: httpHeaders,
      body: {
        facility_id: facility['_id']
      },
    };
    const url = `${API_BRANDS_URL}facilities/remove/${brandId}`;
    return this.http.delete(url, options);
  }
  addBrandLocation(location: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_BRANDS_URL}-location/create`, location, { headers: httpHeaders });
  }
  updateBrandLocation(location: any, brandLocationId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_BRANDS_URL}-location/update/${brandLocationId}`, location, { headers: httpHeader });
  }
  deleteBrandLocation(brandLocationId: string) {
    const url = `${API_BRANDS_URL}-location/remove/${brandLocationId}`;
    return this.http.delete(url);
  }
  addBrandOffer(offer: any, brandId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${AppConfig.API_ENDPOINT}/offer/create/${brandId}`, offer, { headers: httpHeader });
  }
  updateBrandOffer(offer: any, brandId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${AppConfig.API_ENDPOINT}/offer/update/${brandId}`, offer, { headers: httpHeader });
  }

  deleteBrandOffer(offer: any, brandId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    const options = {
      headers: httpHeaders,
      body: {
        offer_id: offer['_id']
      },
    };
    const url = `${AppConfig.API_ENDPOINT}/offer/remove/${brandId}`;
    return this.http.delete(url, options);
  }

  deleteBrand(brandId: string) {
    const url = `${API_BRANDS_URL}/remove/${brandId}`;
    return this.http.delete(url);
  }

  getHours() {
    var hours = [];
    var tempVal = null;
    for (let i = 1; i <= 12; i++) {
      tempVal = i;
      if (i < 10) {

        tempVal = "0" + i;

      }
      hours.push(tempVal.toString());

    }

    return hours;
  }
  getMins() {
    var mins = [];
    var tempVal = null;
    for (let i = 0; i < 60; i++) {
      tempVal = i;
      if (i < 10) {

        tempVal = "0" + i;

      }
      mins.push(tempVal.toString());

    }

    return mins;
  }
  getPackagesByCity(city_id) {
    return this.http.get(`${AppConfig.API_ENDPOINT}/package/getPackageByCity?city_id=${city_id}`);
  }
  getLocationsByBrand(brandId) {
    return this.http.get(`${AppConfig.API_ENDPOINT}/brand-location/get?brand_id=${brandId}`);
  }
  getOrdersByBrand(brandId) {
    return this.http.get(`${AppConfig.API_ENDPOINT}/order/getOrderByBrand?brand_id=${brandId}`);
  }
  getPackagesByOffer(offer_id) {
    return this.http.get(`${AppConfig.API_ENDPOINT}/offer/getOfferPackages?offer_id=${offer_id}`);
  }
  getCitiesByCountry(country, search = "") {
    return this.http.get(`${AppConfig.API_ENDPOINT}/city/get?id=${country}&search=${search}`);
  }
  getBrands(city_id = "", brand_id = "", search = "") {

    if (brand_id && brand_id !== "")
      return this.http.get(`${API_BRANDS_URL}/get?city_id=${city_id}&id=${brand_id}&search=${search}`);
    else
      return this.http.get(`${API_BRANDS_URL}/get?city_id=${city_id}&search=${search}`);

  }
  getBrandLocationsByCity(brand_id, city_id, search = "") {
    return this.http.get(`${API_BRANDS_URL}/get?id=${brand_id}&city_id=${city_id}&search=${search}`);
  }
}
