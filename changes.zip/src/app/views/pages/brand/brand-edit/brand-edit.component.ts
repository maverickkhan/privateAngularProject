
import { Component, OnInit, ChangeDetectionStrategy, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { Observable, BehaviorSubject, Subscription, of } from 'rxjs';
import { map, startWith, delay, first } from 'rxjs/operators';
import { SubheaderService, LayoutConfigService } from '../../../../core/_base/layout';
import { LayoutUtilsService, TypesUtilsService, MessageType } from '../../../../core/_base/crud';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';
import { MatChipInputEvent } from '@angular/material';
import { ENTER, COMMA } from '@angular/cdk/keycodes';
import { CategoryService } from '../../category/category.service';
import { BrandService } from '../brand.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-brand-edit',
  templateUrl: './brand-edit.component.html',
  styleUrls: ['./brand-edit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BrandEditComponent implements OnInit, OnDestroy {
  
  brand: any;
  brandId: string;
  oldBrand: any;
  selectedTab: number = 0;
  brandForm: FormGroup;
  hasFormErrors: boolean = false;
  private componentSubscriptions: Subscription;
  private headerMargin: number;
  filesToUploadForMenuImages: Array<File> = [];
  filesToUploadForBanner: Array<File> = [];
  filesToUploadForIcon: Array<File> = [];
  categories: any[];
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = true;
  separatorKeysCodes = [ENTER, COMMA];

  filterCategories: any[];


  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private typesUtilsService: TypesUtilsService,
    private brandFB: FormBuilder,
    public dialog: MatDialog,
    private subheaderService: SubheaderService,
    private layoutUtilsService: LayoutUtilsService,
    private layoutConfigService: LayoutConfigService,
    private cdr: ChangeDetectorRef,
    private cs: CategoryService,
    private bs: BrandService,
    private ed: EncryptionDecryptionService,

  ) {
  }

  ngOnInit() {
    this.getAllCategories();

    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.init();
      this.cdr.detectChanges(); // Remove this line
    }); // Remove this line
    // sticky portlet header
    window.onload = () => {
      // const style = getComputedStyle(document.getElementById('kt_header'));
      // this.headerMargin = parseInt(style.height, 0);
    };
  }
  init() {
    this.activatedRoute.params.subscribe(params => {
      const id = params['id'];
      const state = params['state'];
      if (id && state) {
        this.loadBrandFromService(id);
        // this.selectedTab = 0;
        // this.loadBrand(result);
        if (state == 'b')
          this.selectedTab = 0;
        else if (state == 'of')
          this.selectedTab = 1;
        else if (state == 'l')
          this.selectedTab = 2;
        else if (state == 'or')
          this.selectedTab = 3;
        else if (state == 's')
          this.selectedTab = 4;
        else if (state == 'f')
          this.selectedTab = 5;

      } else {
        const newBrand = {
          name: '',
          phone_number: '',
          webUrl: '',
          description: '',
          tags: [],
          categories: {
            parent: [],
            child: []
          },
          delivery_code :''  ,  
          socialMediaLinks: [],
          sort_order: 0,
          is_featured: false
        };
        this.loadBrand(newBrand);
      }
    });

  }
  getAllCategories() {
    this.cs!.getAllCategories().subscribe(res => {
      this.categories = res['data'];
      for (let i = 0; i < this.categories.length; i++) {
        this.categories[i]['_id'] = this.ed.decryptValue(this.categories[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }

  loadBrand(_brand, fromService: boolean = false) {
    if (!_brand) {
      this.goBack();
    }
    this.brand = _brand;
    if (_brand._id)
      this.brandId = _brand._id;
    this.oldBrand = Object.assign({}, _brand);
    this.initBrand();
    if (fromService) {
      this.cdr.detectChanges();
    }
  }

  loadBrandFromService(brandId) {
    this.bs.getBrandById(brandId).subscribe(res => {
      // console.log(res['data'][0])
      this.loadBrand(res['data'][0], true);
    });
  }

  ngOnDestroy() {
    if (this.componentSubscriptions) {
      this.componentSubscriptions.unsubscribe();
    }
  }


  initBrand() {
    this.createForm();
    const prefix = this.layoutConfigService.getCurrentMainRoute();

    if (!this.brand._id) {
      this.subheaderService.setBreadcrumbs([
        { title: 'Brands', page: `../${prefix}/brand/all` },
        { title: 'Create brand', page: `../${prefix}/brand/add` }
      ]);
      return;
    }
    this.subheaderService.setTitle('Edit brand');
    this.subheaderService.setBreadcrumbs([
      { title: 'Brands', page: `../${prefix}/brand/all` },
      { title: 'Edit brand', page: `../${prefix}/brand/edit`, queryParams: { id: this.brand._id } }
    ]);
  }

  createForm() {
    this.brandForm = this.brandFB.group({
      name: [this.brand.name, Validators.required],
      phone_number: [this.brand.phone_number, Validators.required],
      webUrl: [this.brand.webUrl, Validators.required],
      description: [this.brand.description],
      parent: [this.brand.categories.parent, Validators.required],
      // child: [this.brand.categories.child, Validators.required],
      menuImages: [null],
      banner: [null, Validators.required],
      icon: [null,Validators.required],
      is_featured: [this.brand.is_featured],
      sort_order: [this.brand.sort_order],
      delivery_code : [this.brand.delivery_code ,Validators.compose([Validators.required,Validators.maxLength(5),Validators.minLength(5)])]

    });
    if (this.brand._id != undefined || this.brandId != undefined) {
      // this.brandForm.get('parent').setValue([])
      // const toSelect = this.categories.find(c => c._id == 3);
      // for (let i = 0; i < this.brand.categories.parent.length; i++)
      // this.brandForm.controls['parent'].value.push(this.brand.categories.parent[i])
      this.getCategory(this.brand.categories.parent)
    }


  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  // numberOnly(event): boolean {
   
  //   const charCode = (event.which) ? event.which : event.keyCode;
  //   if ( charCode > 31 && (charCode < 48 || charCode > 57)) {
  //     return false;
  //   }
  //   return true;

  // }
  onFileChangeForMenuImages(event) {
    if (event.target.files.length > 0) {
      this.filesToUploadForMenuImages = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUploadForMenuImages);
      this.brandForm.get('menuImages').setValue(this.filesToUploadForMenuImages);

    }
  }
  onFileChangeForIcon(event) {
    if (event.target.files.length > 0) {
      this.filesToUploadForIcon = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUploadForIcon);
      this.brandForm.get('icon').setValue(this.filesToUploadForIcon);

    }
  }
  onFileChangeForBanner(event) {
    if (event.target.files.length > 0) {
      this.filesToUploadForBanner = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUploadForBanner);
      this.brandForm.get('banner').setValue(this.filesToUploadForBanner);

    }
  }
  getCategory(val) {
    if (val.length == 0)
      this.brandForm.get('child').setValue([''])
    this.filterCategories = []
    for (let i = 0; i < val.length; i++) {
      if (this.categories && this.categories.length != 0)
        this.filterCategories.push(this.getFilterCategories(this.categories, val[i])[0])
    }
  }
  getFilterCategories(opt: any[], val: string) {
    return opt.filter(item => item._id == val);
  }

  addSocialMediaLink() {
    this.brand.socialMediaLinks.push({
      name: '',
      link: ''
    })
  }
  removeSocialMediaLink(index: number) {
    this.brand.socialMediaLinks.splice(index, 1)
  }
  removeFileForMenuImages() {
    this.brandForm.get('menuImages').setValue(null);
  }
  removeFileForBanner() {
    this.brandForm.get('banner').setValue(null);
  }
  removeFileForIcon() {
    this.brandForm.get('icon').setValue(null);
  }
  addTag(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.brand.tags.push(value.trim());
    }
    if (input) {
      input.value = '';
    }
  }

  removeTag(tag: any): void {
    const index = this.brand.tags.indexOf(tag);
    if (index >= 0) {
      this.brand.tags.splice(index, 1);
    }
  }
  save() {
    console.log(this.brandForm.value);
  }

  goBack() {
    const url = `${this.layoutConfigService.getCurrentMainRoute()}/brand/all`;
    this.router.navigateByUrl(url, { relativeTo: this.activatedRoute });
  }

  refreshBrand(isNew: boolean = false, id = '') {

    let url = this.router.url;
    if (!isNew) {
      this.router.navigate([url], { relativeTo: this.activatedRoute });
      return;
    }

    url = `${this.layoutConfigService.getCurrentMainRoute()}/brand/edit/b/${id}`;
    this.router.navigateByUrl(url, { relativeTo: this.activatedRoute });
  }


  reset() {
    this.brand = Object.assign({}, this.oldBrand);
    this.createForm();
    this.hasFormErrors = false;
    this.brandForm.markAsPristine();
    this.brandForm.markAsUntouched();
    this.brandForm.updateValueAndValidity();
    this.brand.tags = [];
    this.brand.socialMediaLinks = [];
    this.filterCategories = [];
  }


  onSumbit(withBack: boolean = false) {
    this.hasFormErrors = false;
    const controls = this.brandForm.controls;
    if (this.brandForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      this.selectedTab = 0;
      return;
    }

    let editedBrand = this.prepareBrand();

    if (this.brand._id != undefined || this.brandId != undefined) {
      this.updateBrand(editedBrand, this.brand._id, withBack);
      return;
    }

    this.addBrand(editedBrand, withBack);
  }

  prepareBrand(): any {
    const controls = this.brandForm.controls;
    const _brand = {
      name: '',
      phone_number: '',
      webUrl: '',
      description: '',
      tags: [],
      categories: {
        parent: [],
        child: []
      },
      delivery_code : '',
      socialMediaLinks: [],
      sort_order: 0,
          is_featured: false
    };
    // if (this.brand._id != undefined || this.brandId != undefined)
    //   _brand["_id"] = this.brand._id;
    _brand.name = controls['name'].value;
    _brand.phone_number = controls['phone_number'].value;
    _brand.webUrl = controls['webUrl'].value;
    _brand.description = controls['description'].value;
    _brand.categories.parent = controls['parent'].value;
    _brand.sort_order = controls["sort_order"].value;
    _brand.is_featured = controls["is_featured"].value;
    _brand.delivery_code = controls['delivery_code'].value
    // _brand.categories.child = controls['child'].value;
    this.brand.categories.parent = controls['parent'].value;
    // this.brand.categories.child = controls['child'].value;
    _brand.tags = this.brand.tags;
    _brand.socialMediaLinks = this.brand.socialMediaLinks;
    console.log(_brand);
    let input = new FormData();
    const bannerFiles: Array<File> = this.filesToUploadForBanner;
    console.log(bannerFiles);
    const iconFiles: Array<File> = this.filesToUploadForIcon;
    console.log(iconFiles);
    const filesForMenuImages: Array<File> = this.filesToUploadForMenuImages;
    console.log(filesForMenuImages);


    // if (this.category._id !== undefined)
    //   input.append('_id', this.category._id);

    input.append('name', this.brandForm.get('name').value);
    input.append('phone_number', this.brandForm.get('phone_number').value);
    input.append('webUrl', this.brandForm.get('webUrl').value);
    input.append('description', this.brandForm.get('description').value);
    input.append('sort_order', this.brandForm.get('sort_order').value);
    input.append('is_featured', this.brandForm.get('is_featured').value);
    input.append('delivery_code',this.brandForm.get('delivery_code').value)
    // input.append('categories', this.brandForm.get('parent').value);
    input.append('categories', JSON.stringify(this.brand.categories));
    input.append('tags', JSON.stringify(this.brand.tags));
    input.append('socialMediaLinks', JSON.stringify(this.brand.socialMediaLinks));
    for (let i = 0; i < filesForMenuImages.length; i++) {
      input.append("menuImages", filesForMenuImages[i], filesForMenuImages[i]['name']);
    }
    for (let i = 0; i < bannerFiles.length; i++) {
      input.append("banner", bannerFiles[i], bannerFiles[i]['name']);
    }
    for (let i = 0; i < iconFiles.length; i++) {
      input.append("icon", iconFiles[i], iconFiles[i]['name']);
    }
    return input;
  }

  addBrand(_brand: any, withBack: boolean = false) {
debugger
    this.bs!.createBrand(_brand).subscribe(res => {
      debugger
      if (!res) {
        return;
      }

      if (withBack) {
        this.goBack();
      } else {
        // console.log(res)
        const message = `New brand successfully has been added.`;
        this.layoutUtilsService.showActionNotification(message, MessageType.Create, 10000, true, true);
        this.refreshBrand(true, this.ed.encryptValue(res['data']['_id']));
      }
    },
      err => {
        console.log(err)
      });
  }


  updateBrand(_brand: any, brandId: any, withBack: boolean = false) {

    this.bs!.updateBrand(_brand, brandId).subscribe(res => {
      if (!res) {
        return;
      }

      if (withBack) {
        this.goBack();
        console.log(res)
      } else {
        console.log(res)
        const message = `Brand successfully has been updated.`;
        this.layoutUtilsService.showActionNotification(message, MessageType.Update, 10000, true, true);
        this.refreshBrand(false);
      }
    },
      err => {
        console.log(err)
      });
  }


  getComponentTitle() {
    let result = 'Create Brand';
    if (!this.brand || !this.brand._id) {
      return result;
    }

    result = `Edit brand - ${this.brand.name}`;
    return result;
  }

  onAlertClose($event) {
    this.hasFormErrors = false;
  }
}

