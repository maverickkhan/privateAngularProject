
import { Component, OnInit, ElementRef, ViewChild, Input, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, Sort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { merge, Observable, of as observableOf, fromEvent, Subscription } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { debounceTime, distinctUntilChanged, tap, delay } from 'rxjs/operators';
import { QueryParamsModel, LayoutUtilsService, MessageType } from '../../../../../core/_base/crud';
import { EditBrandFacilityComponent } from '../edit-brand-facility/edit-brand-facility.component';
import { BrandService } from '../../brand.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-brand-facilities',
  templateUrl: './brand-facilities.component.html',
  styleUrls: ['./brand-facilities.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BrandFacilitiesComponent implements OnInit, OnDestroy {
  @Input() brandId: string;
  dataSource = new MatTableDataSource();
  displayedColumns = ['no', 'facility_name', 'actions'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('searchInput') searchInput: ElementRef;
  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;
  pageSize = 10;
  pageSizeOptions = [5, 10, 25, 100];
  selection = new SelectionModel<any>(true, []);
  brandSpecialitiesResult: any[] = [];

  private componentSubscriptions: Subscription;


  constructor(
    public dialog: MatDialog,
    public bs: BrandService,
    private layoutUtilsService: LayoutUtilsService) { }


  ngOnInit() {

    this.Init(this.brandId);


  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy() {
    if (this.componentSubscriptions) {
      this.componentSubscriptions.unsubscribe();
    }
  }


  Init(brandId: string) {

    this.isLoadingResults = true;
    this.bs!.getBrandById(brandId).subscribe(res => {
      this.resultsLength = res['data'][0].facilities.length;
      this.brandSpecialitiesResult = res['data'][0].facilities;
      this.dataSource.data = res['data'][0].facilities;
      this.isLoadingResults = false;
      this.isRateLimitReached = false;
    },
      err => {
        console.log(err)
        this.isLoadingResults = false;
        this.isRateLimitReached = true;
      })
  }



  deleteSpec(_item: any) {
    const _title: string = 'Facility Delete';
    const _description: string = 'Are you sure to permanently delete this Facility?';
    const _waitDesciption: string = 'Facility is deleting...';
    const _deleteMessage = `Facility has been deleted`;

    const dialogRef = this.layoutUtilsService.deleteElement(_title, _description, _waitDesciption);
    dialogRef.afterClosed().subscribe(res => {
      if (!res) {
        return;
      }
      this.bs.deleteBrandFacility(_item, this.brandId).subscribe((res) => {
        if (res['success'] == true) {
          this.layoutUtilsService.showActionNotification(_deleteMessage, MessageType.Delete);
          this.Init(this.brandId);
        }
        else
          this.layoutUtilsService.showActionNotification(res['message'], MessageType.Delete);
      });

      // this.loadSpecsList();
    });
  }


  addSpec() {
    // let newSpec = {
    //   facility_name: ''
    // }
    const dialogRef = this.dialog.open(EditBrandFacilityComponent, {
      data: {
        name: '',
        isNew: true
      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res.isUpdated) {

        // newSpec.facility_name = res.spec;
        this.bs.addBrandFacility(res['spec'], this.brandId).subscribe((res) => {
          if (res['success'] == true) {
            const saveMessage = `Facility has been created`;
            this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Create, 10000, true, true);
            this.Init(this.brandId);
          }
          else
            this.layoutUtilsService.showActionNotification(res['message'], MessageType.Create, 10000, true, true);
        });


      }
    });
  }


  editSpec(item: any) {
    const _item = Object.assign({}, item);
    const dialogRef = this.dialog.open(EditBrandFacilityComponent, {
      data: {
        specId: _item.specId,
        value: _item.value,
        isNew: false
      },
      width: '450px'
    });
    dialogRef.afterClosed().subscribe(res => {
      if (res && res.isUpdated) {
        _item._FacilityName = res._FacilityName;
        _item.specId = res.specId;
        _item.value = res.value;

        const saveMessage = `Facility has been updated`;
        this.layoutUtilsService.showActionNotification(saveMessage, MessageType.Update, 10000, true, true);
      }
    });
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }
  sortData(sort: Sort) {
    const data = this.brandSpecialitiesResult.slice();
    if (!sort.active || sort.direction == '') {
      this.dataSource.data = data;
      return;
    }
    if (sort.active == "no") {
      this.dataSource.data.reverse();
      return;
    }
    this.dataSource.data = data.sort((a, b) => {
      let isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'facility_name': return compare(a.facility_name, b.facility_name, isAsc);
        default: return 0;
      }
    });
  }
}
function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

