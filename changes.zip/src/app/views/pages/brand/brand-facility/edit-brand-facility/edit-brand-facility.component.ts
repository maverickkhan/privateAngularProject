import { ChangeDetectorRef } from '@angular/core';
import { Component, Inject, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'kt-edit-brand-facility',
  templateUrl: './edit-brand-facility.component.html',
  styleUrls: ['./edit-brand-facility.component.scss']
})
export class EditBrandFacilityComponent implements OnInit {


  facilityEditForm: FormGroup;
  viewLoading: boolean = true;
  loadingAfterSubmit: boolean = false;
  filesToUploadForIcon: Array<File> = [];

  constructor(
    public dialogRef: MatDialogRef<EditBrandFacilityComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.initfacilityForm();
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false; // Remove this line
      this.cdr.detectChanges(); // Remove this line
    }); // Remove this line
  }


  initfacilityForm() {
    const specName: string = this.data.name;
    this.facilityEditForm = this.fb.group({
      name: [specName, [Validators.required]],
      icon: [null, [Validators.required]]
    });
  }


  onNoClick(): void {
    this.dialogRef.close({ isUpdated: false });
  }
  onFileChangeForIcon(event) {
    if (event.target.files.length > 0) {
      this.filesToUploadForIcon = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUploadForIcon);
      this.facilityEditForm.get('icon').setValue(this.filesToUploadForIcon);

    }
  }
  removeFileForIcon() {
    this.facilityEditForm.get('icon').setValue(null);
  }

  save() {
    const controls = this.facilityEditForm.controls;

    if (this.facilityEditForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );
      return;
    }

    this.loadingAfterSubmit = true;
    this.viewLoading = true;

    // const specName = controls['name'].value;
    let input = new FormData();
    const iconFiles: Array<File> = this.filesToUploadForIcon;
    console.log(iconFiles);
    input.append('facility_name', this.facilityEditForm.get('name').value);
    for (let i = 0; i < iconFiles.length; i++) {
      input.append("facility_icon", iconFiles[i], iconFiles[i]['name']);
    }
    /* Server loading imitation. Remove this on real code */
    of(undefined).pipe(delay(1000)).subscribe(() => { // Remove this line
      this.viewLoading = false;
      this.closeDialog(input);
    }); // Remove this line
  }


  closeDialog(spec) {
    this.dialogRef.close({
      isUpdated: true,
      spec: spec
    });
  }


  isControlHasError(controlName: string, validationType: string): boolean {
    const control = this.facilityEditForm.controls[controlName];
    if (!control) {
      return false;
    }

    const result = control.hasError(validationType) && (control.dirty || control.touched);
    return result;
  }

}
