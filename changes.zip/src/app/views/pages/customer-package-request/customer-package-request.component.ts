import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-customer-package-request',
  templateUrl: './customer-package-request.component.html',
  styleUrls: ['./customer-package-request.component.scss']
})
export class CustomerPackageRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
