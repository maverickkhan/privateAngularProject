import { TestBed } from '@angular/core/testing';

import { CustomerPackageRequestService } from './customer-package-request.service';

describe('CustomerPackageRequestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomerPackageRequestService = TestBed.get(CustomerPackageRequestService);
    expect(service).toBeTruthy();
  });
});
