import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPackageRequestsComponent } from './customer-package-requests.component';

describe('CustomerPackageRequestsComponent', () => {
  let component: CustomerPackageRequestsComponent;
  let fixture: ComponentFixture<CustomerPackageRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerPackageRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPackageRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
