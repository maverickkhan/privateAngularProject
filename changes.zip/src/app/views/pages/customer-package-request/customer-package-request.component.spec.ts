import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPackageRequestComponent } from './customer-package-request.component';

describe('CustomerPackageRequestComponent', () => {
  let component: CustomerPackageRequestComponent;
  let fixture: ComponentFixture<CustomerPackageRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerPackageRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPackageRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
