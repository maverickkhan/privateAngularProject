import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_CUSTOMER_PACKAGE_REQUESTS_URL = `${AppConfig.API_ENDPOINT}/customer-package-request`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})

export class CustomerPackageRequestService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  getAllCustomerPackageRequests() {
    return this.http.get(`${API_CUSTOMER_PACKAGE_REQUESTS_URL}/get`);
  }
}
