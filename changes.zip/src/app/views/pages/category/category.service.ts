// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
// Models
import { AppConfig } from '../../../core/_base/crud/utils/app-config';

const API_CATEGORIES_URL = `${AppConfig.API_ENDPOINT}/category`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createCategory(category: any) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.post(`${API_CATEGORIES_URL}/create`, category, { headers: httpHeaders });
  }

  getAllCategories() {
    return this.http.get(`${API_CATEGORIES_URL}/get`);
  }

  getCategoryById(categoryId) {
    return this.http.get(API_CATEGORIES_URL + `/${categoryId}`);
  }
 
  updateCategory(category: any, categoryId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_CATEGORIES_URL}/update/${categoryId}`, category, { headers: httpHeader });
  }

  deleteCategory(categoryId: string) {
    const url = `${API_CATEGORIES_URL}/remove/${categoryId}`;
    return this.http.delete(url);
  }

}
