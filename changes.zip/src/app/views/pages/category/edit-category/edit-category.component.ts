
import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class EditCategoryComponent implements OnInit, OnDestroy {

  category: any;
  categoryForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;
  filesToUpload: Array<File> = [];
  color: string = '';


  constructor(public dialogRef: MatDialogRef<EditCategoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.category = this.data.category;
    this.createForm();
  }


  ngOnDestroy() {

  }
  getHex(value) {
    // console.log(value)
    this.categoryForm.controls['bgcolor'].setValue(value);

  }
  onFileChange(event) {
    if (event.target.files.length > 0) {
      this.filesToUpload = <Array<File>>event.target.files;
      // let file = event.target.files[0];
      console.log(this.filesToUpload);
      this.categoryForm.get('icon').setValue(this.filesToUpload);

    }


  }
  removeFile() {
    this.categoryForm.get('icon').setValue(null);
  }
  createForm() {
    // if (this.category._id !== undefined) {
    this.categoryForm = this.fb.group({
      name: [this.category.name, Validators.required],
      bgcolor: [this.category.bgcolor, Validators.required],
      icon: [null, Validators.required],
      sort_order :[this.category.sort_order, Validators.required]

    });
    // }
    // else {
    // this.categoryForm = this.fb.group({
    //   name: [this.category.name, Validators.required],
    //   bgcolor: [this.category.bgcolor, Validators.required],
    //   icon: [this.category.icon, Validators.required],

    // });
    // }

  }

  getTitle(): string {
    if (this.category._id !== undefined) {
      return `Edit Category '${this.category.name}'`;
    }

    return 'New Category';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.categoryForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareCategory() {
    // const controls = this.categoryForm.controls;
    // const _category = {
    //   _id: '',
    //   name: '',
    //   bgcolor: '',
    //   icon: ''

    // };
    // _category._id = this.category._id;
    // _category.name = controls['name'].value;
    // _category.bgcolor = controls['bgcolor'].value;
    // _category.icon = controls['icon'].value;
    let input = new FormData();
    const files: Array<File> = this.filesToUpload;
    console.log(files);

    for (let i = 0; i < files.length; i++) {
      input.append("icon", files[i], files[i]['name']);
    }
    // if (this.category._id !== undefined)
    //   input.append('_id', this.category._id);

    input.append('name', this.categoryForm.get('name').value);
    input.append('bgcolor', this.categoryForm.get('bgcolor').value);
    input.append('sort_order',this.categoryForm.get('sort_order').value)
    // input.append('icon', this.categoryForm.get('icon').value);
    return input;

    // return _category;
  }


  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.categoryForm.controls;

    if (this.categoryForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedCategory = this.prepareCategory();
    if (this.category._id !== undefined) {
      this.updateCategory(editedCategory);
    } else {
      this.createCategory(editedCategory);
    }
  }

  updateCategory(_category) {
    this.dialogRef.close({ _category, isEdit: true })
  }

  createCategory(_category) {
    this.dialogRef.close({ _category, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }
}

