import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-area',
  templateUrl: './area.component.html',
  styleUrls: ['./area.component.scss']
})
export class AreaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
