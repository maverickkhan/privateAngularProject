import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';

@Component({
  selector: 'kt-edit-area',
  templateUrl: './edit-area.component.html',
  styleUrls: ['./edit-area.component.scss']
})
export class EditAreaComponent implements OnInit {


  area: any;
  areaForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;
  filesToUpload: Array<File> = [];


  constructor(public dialogRef: MatDialogRef<EditAreaComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.area = this.data.area;
    this.createForm();
  }


  ngOnDestroy() {
 
  }


  createForm() {
    this.areaForm = this.fb.group({
      area_name: [this.area.area_name, Validators.required],
    });
  }

  getTitle(): string {
    if (this.area._id !== undefined) {
      return `Edit area '${this.area.area_name}'`;
    }

    return 'New area';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.areaForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareArea() {
    const controls = this.areaForm.controls;
    const _area = {
      area_name: '',

    };
    if (this.area._id !== undefined)
      _area['area_id'] = this.area._id;
    _area.area_name = controls['area_name'].value;


    return _area;
  }

  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.areaForm.controls;

    if (this.areaForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedArea = this.prepareArea();
    if (this.area._id !== undefined) {
      this.updateArea(editedArea);
    } else {
      this.createArea(editedArea);
    }
  }

  updateArea(_area) {
    this.dialogRef.close({ _area, isEdit: true })
  }

  createArea(_area) {
    this.dialogRef.close({ _area, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }


}
