// Angular
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// RxJS
import { Observable } from 'rxjs';
// CRUD
import { HttpUtilsService, QueryParamsModel, QueryResultsModel } from '../../../core/_base/crud';
import { AppConfig } from '../../../core/_base/crud/utils/app-config';
// Models
const API_AREAS_URL = `${AppConfig.API_ENDPOINT}/area`;

// @Injectable()
@Injectable({
  providedIn: 'root'
})
export class AreaService {

  constructor(private http: HttpClient, private httpUtils: HttpUtilsService) { }

  createArea(area: any, countryId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_AREAS_URL}/create/${countryId}`, area, { headers: httpHeaders });
  }

  getAllAreas(countryId: string = '', cityId: string = '', search: string = '') {
    return this.http.get(`${API_AREAS_URL}/get?search=${search}&id=${countryId}&city_id=${cityId}`);
  }
  getAreaById(areaId) {
    return this.http.get(API_AREAS_URL + `/${areaId}`);
  }

  updateArea(area: any, areaId) {
    const httpHeader = this.httpUtils.getHTTPHeaders();
    return this.http.put(`${API_AREAS_URL}/update/${areaId}`, area, { headers: httpHeader });
  }

  deleteArea(area: any, countryId: string, cityId: string) {
    const httpHeaders = this.httpUtils.getHTTPHeaders();
    const options = {
      headers: httpHeaders,
      body: {
        area_id: area['_id'],
        city_id: cityId
      },
    };
    const url = `${API_AREAS_URL}/remove/${countryId}`;
    return this.http.delete(url, options);
  }
}
