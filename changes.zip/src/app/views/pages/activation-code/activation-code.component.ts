import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-activation-code',
  templateUrl: './activation-code.component.html',
  styleUrls: ['./activation-code.component.scss']
})
export class ActivationCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
