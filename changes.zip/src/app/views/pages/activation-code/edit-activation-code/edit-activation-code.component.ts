import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TypesUtilsService } from '../../../../core/_base/crud';
import { PackageService } from '../../package/package.service';
import { EncryptionDecryptionService } from '../../../../core/_base/layout/services/encryption-decryption.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'kt-edit-activation-code',
  templateUrl: './edit-activation-code.component.html',
  styleUrls: ['./edit-activation-code.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})

export class EditActivationCodeComponent implements OnInit {

  activationCode: any;
  activationCodeForm: FormGroup;
  hasFormErrors: boolean = false;
  viewLoading: boolean = false;
  packages: any[] = [];

  constructor(public dialogRef: MatDialogRef<EditActivationCodeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private ps: PackageService,
    private ed: EncryptionDecryptionService,
    private typesUtilsService: TypesUtilsService) {
  }


  ngOnInit() {
    this.activationCode = this.data.activationCode;
    this.getAllPackages();
    this.createForm();
  }

  ngOnDestroy() {

  }

  createForm() {
    this.activationCodeForm = this.fb.group({
      type: [this.activationCode.type, Validators.required],
      code_count: [this.activationCode.code_count, Validators.required],
      validity: [this.activationCode.validity, Validators.required],
      package_id: [this.activationCode.package_id, Validators.required],
    });
  }
  getAllPackages() {
    this.ps!.getAllPackages().subscribe(res => {
      this.packages = res['data'];
      console.log(this.packages)
      for (let i = 0; i < this.packages.length; i++) {
        this.packages[i]['_id'] = this.ed.decryptValue(this.packages[i]['_id'])
      }
    },
      err => {
        console.log(err)
      })
  }
  compareByReference(o1: any, o2: any) {
    return o1 === o2;
  }
  getTitle(): string {
    if (this.activationCode._id !== undefined) {
      return `Edit Activation Codes '${this.activationCode.name}'`;
    }
    return 'Generate Activation Codes';
  }


  isControlInvalid(controlName: string): boolean {
    const control = this.activationCodeForm.controls[controlName];
    const result = control.invalid && control.touched;
    return result;
  }


  prepareActivationCodes() {
    const controls = this.activationCodeForm.controls;
    const _activationCode = {
      // _id: '',
      type: '',
      code_count: '',
      validity: '',
      package_id: ''

    };
    // _activationCode._id = this.activationCode._id;
    _activationCode.type = controls['type'].value;
    _activationCode.code_count = controls['code_count'].value;
    _activationCode.validity = controls['validity'].value;
    _activationCode.package_id = controls['package_id'].value;

    return _activationCode;
  }


  onSubmit() {
    this.hasFormErrors = false;
    const controls = this.activationCodeForm.controls;

    if (this.activationCodeForm.invalid) {
      Object.keys(controls).forEach(controlName =>
        controls[controlName].markAsTouched()
      );

      this.hasFormErrors = true;
      return;
    }

    const editedActivationCodes = this.prepareActivationCodes();
    if (this.activationCode._id !== undefined) {
      this.updateActivationCodes(editedActivationCodes);
    } else {
      this.createActivationCodes(editedActivationCodes);
    }
  }

  updateActivationCodes(_activationCode) {
    this.dialogRef.close({ _activationCode, isEdit: true })
  }

  createActivationCodes(_activationCode) {
    this.dialogRef.close({ _activationCode, isEdit: false });
  }
  onAlertClose($event) {
    this.hasFormErrors = false;
  }

}
