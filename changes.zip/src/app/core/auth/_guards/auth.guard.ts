// Angular
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
// RxJS
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
// NGRX
import { select, Store } from '@ngrx/store';
// Auth reducers and selectors
import { AppState } from '../../../core/reducers/';
import { isLoggedIn } from '../_selectors/auth.selectors';
import { CookieService } from 'angular2-cookie/services';
// import { tokenNotExpired } from 'angular2-jwt';

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private store: Store<AppState>, private router: Router, private _cookieService: CookieService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        // if (this._authservice.getToken() && this._authservice.isAuthenticated()) {
        if (this.getToken()) {
            return true;
        }
        // not logged in so redirect to login page
        this.router.navigate(['/auth/login'], { queryParams: { returnUrl: state.url } });

        return false;
    }
    public getToken(): string {
        return this._cookieService.get('token');
    }

    // public isAuthenticated(): boolean {
    //     return tokenNotExpired('id_token');
    // }

}
