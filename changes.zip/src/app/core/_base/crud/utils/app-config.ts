export class AppConfig {

    // public static API_ENDPOINT = 'http://137.59.227.59:9000/api';
    // // public static IMAGE_ENDPOINT = 'http://137.59.227.59:9000';
    // public static API_ENDPOINT = 'https://165.227.69.207:9001/api';
    // public static IMAGE_ENDPOINT = 'https://165.227.69.207:9001';
        public static API_ENDPOINT = 'https://bigbang.pk:8000/api';
    public static IMAGE_ENDPOINT = 'https://bigbang.pk:8000';

    // public static API_ENDPOINT = 'http://192.168.18.14:5002/api';
    public static encryption_key = "@big-bang123";
    public static country_id = "5d6f8cf82c94f35475f82401";

}