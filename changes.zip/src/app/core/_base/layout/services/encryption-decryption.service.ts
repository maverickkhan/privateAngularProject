import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { AppConfig } from '../../crud/utils/app-config';


@Injectable({
  providedIn: 'root'
})
export class EncryptionDecryptionService {

  enc_key = AppConfig.encryption_key;

  constructor() { }

  encryptValue(plaintext) {

    let ciphertext = CryptoJS.AES.encrypt(plaintext, this.enc_key).toString();
    let base64 = CryptoJS.enc.Base64.parse(ciphertext);
    let eHex = base64.toString(CryptoJS.enc.Hex);
    return eHex;

  }

  decryptValue(ciphertext) {

    var reb64 = CryptoJS.enc.Hex.parse(ciphertext);
    var bytes = reb64.toString(CryptoJS.enc.Base64);
    var decrypt = CryptoJS.AES.decrypt(bytes, this.enc_key);
    var plaintext = decrypt.toString(CryptoJS.enc.Utf8);
    return plaintext;
    


  }


  encryptObject(plainObj) {

    var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(plainObj), this.enc_key).toString();
    let base64 = CryptoJS.enc.Base64.parse(ciphertext);
    let eHex = base64.toString(CryptoJS.enc.Hex);
    return eHex;
  }

  decryptObject(cipherObj) {

    var reb64 = CryptoJS.enc.Hex.parse(cipherObj);
    var bytes = reb64.toString(CryptoJS.enc.Base64);
    var decrypt = CryptoJS.AES.decrypt(bytes, this.enc_key);
    var plainObj = decrypt.toString(CryptoJS.enc.Utf8);
    return JSON.parse(plainObj);

  }

}
