/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import BrandLocation from '../models/brandLocation';
import Brand from '../models/brand';
import Country from '../models/country';
import Category from '../models/category';
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import moment from 'moment';
import _ from 'underscore'
import { decryptValue } from '../utilites/encryption-module';
const lodash = require('lodash');
function getQueryParams(queryParams) {
    let findParams = {};
    // console.log(queryParams,"hello")
    findParams = {
        'status.is_deleted': false,
    };
    if(queryParams.brand_id){
        findParams = {'brand_id' : queryParams.brand_id }
    }
    // console.log(queryParams.brand_id);
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'address': { $regex: queryParams.search, $options: 'i' } },
                // { 'brand_id': { $regex: queryParams.id, $options: 'i' } },
                // { 'location.latitude': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    // if (queryParams.latestbrandLocations != undefined && queryParams.latestbrandLocations != "") {
    //     findParams['timestamps.created_at'] = { $gte: new Date() - 1000 * 3600 * 24 * queryParams.latestbrandLocations, $lt: new Date() };
    // }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    // if (queryParams.id != undefined && queryParams.id != "") {
    //     findParams['_id'] = queryParams.id || "";
    // }
    return findParams;
}
function minutesToStandard(model) {
    function minutesToStandardTime(minutes) {
        var military_time = Math.floor(minutes / 60) + ':' + minutes % 60
        var mTime = moment(military_time, "hh:m")
        var standardTime = moment(mTime).format('LT');
        // console.log(standardTime.split(":")[0],standardTime.split(":")[1].split(" ")[0],standardTime.split(":")[1].split(" ")[1])
        // console.log(military_time,'--',mTime,'--',standardTime)
        // console.log(moment(mTime).endOf('hour').fromNow());
        // console.log(moment(mTime).startOf('hour').fromNow());
        // console.log(minutesToStandardTime(standardTimetoMinutes('9:30 PM')))
        return standardTime;
    }
    // console.log(model[0]['location'][0]['timings']);
    lodash.forEach(model, (val) => {
        // lodash.forEach(val.location, (val1) => {
        lodash.forEach(val.timings, (val2) => {
            val2.open = minutesToStandardTime(val2.open)
            val2.close = minutesToStandardTime(val2.close)
        })
        // });
    });
    return model;
}
function standardTimetoMinutes(standardTime) {
    //coverting to military timings
    var hours = Number(standardTime.match(/^(\d+)/)[1]);
    var minutes = Number(standardTime.match(/:(\d+)/)[1]);
    var AMPM = standardTime.match(/\s(.*)$/)[1];
    if (AMPM == "PM" && hours < 12) hours = hours + 12;
    if (AMPM == "AM" && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = "0" + sHours;
    if (minutes < 10) sMinutes = "0" + sMinutes;
    //coverted to military timings
    // var militarTime = sHours + ":" + sMinutes;
    //coverting to minutes
    var hms = sHours + ":" + sMinutes;   // your input string
    var a = hms.split(':'); // split it at the colons
    // Hours are worth 60 minutes.
    var minutes = (+a[0]) * 60 + (+a[1]);
    //coverted to minutes
    // console.log(minutes);
    return minutes;
}
export function getNearBy(req, res) {
    try {
        BrandLocation.getNearByLocation(req.query.lng, req.query.lat, req.query.maxDistance, req.query.minDistance, 100, (err, nearlocation) => {
            if (err) {
                generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
            }
            else {
                generateResponse(true, 'Success', nearlocation, res, ['_id'], ['offer', 'terms_and_condition']);
            }
        })
    }
    catch (err) {
        console.log(err)
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}
export function get(req, res) {
    try {
        var queryString = req.query;
        // console.log(req.query.id)
        searchQuery(BrandLocation, function (err, brandLocation) {
            if (err) {
                // console.log(err)
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', err, res, [], []);
            } else {
                if (brandLocation.length > 0) {
                    minutesToStandard(brandLocation);
                    generateResponse(true, 'Success', brandLocation, res, ['_id'], []);
                }
                else {
                    generateResponse(false, 'Record not found.', brandLocation, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body != undefined && body != null) {

            let data = {
                brand_id: body.brand_id,
                area_id: body.area_id,
                address: body.address,
                code: body.code,
                geometry: {
                    coordinates: [body.lng, body.lat]
                },
                timings: {
                    mon: {
                        open: body.mondayOpenTimings,
                        close: body.mondayCloseTimings,
                    },
                    tue: {
                        open: body.tuesdayOpenTimings,
                        close: body.tuesdayCloseTimings,
                    },
                    wed: {
                        open: body.wednesdayOpenTimings,
                        close: body.wednesdayCloseTimings,
                    },
                    thu: {
                        open: body.thursdayOpenTimings,
                        close: body.thursdayCloseTimings,
                    },
                    fri: {
                        open: body.fridayOpenTimings,
                        close: body.fridayCloseTimings,
                    },
                    sat: {
                        open: body.saturdayOpenTimings,
                        close: body.saturdayCloseTimings,
                    },
                    sun: {
                        open: body.sundayOpenTimings,
                        close: body.sundayCloseTimings,
                    }
                }
            }
            lodash.forEach(data.timings, (val1) => {
                val1.open = standardTimetoMinutes(val1.open)
                val1.close = standardTimetoMinutes(val1.close)
            });
            Brand.get({
                _id: mongoose.Types.ObjectId(body.brand_id)
            }, (err, brand) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (brand.length > 0) {
                        if (body.code != undefined) {
                            if (body.code.length == 5) {
                                Country.getRecord(
                                    "cities.areas._id",
                                    mongoose.Types.ObjectId(body.area_id)
                                    , (err, country) => {
                                        if (err) {
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', err, res, [], []);
                                        } else {

                                            var temp_count = 0

                                            lodash.forEach(country, (val) => {
                                                data.country_id = val._id
                                                if (val.status.is_deleted == false) {
                                                    lodash.forEach(val.cities, (val1) => {
                                                        if (val1.status.is_deleted == false) {
                                                            lodash.forEach(val1.areas, (val2) => {
                                                                if (val2.status.is_deleted == false && val2._id.toString() === body.area_id) {
                                                                    data.city_id = val1._id
                                                                    temp_count++;

                                                                }
                                                            });
                                                        }
                                                    });
                                                }
                                            });
                                            if (country.length > 0 && (temp_count == country.length)) {
                                                BrandLocation.create(data,
                                                    (err, brandLocation) => {
                                                        if (err) {
                                                            console.log(err);
                                                            var errors = {};
                                                            if (err.name == "ValidationError") {
                                                                for (var i in err.errors) {
                                                                    errors[i] = err.errors[i].message;
                                                                }
                                                            } else {
                                                                errors[i] = err.errmsg;
                                                            }
                                                            generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                                        } else {
                                                            generateResponse(true, 'Created Successfully', brandLocation, res, [], []);
                                                        }
                                                    })


                                            } else {
                                                var errors = {
                                                    error: "Area does not exist"
                                                };
                                                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                            }
                                        }
                                    });
                            }
                            else {
                                generateResponse(false, 'Code length should be 5', [], res, [], []);
                            }
                        }

                        else {
                            generateResponse(false, 'One or more field is reqiured', [], res, [], []);
                        }

                    }
                    else {
                        generateResponse(false, 'Record not found', [], res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);

            if (body != undefined && body != null) {
                let data = {
                    brand_id: body.brand_id,
                    area_id: body.area_id,
                    address: body.address,
                    code:body.code,
                    geometry: {
                        coordinates: [body.lng, body.lat]
                    },
                    timings: {
                        mon: {
                            open: body.mondayOpenTimings,
                            close: body.mondayCloseTimings,
                        },
                        tue: {
                            open: body.tuesdayOpenTimings,
                            close: body.tuesdayCloseTimings,
                        },
                        wed: {
                            open: body.wednesdayOpenTimings,
                            close: body.wednesdayCloseTimings,
                        },
                        thu: {
                            open: body.thursdayOpenTimings,
                            close: body.thursdayCloseTimings,
                        },
                        fri: {
                            open: body.fridayOpenTimings,
                            close: body.fridayCloseTimings,
                        },
                        sat: {
                            open: body.saturdayOpenTimings,
                            close: body.saturdayCloseTimings,
                        },
                        sun: {
                            open: body.sundayOpenTimings,
                            close: body.sundayCloseTimings,
                        }
                    }
                }
                if (data.timings != "") {
                    lodash.forEach(data.timings, (val1) => {
                        val1.open = standardTimetoMinutes(val1.open)
                        val1.close = standardTimetoMinutes(val1.close)
                    });
                    BrandLocation.get({
                        _id: req.params.id
                    }, (err, brandLocation) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        }
                        else {
                            if (brandLocation.length > 0) {
                                Brand.get({
                                    _id: mongoose.Types.ObjectId(body.brand_id)
                                },
                                    (err, brand) => {
                                        if (err) {
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                                        }
                                        else {
                                            if (brand.length > 0) {
                                                if (body.code != undefined) {
                                                    if (body.code.length == 5) {
                                                        BrandLocation.get({
                                                            // brand_id: mongoose.Types.ObjectId(body.brand_id),
                                                            code: body.code
                                                        }, (err, brandLocation) => {
                                                            if (err) {
                                                                var errors = err.errmsg;
                                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                            }
                                                            else {
                                                                // if(brandLocation[0].brand_id == mongoose.Types.ObjectId(body.brand_id)  || brandLocation.length == 0){
                                                                    Country.getRecord(
                                                                        "cities.areas._id",
                                                                        mongoose.Types.ObjectId(body.area_id)
                                                                        , (err, country) => {
                                                                            if (err) {
                                                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', err, res, [], []);
                                                                            }
                                                                            else {
                                                                                var temp_count = 0
                                                                                lodash.forEach(country, (val) => {
                                                                                    data.country_id = val._id
                                                                                    if (val.status.is_deleted == false) {
                                                                                        lodash.forEach(val.cities, (val1) => {
                                                                                            if (val1.status.is_deleted == false) {
                                                                                                lodash.forEach(val1.areas, (val2) => {
                                                                                                    if (val2.status.is_deleted == false && val2._id == body.area_id) {
                                                                                                        data.city_id = val1._id
                                                                                                        temp_count++;
                                                                                                    }
                                                                                                });
                                                                                            }
                                                                                        });
                                                                                    }
                                                                                });
                                                                                // console.log(temp_count);
                                                                                // return;
                                                                                if (country.length > 0 && (temp_count == country.length)) {
                                                                                    BrandLocation.update(req.params.id,
                                                                                        data,
                                                                                        (err, brandLocation) => {
                                                                                            if (err) {
                                                                                                console.log(err);
                                                                                                var errors = {};
                                                                                                if (err.name == "ValidationError") {
                                                                                                    for (var i in err.errors) {
                                                                                                        errors[i] = err.errors[i].message;
                                                                                                    }
                                                                                                } else {
                                                                                                    errors[i] = err.errmsg;
                                                                                                }
                                                                                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                                                                            }
                                                                                            else {
                                                                                                generateResponse(true, "Updated Successfully", brandLocation, res, [], []);
                                                                                            }
                                                                                        })
                                                                                }
                                                                                else {
                                                                                    var errors = {
                                                                                        error: "Area does not exist"
                                                                                    };
                                                                                    generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                                                                }
                                                                            }
                                                                        });
                                                                // }
                                                                // else {
                                                                //     generateResponse(false, 'Code Already Exist', [], res, [], []);
                                                                // }
                                                            }
                                                        })
                                                    }
                                                    else {
                                                        generateResponse(false, 'Code length should be 5', [], res, [], []);
                                                    }
                                                }
                                                else {
                                                    generateResponse(false, 'One or more field is reqiured', [], res, [], []);
                                                }

                                            }
                                            else {
                                                generateResponse(false, 'Record not found', [], res, [], []);
                                            }
                                        }
                                    })
                            }
                            else {
                                generateResponse(false, 'Record not found', [], res, [], []);
                            }
                        }
                    });
                }
                else {
                    var errors = {
                        error: "One or more field reqiured"
                    };
                    generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                }
            }
            else {
                generateResponse(false, 'aUnable to process your request, Please retry in few minutes', [], res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'aUnable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            BrandLocation.get({
                _id: req.params.id
            }, (err, brandLocation) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (brandLocation.length > 0) {
                        BrandLocation.remove(req.params.id, (err, update) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            else {
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

module.exports.globalSearch = function (text, lng, lat, flag, sort = {},city_id, callback) {
    // Brand.dropIndex("tags_text_name_text_description_text_offer.tags_text_offer.title_text_offer.offer_description_text")
    // console.log('here')
    // Brand.index({"tags":"text","name":"text","description":"text","offer.tags":"text","offer.title":"text","offer.offer_description":"text"},callback)
    // return;
    // console.log(lng ,lat,(sort == undefined));

    // console.log((lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort == null || sort == undefined));
    // return;
    console.log(text)
    if (flag == true) {
        if ((text != undefined || text != null) && (sort != null || sort != undefined)) {
            Brand.find({ $text: { $search: text } }, { score: { $meta: "textScore" } }, callback).sort(sort);
        }

        else if ((text == undefined || text == null) && (lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort != null || sort != undefined)) {
            BrandLocation.aggregate([{
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
                    spherical: true,
                    maxDistance: 100000,
                    minDistance: 0,
                    distanceField: "dist"
                }
            }
            // ,,{ $unwind: "$brand" }
                // ,{
                //     $match : { "city_id" : mongoose.Types.ObjectId(city_id)}
                // }
                // ,{ $unwind: "$location" }
                // ,{ $limit: parseInt(limit) }
            ], callback);
        }
        else if ((text == undefined || text == null) && (sort != null || sort != undefined)) {

            Brand.find({}, callback).sort(sort)
        }
    }
    else {
        if (flag == false) {
            if (text != undefined || text != null && (sort != null || sort != undefined)) {
                Brand.find({
                    "$or": [
                        { name: { $regex: text, $options: 'i' } }
                        , { description: { $regex: text, $options: 'i' } }
                        , { tags: { $regex: text, $options: 'i' } }
                        , { "offer.title": { $regex: text, $options: 'i' } }
                        , { "offer.offer_description": { $regex: text, $options: 'i' } }
                        , { "offer.tags": { $regex: text, $options: 'i' } }

                    ]
                }, callback).sort(sort);
            }
        }

    }

};
