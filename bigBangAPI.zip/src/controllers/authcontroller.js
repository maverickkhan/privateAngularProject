/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hashSync, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import Auth from '../models/auth';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
export function login(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            Auth.get({
                email: body.email
            }, (err, auth) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (auth.length > 0) {
                        var auth = auth[0];
                        compare(body.password, auth.password).then(valid => {
                            if (valid) {
                                let payload = {
                                    first_name: auth.first_name,
                                    last_name: auth.last_name,
                                    email: auth.email,
                                    role_id: auth.role_id
                                };
                                let token = sign({ payload }, `${config.app['jwtsecret']}`, { expiresIn: "1y" });
                                let userData = [{
                                    auth: payload,
                                    token: token
                                }];
                                var tokendata = {
                                    token : token
                                }
                                Auth.tokenupdate(auth._id, tokendata, (err, update) => {
                                    if (err) {
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                    }
                                    else {
                                        generateResponse(true, 'Successfully Logged in', userData, res, [], []);
                                    }
                                });

                            } else {
                                generateResponse(false, "Email or password incorrect", [], res, [], []);
                            }
                        });
                    } else {
                        generateResponse(false, "Record not found", [], res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
    }
}
export function register(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            Auth.get({
                email: body.email
            }, (err, auth) => {
                // console.log(auth)
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (auth.length == 0) {
                        if (body.confirm_password != body.password) {
                            var errors = {
                                password: "Password doen't match"
                            };
                            generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                        } else {
                            if (body.password == null || body.password == undefined) {
                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                            }
                            else {
                                body.password = hashSync(body.password, 10);
                                Auth.add(body, function (err, auth) {
                                    if (err) {
                                        var errors = {};
                                        if (err.name == "ValidationError") {
                                            for (var i in err.errors) {
                                                errors[i] = err.errors[i].message;
                                            }
                                        } else {
                                            errors[i] = err.errmsg;
                                        }
                                        generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                    } else {
                                        generateResponse(true, "Added Successfully", auth, res, ['_id'],[]);
                                    }
                                });
                            }

                        }
                    } else {
                        var errors = {
                            email: "Email already exist"
                        };
                        generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
    }
}
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'first_name': { $regex: queryParams.search, $options: 'i' } },
                { 'last_name': { $regex: queryParams.search, $options: 'i' } },
                { 'email': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Auth, function (err, auth) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
            } else {
                if (auth.length > 0) {
                    generateResponse(true, 'Success', auth, res, ['_id'],[]);
                } else {
                    generateResponse(false, 'Record not found.', auth, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            // console.log(body)
            if (body) {
                Auth.get({
                    _id: req.params.id
                }, (err, auth) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    }
                    else {
                        if (auth.length > 0) {
                            if (body.confirm_password == body.password) {
                                if (body.email != undefined && body.email != '') {
                                    generateResponse(false, 'You Can Not Change Your Email Address', [], res, [], []);
                                }
                                else {
                                    if (body.password != undefined && body.password != '') {
                                        body.password = hashSync(body.password, 10);
                                        Auth.update(req.params.id, body, (err, update) => {
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            }
                                            else {
                                                generateResponse(true, 'Updated Successfully', update, res, [], []);
                                            }
                                        });
                                    }
                                    else {
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                                    }
                                }
                            }
                            else {
                                var errors = {
                                    password: "Password doen't match"
                                };
                                generateResponse(false, "Unable to process your request.", errors, res, [], []);
                            }
                        } else {
                            generateResponse(false, 'Record not found.', [], res, [], []);
                        }
                    }
                });
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Auth.get(
                { _id: req.params.id }
                , (err, auth) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    }
                    else {
                        if (auth.length > 0) {
                            Auth.remove(req.params.id, (err, update) => {
                                // console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                }
                                else {
                                    generateResponse(true, 'Removed Successfully', [], res, [], []);
                                }
                            })
                        }
                        else {
                            generateResponse(false, "Record not found", [], res, [], []);
                        }
                    }
                })

        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err);
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function gett(req, res) {
    try {
        var queryString = {token : req.get('Token')};
        if (queryString) {
            Auth.get(queryString, (err, auth) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
                }
                else{
                    generateResponse(true, 'Updated Successfully', auth, res, [], []);

                }

                })
            }

            }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
