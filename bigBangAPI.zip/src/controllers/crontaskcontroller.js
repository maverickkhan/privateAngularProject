/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import {parseBody, generateResponse} from '../utilites';
import {hashSync, genSalt, compare} from "bcrypt";
import {searchQuery} from '../utilites/query-module';
import {decryptValue} from '../utilites/encryption-module';
import Crontask from '../models/crontask'
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                {'first_name': {$regex: queryParams.search, $options: 'i'}},
                {'last_name': {$regex: queryParams.search, $options: 'i'}},
                {'email': {$regex: queryParams.search, $options: 'i'}},
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
const lodash = require('lodash');


export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            body.details = {
                identifier : body.identifier,
                value : body.value,
                status : body.status,
                comment : body.comment,
                data_processed : body.data_processed,
            }

            Crontask.add(body, function (err, crontask) {
                if (err) {
                    var errors = {};
                    if (err.name == "ValidationError") {
                        for (var i in err.errors) {
                            errors[i] = err.errors[i].message;
                        }
                    } else {
                        errors[i] = err.errmsg;
                    }
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                } else {
                    generateResponse(true, "Added Successfully", crontask, res, ['_id'], []);
                }
            });
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        console.log(err)
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
    }
}

export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Crontask, function (err, crontask) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
            } else {
                if (crontask.length > 0) {
                    generateResponse(true, 'Success', crontask, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found.', crontask, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            // console.log(body)
            if (body) {
                Crontask.get({
                    _id: req.params.id
                }, (err, crontask) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    } else {
                        if (crontask.length > 0) {
                            if (body.confirm_password == body.password) {
                                if (body.email != undefined && body.email != '') {
                                    generateResponse(false, 'You Can Not Change Your Email Address', [], res, [], []);
                                } else {
                                    if (body.password != undefined && body.password != '') {
                                        body.password = hashSync(body.password, 10);
                                        Crontask.update(req.params.id, body, (err, update) => {
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            } else {
                                                generateResponse(true, 'Updated Successfully', update, res, [], []);
                                            }
                                        });
                                    } else {
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                                    }
                                }
                            } else {
                                var errors = {
                                    password: "Password doen't match"
                                };
                                generateResponse(false, "Unable to process your request.", errors, res, [], []);
                            }
                        } else {
                            generateResponse(false, 'Record not found.', [], res, [], []);
                        }
                    }
                });
            } else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Crontask.get(
                {_id: req.params.id}
                , (err, crontask) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    } else {
                        if (crontask.length > 0) {
                            Crontask.remove(req.params.id, (err, update) => {
                                // console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    generateResponse(true, 'Removed Successfully', [], res, [], []);
                                }
                            })
                        } else {
                            generateResponse(false, "Record not found", [], res, [], []);
                        }
                    }
                })

        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        console.log(err);
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

