/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import {parseBody, generateResponse} from '../utilites';
import {searchQuery} from '../utilites/query-module';
import mongoose from 'mongoose';
import ActivationCode from '../models/activationcode';
import Customer from '../models/customer';
import {encryptValue, decryptValue} from '../utilites/encryption-module';
import _ from 'underscore'
import moment from 'moment';
import Promocode from '../models/promocode';
import Package from '../models/package';


var lodash = require('lodash');

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                // { 'offer.title': { $regex: queryParams.search, $options: 'i' } },
                // { 'offer.offer_description': { $regex: queryParams.search, $options: 'i' } },
                // { 'offer.image': { $regex: queryParams.search, $options: 'i' } },
            ];
    }

    if (queryParams.subscription_id != undefined && queryParams.subscription_id != "") {
        findParams.subscription._id = queryParams.subscription_id || "";
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}

export function get(req, res) {
    var queryString = req.query;
    // var filter = {};
    searchQuery(Customer, function (err, customer) {
        if (err) {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        } else {
            if (customer.length > 0) {
                generateResponse(true, 'Success', customer, res, ['_id'], []);
            } else {
                generateResponse(false, 'Record not found', customer, res, [], []);
            }
        }
    }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
}

export function create(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Customer.get({
                _id: req.params.id
            }, (err, customers) => {
                if (err) {
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes1', [], res, [], []);
                } else {
                    if (customers.length > 0) {
                        if (body.activation_code != "" && body.activation_code != null && body.activation_code != undefined) {
                            var activation_code_id;
                            var activation_code = parseInt(body.activation_code);
                            // activation_code = body.activation_code.split("-");
                            if(!Number.isInteger(activation_code)){
                                activation_code = 1
                            }
                            ActivationCode.get({
                                "code": parseInt(activation_code)
                                // "activation_code.prefix": activation_code[0],
                                // "activation_code.type": activation_code[1],
                                // "activation_code.serial": activation_code[2],
                                // "activation_code.code": activation_code[3]
                            }, (err, activationcode_data) => {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes2', errors, res, [], []);
                                } else {
                                    if (activationcode_data.length > 0) {
                                        if (activationcode_data[0].is_used === false) {
                                            activation_code_id = activationcode_data[0]._id
                                            let check = false;
                                            customers[0].subscription.forEach(function (customer_sub) {
                                                let customer_sub_id = mongoose.Types.ObjectId(customer_sub.activation_code_id)
                                                let activation_codeid = mongoose.Types.ObjectId(activationcode_data[0]._id)
                                                if (customer_sub_id.equals(activation_codeid)) {
                                                    check = true
                                                }
                                            })
                                            if (check === true) {
                                                generateResponse(false, 'You are already subscribed this package', [], res, [], []);
                                            } else {
                                                var today = new Date();
                                                var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                                                var new_date = moment(date, "YYYY-MM-DD").add(activationcode_data[0].validity, 'days');
                                                var day = new_date.format('DD');
                                                var month = new_date.format('MM');
                                                var year = new_date.format('YYYY');
                                                let customer_package = {
                                                    package_id: activationcode_data[0].package_id,
                                                    // start_at: body.start_at,
                                                    end_at: year + '-' + month + '-' + day,
                                                    // status: true,
                                                    activation_code_id: activation_code_id,
                                                }
                                                // console.log(customers[0]._id, customers, customer_package);
                                                Customer.updateByGetPackage(customers[0]._id, body, customer_package, (err, update_result) => {
                                                    // console.log(req.params.id, update_result)
                                                    if (err) {
                                                        var errors = err.errmsg;
                                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes4', err, res, [], []);
                                                    } else {
                                                        if(activationcode_data[0].type === "PROMO"){
                                                            generateResponse(true, 'Updated Successfully', update_result, res, [], []);
                                                        } else {
                                                            Package.get({_id : activationcode_data[0].package_id}, (err, packages) =>{
                                                                let package_name = packages[0].name;
                                                                update_result['package'] = package_name
                                                                generateResponse(true, 'Updated Successfully', update_result, res, [], []);
                                                                ActivationCode.update(activation_code_id,
                                                                    {"is_used": true}
                                                                    , (err, update) => {
                                                                        if (err) {
                                                                            var errors = err.errmsg;
                                                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes5', err, res, [], []);
                                                                        } else {
                                                                            console.log('activation code status updated');
                                                                        }
                                                                    })
                                                            });

                                                        }

                                                    }
                                                })
                                            }
                                        } else {
                                            generateResponse(false, 'Activation code already used.', [], res, [], []);
                                        }
                                    } else {
                                        Promocode.get({
                                            code: body.activation_code,
                                            'status.is_deleted': false
                                        }, (err, promocode) => {
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            } else {
                                                if (promocode.length > 0) {
                                                    var flag = true;

                                                    lodash.forEach(customers, (val) => {
                                                        lodash.forEach(val.subscription, (val1) => {
                                                            if (val1.promo_code_id != undefined) {
                                                                if (JSON.stringify(val1.promo_code_id) == JSON.stringify(promocode[0]['_id'])) {
                                                                    flag = false;
                                                                }
                                                            }

                                                        })
                                                    });
                                                    if (flag) {
                                                        var ptoday = new Date();
                                                        var pdate = ptoday.getFullYear() + '-' + (ptoday.getMonth() + 1) + '-' + ptoday.getDate();
                                                        var new_pdate = moment(pdate, "YYYY-MM-DD").add(promocode[0]["validity"], 'days');
                                                        var pday = new_pdate.format('DD');
                                                        var pmonth = new_pdate.format('MM');
                                                        var pyear = new_pdate.format('YYYY');

                                                        var customer_package = {
                                                            package_id: promocode[0]['package_id'],
                                                            promo_code_id: promocode[0]['_id'],
                                                            end_at: pyear + '-' + pmonth + '-' + pday,
                                                            // activation_code_id: activation_code_id,
                                                        }
                                                        console.log(body.subscription);
                                                        Customer.updateByGetPackage(customers[0]._id, body, customer_package
                                                        //     Customer.update(req.params.id,
                                                        //     {$push: body}
                                                            , (err, update) => {
                                                                if (err) {
                                                                    var errors = err.errmsg;
                                                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                                } else {
                                                                    generateResponse(true, 'Updated Successfully', update, res, [], []);
                                                                }
                                                            });
                                                    } else {
                                                        var errors = {
                                                            error: "Promo Code Already Taken."
                                                        };
                                                        generateResponse(false, 'Promo Code Already Taken.', errors, res, [], []);

                                                    }

                                                } else {
                                                    var errors = {
                                                        error: "Promo Code not found"
                                                    };
                                                    generateResponse(false, 'Invalid Code!', errors, res, [], []);
                                                }
                                            }
                                        })
                                    }

                                    //Old Code
                                    // if (activationcode_data.length > 0) {
                                    //     activation_code_id = activationcode_data[0]["_id"]
                                    //     var flag = true;
                                    //     lodash.forEach(customer, (val) => {
                                    //         lodash.forEach(val.subscription, (val1) => {
                                    //             if (val1.activation_code_id == activation_code_id) {
                                    //                 flag = false;
                                    //             }
                                    //         })
                                    //     });
                                    //     if (flag) {
                                    //         ActivationCode.get({
                                    //             "_id": activation_code_id,
                                    //             "is_used": false,
                                    //             "verified": true
                                    //         }, (err, activationcode) => {
                                    //             if (err) {
                                    //                 var errors = err.errmsg;
                                    //                 generateResponse(false, 'Unable to process your request, Please retry in few minutes3', errors, res, [], []);
                                    //             }
                                    //             else {
                                    //                 if (activationcode.length > 0) {
                                    //                     var flag = false;
                                    //
                                    //                     lodash.forEach(customer, (val) => {
                                    //                         lodash.forEach(val.subscription, (val1) => {
                                    //                             lodash.forEach(activationcode, (val2) => {
                                    //                                 if (JSON.stringify(val1.package_id) == JSON.stringify(val2.package_id)) {
                                    //                                     flag = true;
                                    //                                 }
                                    //                             })
                                    //                         })
                                    //                     });
                                    //                     let customer_package;
                                    //                     if (flag) {
                                    //                         var startdate;
                                    //                         var enddate
                                    //                         lodash.forEach(customer, (val) => {
                                    //                             lodash.forEach(val.subscription, (val1) => {
                                    //                                 lodash.forEach(activationcode, (val2) => {
                                    //                                     if (JSON.stringify(val1.package_id) == JSON.stringify(val2.package_id)) {
                                    //
                                    //                                         var date = val1.end_at.getFullYear() + '-' + (val1.end_at.getMonth() + 1) + '-' + val1.end_at.getDate();
                                    //                                         var new_date = moment(date, "YYYY-MM-DD").add(1, 'days');
                                    //                                         var startday = new_date.format('DD');
                                    //                                         var startmonth = new_date.format('MM');
                                    //                                         var startyear = new_date.format('YYYY');
                                    //                                         startdate = startyear + '-' + startmonth + '-' + startday;
                                    //
                                    //                                         var new_date = moment(startdate, "YYYY-MM-DD").add(val2.validity, 'days');
                                    //                                         var day = new_date.format('DD');
                                    //                                         var month = new_date.format('MM');
                                    //                                         var year = new_date.format('YYYY');
                                    //                                         enddate = year + '-' + month + '-' + day;
                                    //                                     }
                                    //                                 })
                                    //                             })
                                    //                         });
                                    //                          customer_package = {
                                    //                             package_id: activationcode[0]['package_id'],
                                    //                             start_at: startdate,
                                    //                             end_at: enddate,
                                    //                             // status: true,
                                    //                             activation_code_id: activation_code_id,
                                    //                         }
                                    //                     }
                                    //                     else {
                                    //                         var today = new Date();
                                    //                         var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                                    //                         var new_date = moment(date, "YYYY-MM-DD").add(activationcode[0]["validity"], 'days');
                                    //                         var day = new_date.format('DD');
                                    //                         var month = new_date.format('MM');
                                    //                         var year = new_date.format('YYYY');
                                    //
                                    //                          customer_package = {
                                    //                             package_id: activationcode[0]['package_id'],
                                    //                             // start_at: body.start_at,
                                    //                             end_at: year + '-' + month + '-' + day,
                                    //                             // status: true,
                                    //                             activation_code_id: activation_code_id,
                                    //                         }
                                    //                     }
                                    //                     console.log(req.params.id)
                                    //                     Customer.updateByGetPackage(req.params.id,
                                    //                         customer_package
                                    //                         , (err, update) => {
                                    //                             if (err) {
                                    //                                 var errors = err.errmsg;
                                    //                                 generateResponse(false, 'Unable to process your request, Please retry in few minutes4', errors, res, [], []);
                                    //                             } else {
                                    //                                 generateResponse(true, 'Updated Successfully', update, res, [], []);
                                    //                                 ActivationCode.update(activation_code_id,
                                    //                                     { "is_used": true }
                                    //                                     , (err, update) => {
                                    //                                         if (err) {
                                    //                                             var errors = err.errmsg;
                                    //                                             generateResponse(false, 'Unable to process your request, Please retry in few minutes5', errors, res, [], []);
                                    //                                         } else {
                                    //                                             console.log('activation code status updated');
                                    //                                             // generateResponse(true, 'Updated Successfully', update, res, [], []);
                                    //
                                    //                                         }
                                    //                                     })
                                    //
                                    //                             }
                                    //                         })
                                    //
                                    //                 }
                                    //                 else {
                                    //                     var errors = {
                                    //                         error: "Activation Code not found"
                                    //                     };
                                    //                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    //                 }
                                    //             }
                                    //         })
                                    //     }
                                    //     else {
                                    //         var errors = {
                                    //             error: "Customer is already subscribed to current program"
                                    //         };
                                    //         generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    //
                                    //     }
                                    //
                                    // }
                                    // else {
                                    //     var errors = {
                                    //         error: "Invalid Activation Code"
                                    //     };
                                    //     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    // }
                                }
                            })
                        } else if (body.promo_code != "" && body.promo_code != null && body.promo_code != undefined) {
                            Promocode.get({
                                code: body.promo_code,
                                'status.is_deleted': false
                            }, (err, promocode) => {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    if (promocode.length > 0) {
                                        var flag = true;

                                        lodash.forEach(customer, (val) => {
                                            lodash.forEach(val.subscription, (val1) => {
                                                if (val1.promo_code_id != undefined) {
                                                    if (JSON.stringify(val1.promo_code_id) == JSON.stringify(promocode[0]['_id'])) {
                                                        flag = false;
                                                    }
                                                }

                                            })
                                        });
                                        if (flag) {
                                            var ptoday = new Date();
                                            var pdate = ptoday.getFullYear() + '-' + (ptoday.getMonth() + 1) + '-' + ptoday.getDate();
                                            var new_pdate = moment(pdate, "YYYY-MM-DD").add(promocode[0]["validity"], 'days');
                                            var pday = new_pdate.format('DD');
                                            var pmonth = new_pdate.format('MM');
                                            var pyear = new_pdate.format('YYYY');

                                            body.subscription = {
                                                package_id: promocode[0]['package_id'],
                                                promo_code_id: promocode[0]['_id'],
                                                end_at: pyear + '-' + pmonth + '-' + pday,
                                                // activation_code_id: activation_code_id,
                                            }
                                            Customer.update(req.params.id,
                                                {$push: body}
                                                , (err, update) => {
                                                    if (err) {
                                                        var errors = err.errmsg;
                                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                    } else {
                                                        generateResponse(true, 'Updated Successfully', update, res, [], []);
                                                    }
                                                });
                                        } else {
                                            var errors = {
                                                error: "Promo Code Already Taken."
                                            };
                                            generateResponse(false, 'Promo Code Already Taken.', errors, res, [], []);

                                        }

                                    } else {
                                        var errors = {
                                            error: "Promo Code not found"
                                        };
                                        generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    }
                                }
                            })
                        } else {
                            var errors = {
                                error: "One or more required fields are missing"
                            };
                            generateResponse(false, 'Unable to process your request.', errors, res, [], []);

                        }


                    } else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });


        } else {
            generateResponse(false, 'Unable to process your request, ID can not be null', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, please try in few minutes', [], res, [], []);
    }
}

// export function update(req, res) {
//     try {
//         if (req.params.id != undefined || req.params.id != "") {
//             req.params.id = decryptValue(req.params.id);
//             let body = parseBody(req);

//             Customer.get({
//                 _id: req.params.id
//             }, (err, customer) => {
//                 if (err) {
//                     generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//                 }
//                 else {
//                     if (customer.length > 0) {
//                         ActivationCode.get({
//                             "activation_code._id": body.activation_code_id,
//                             "is_used": false
//                         }, (err, activationcode) => {
//                             if (err) {
//                                 var errors = err.errmsg;
//                                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                             }
//                             else {
//                                 if (activationcode.length > 0) {
//                                     var today = new Date();
//                                     var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
//                                     var new_date = moment(date, "YYYY-MM-DD").add(activationcode[0]["validity"], 'days');
//                                     var day = new_date.format('DD');
//                                     var month = new_date.format('MM');
//                                     var year = new_date.format('YYYY');

//                                     body.subscription = {
//                                         "subscription.$.package_id": activationcode[0]['package_id'],
//                                         "subscription.$.end_at": year + '-' + month + '-' + day,
//                                         "subscription.$.activation_code_id": body.activation_code_id,
//                                     }
//                                     Customer.update(req.params.id,
//                                         { $push: body }
//                                         , (err, update) => {
//                                             if (err) {
//                                                 var errors = err.errmsg;
//                                                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                                             } else {
//                                                 generateResponse(true, 'Updated Successfully', update, res, [], []);
//                                             }
//                                         })

//                                 }
//                                 else {
//                                     var errors = {
//                                         error: "Activation Code not found"
//                                     };
//                                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                 }
//                             }
//                         })

//                     } else {
//                         generateResponse(false, 'Record not found.', [], res, [], []);
//                     }
//                 }
//             });


//         } else {
//             generateResponse(false, 'Unable to process your request, ID can not be null', [], res, [], []);
//         }
//     } catch (err) {
//         generateResponse(false, 'Unable to process your request, please try in few minutes', [], res, [], []);
//     }
// }
// export function remove(req, res) {
//     try {
//         if (req.params.id != undefined || req.params.id != "") {
//             req.params.id = decryptValue(req.params.id);
//             let body = parseBody(req);
//             if (body != undefined || body != null) {
//                 let input = [
//                     { _id: mongoose.Types.ObjectId(req.params.id) },
//                     { "offer._id": mongoose.Types.ObjectId(body.offer_id) },
//                     { "offer.status.is_deleted": false },
//                     { "offer.status.is_activated": true }
//                 ]
//                 Brand.verifyExistance(
//                     input
//                     , (err, brand) => {
//                         if (err) {
//                             generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//                         } else {
//                             if (brand.length > 0) {
//                                 var temp_count = 0
//                                 for (var i = 0; i < brand.length; i++) {
//                                     if (brand[i]['status']['is_deleted'] == false) {
//                                         for (var j = 0; j < brand[i]['offer'].length; j++) {
//                                             if ((brand[i]['offer'][j]['_id'] == body.offer_id) && (brand[i]['offer'][j]['status']['is_deleted'] == false)) {
//                                                 temp_count++;
//                                             }
//                                         }
//                                     }
//                                 }
//                                 if (brand.length > 0 && (temp_count == brand.length)) {
//                                     Brand.removeOffer(req.params.id,
//                                         body.offer_id,
//                                         (err, update) => {
//                                             console.log(update);
//                                             if (err) {
//                                                 var errors = err.errmsg;
//                                                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                                             }
//                                             else {
//                                                 generateResponse(true, 'Removed Successfully.', [], res, [], ['offer', 'terms_and_condition']);
//                                             }
//                                         })
//                                 }
//                                 else {
//                                     generateResponse(false, 'Record not found.', [], res, [], []);

//                                 }

//                             }
//                             else {
//                                 generateResponse(false, 'Record not found.', [], res, [], []);
//                             }
//                         }
//                     })
//             }
//             else {
//                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//             }
//         } else {
//             generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//         }
//     } catch (err) {
//         generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//     }
// }
