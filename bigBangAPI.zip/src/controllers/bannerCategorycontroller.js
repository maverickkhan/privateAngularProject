/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
import BannerCategory from '../models/bannerCategory';
function getQueryParams(queryParams) {
    // console.log(queryParams)
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } }
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function create(req, res) {
    try {
        let body = parseBody(req);
        function addBannerCategory(body) {
            BannerCategory.add(body, function (err, bannerCategory) {
                if (err) {
                    var errors = {};
                    if (err.name == "ValidationError") {
                        for (var i in err.errors) {
                            errors[i] = err.errors[i].message;
                        }
                    } else {
                        errors[i] = err.errmsg;
                    }
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], [], []);
                } else {
                    generateResponse(true, "Added Successfully", bannerCategory, res, ['_id'], []);
                }
            });
        }
        if (body != undefined && body != null) {

            addBannerCategory(body)
        }
        else {
            generateResponse(false, 'Unable to process your request.Please retry in few minutes', errors, res, [], [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request.Please retry in few minutes', [], res, [], [], []);
    }
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(BannerCategory, function (err, bannerCategory) {
            if (err) {
                generateResponse(false, 'Unable to process your request. Please retry in few minutes', [], res, [], [], []);
            } else {
                if (bannerCategory.length > 0) {
                    generateResponse(true, 'Success', bannerCategory, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', bannerCategory, res, [], [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            function updateBannerCategory(body) {
                BannerCategory.update(req.params.id, body, (err, update) => {
                    // console.log(update);
                    if (err) {
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                    }
                    generateResponse(true, 'Updated Successfully', update, res, [], []);
                })
            }
            let body = parseBody(req);
            if (body != undefined && body != null) {
                updateBannerCategory(body);
            }
            else {
                generateResponse(false, 'Unable to process your request.Please retry in few minutes', errors, res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            BannerCategory.remove(req.params.id, (err, update) => {
                // console.log(update);
                if (err) {
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
                }
                else {
                    generateResponse(true, 'Removed Successfully', [], res, [], []);
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
