/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
import { hashSync, genSalt, compare } from "bcrypt";
import CustomerPkgReq from '../models/customerPackageRequest';
import Package from '../models/package';
import Country from '../models/country'
import _ from 'underscore'
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                { 'phone': { $regex: queryParams.search, $options: 'i' } },
                { 'address': { $regex: queryParams.search, $options: 'i' } },
                // {'package_Id': {$regex: queryParams.search, $options: 'i'}}
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    // if (queryParams.package_Id != undefined && queryParams.package_Id != "") {
    //     findParams.package_Id = decryptValue(queryParams.package_Id) || "";
    // }
    return findParams;
}

export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body.package_Id != undefined && body.package_Id != '') {
            Package.get({
                _id: body.package_Id
            }, (err, pkgs) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (pkgs.length > 0) {
                        CustomerPkgReq.add(body, function (err, customerPackageRequest) {
                            if (err) {
                                console.log(err);
                                var errors = {};
                                if (err.name == "ValidationError") {
                                    for (var i in err.errors) {
                                        errors[i] = err.errors[i].message;
                                    }
                                } else {
                                    errors[i] = err.errmsg;
                                }
                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                            } else {
                                generateResponse(true, "Added Successfully", customerPackageRequest, res, ['_id'], []);
                            }
                        });


                    }
                    else {
                        var errors = {
                            error: "Package not found"
                        };
                        generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                    }
                }
            })
        }
        else {
            var errors = {
                error: "one or more required field missing"
            };
            generateResponse(false, 'Unable to process your request.', errors, res, [], []);
        }

    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function get(req, res) {
    var queryString = req.query;
    // var filter = {};
    searchQuery(CustomerPkgReq, function (err, customerPackageRequest) {
        if (err) {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        } else {
            if (customerPackageRequest.length > 0) {
                generateResponse(true, 'Success', customerPackageRequest, res, ['_id'], []);
            } else {
                generateResponse(false, 'Record not found', customerPackageRequest, res, [], []);
            }
        }
    }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            CustomerPkgReq.get({
                _id: req.params.id
            }, (err, customerPackageRequest) => {
                if (err) {
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                }
                else {
                    if (customerPackageRequest.length > 0) {
                        if (body.package_Id != undefined && body.package_Id != '') {
                            Package.get({
                                _id: body.package_Id
                            }, (err, pkgs) => {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                }
                                else {
                                    if (pkgs.length > 0) {
                                        CustomerPkgReq.update(req.params.id, body, function (err, customerPackageRequest) {
                                            if (err) {
                                                console.log(err);
                                                var errors = {};
                                                if (err.name == "ValidationError") {
                                                    for (var i in err.errors) {
                                                        errors[i] = err.errors[i].message;
                                                    }
                                                } else {
                                                    errors[i] = err.errmsg;
                                                }
                                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                            } else {
                                                generateResponse(true, "Updated Successfully", customerPackageRequest, res, ['_id'], []);
                                            }
                                        });


                                    }
                                    else {
                                        var errors = {
                                            error: "Package not found"
                                        };
                                        generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    }
                                }
                            })
                        }
                        else {
                            var errors = {
                                error: "one or more required field missing"
                            };
                            generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                        }
                    } else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            CustomerPkgReq.get({
                _id: req.params.id
            }, (err, customerPackageRequest) => {
                if (err) {
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                }
                else {
                    if (customerPackageRequest.length > 0) {
                        CustomerPkgReq.remove(req.params.id, (err, update) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            else {
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })

        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
