/**
 * Created by Annas on 12/24/2018.
 */


'use strict';
import { parseBody, generateResponse } from '../utilites';
import Country from '../models/country';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
import {decodeToken} from "../middlewares";
import {validateUser} from "../middlewares";
import Brand from "../models/brand";
import Customer from "../models/customer";
import mongoose from "mongoose";
import statistics from "../api/statistics";
var lodash = require('lodash');

export function getStatistics(req, res) {
    try {
            Customer.customerCount((err, customer_count) =>{
                if (err){
                    generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);
                } else {
                    Customer.availOffersCount((err, avail_count) => {
                        if(err){
                            generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);
                        } else {

                            Brand.totalOffersCount((err, total_offer) => {
                                if(err){
                                    generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);

                                } else {
                                    Brand.brandCount((err, brand_count) => {
                                        if(err){
                                            generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);
                                        } else {
                                            let statistics_data = {
                                                customer_count : customer_count,
                                                offer_avail_count : avail_count[0].total_avail_offers,
                                                total_offer_count : total_offer[0].total_offers_count,
                                                brand_count : brand_count
                                            }
                                            generateResponse(true, 'Success', statistics_data, res, [], []);

                                        }
                                    })
                                }
                            })

                        }

                    })

                }
            })
    }
    catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);
    }
}

export function getOffersStatistics(req, res) {
    try {
        Customer.offeravail( (err, result) => {
            let data = [];
            result.forEach(function (customer_data) {
                if(customer_data.offer_Avail.offer_id.equals(customer_data.result.offer._id)){
                    data.push(customer_data);
                }
            })
            generateResponse(true, 'Success.', data, res, [], []);
        })
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);

    }
}

export function getOffersStatisticsall(req, res) {
    try {
        Customer.offeravailall( (err, result) => {
            let data = [];
            result.forEach(function (customer_data) {
                if(customer_data.offer_Avail.offer_id.equals(customer_data.result.offer._id)){
                    data.push(customer_data);
                }
            })
            generateResponse(true, 'Success.', data, res, [], []);
        })
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);

    }
}

export function getAvailOfferBrand(req, res) {
    try {
        let start_date = {};
        let end_date = {};
        let brand_id={};
        if(req.query.start_date != undefined && req.query.start_date != "" && req.query.end_date != undefined && req.query.end_date != ""){
            let s_date = req.query.start_date + 'T00:00:00.000Z';
            let e_date = req.query.end_date + 'T23:59:59.999Z'
            start_date = { "offer_Avail.avail_on" : {$gt : new Date(s_date)}}
            end_date = { "offer_Avail.avail_on" : {$lt : new Date(e_date)}}
        }
        if(req.query.brand_id != undefined && req.query.brand_id != ""){
            brand_id = { "brand._id" : mongoose.Types.ObjectId(req.query.brand_id) }
        }
        Customer.getAvailOfferBrand( start_date,end_date,brand_id,(err, result) => {
            if(err){
                generateResponse(false, 'Error.', err, res, [], []);
            } else {
                if(result.length > 0){
                    generateResponse(true, 'Success.', result, res, ['brand._id'], []);
                } else {
                    generateResponse(false, 'Record not found.', [], res, [], []);
                }
            }
        })
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', err, res, [], []);

    }
}

