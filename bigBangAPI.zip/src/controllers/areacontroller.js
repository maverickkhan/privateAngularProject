/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import Country from '../models/country';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
var lodash = require('lodash');

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                { 'cities.city_name': { $regex: queryParams.search, $options: 'i' } },
                { 'cities.areas.area_name': { $regex: queryParams.search, $options: 'i' } }
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
    // try {
    //     var queryString = req.query;
    //     searchQuery(Country, function (err, country) {
    //         if (err) {
    //             var errors = err.errmsg;
    //             generateResponse(false, 'Unable to process your request.', errors, res, [], []);
    //         } else {
    //             if (country.length > 0) {
    //                 generateResponse(true, 'Success', country, res, ['_id'], []);
    //             } else {
    //                 generateResponse(false, 'Record not found', country, res, [], []);
    //             }
    //         }
    //     }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    // }
    // catch (err) {
    //     generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    // }
    try {
        let id = decryptValue(req.query.id);
        Country.getAggregateArea(id, req.query.city_id, req.query.search, (err, area) => {
            generateResponse(true, 'Success', area, res, ['_id'], []);
        })
    }
    catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', [], res, [], []);
    }
}
export function create(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                // body.cities = {
                //     city_name: body.city_name
                // }
                let body1 = {
                    'cities.$.areas': {
                        "area_name": body.area_name
                    }
                }
                // db.getCollection('countrys').updateOne(
                //     { "_id": ObjectId("5c8f89a9e2d9cf246080750a"), "cities._id": ObjectId("5c8f9c9dcee5630ad8195201")},
                //     { "$push": 
                //         {"cities.$.areas": 
                //             {
                //                 "area_name": "test name"
                //             }
                //         }
                //     }
                // )                                        
                Country.createArea({
                    "cities._id": body.city_id
                },
                    { $push: body1 }
                    , (err, update) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        } else {
                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                        }
                    })
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }


        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

        }

    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                let body1 = {
                    'cities.$.areas': {
                        "area_name": body.area_name,
                        "timestamps.updated_at":new Date()
                    }
                }
                // console.log(body1); return;
                // let body1 = {
                //     'cities.$.areas.area_name': body.area_name
                //
                // }
                // console.log(req.params.id,
                //     body.city_id,
                //     body.area_id,
                //     body1)
                //     return;
                Country.updateArea(req.params.id,
                    // body.city_id,
                    body.area_id,
                    body1
                    , (err, update) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        } else {
                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                        }
                    })
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }


        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

        }

    }
    catch (err) {
        console.log(err);
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Country.get({
                _id: req.params.id
            }, (err, country) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (country.length > 0) {
                        var temp_count = 0
                        lodash.forEach(country, (val) => {
                            if (val.status.is_deleted == false) {
                                lodash.forEach(val.cities, (val1) => {
                                    if (val1.status.is_deleted == false && val1._id == body.city_id) {                                  
                                        lodash.forEach(val1.areas, (val2) => {                                            
                                            if (val2.status.is_deleted == false && val2._id == body.area_id) {
                                                temp_count++;
                                            }
                                        });
                                    }
                                });
                            }
                        });

                        if (country.length > 0 && (temp_count == country.length)) {
                            Country.remove_area(
                                body.area_id,
                                (err, update) => {
                                    if (err) {
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                    }
                                    else {
                                        generateResponse(true, 'Removed Successfully.', [], res, [], ['offer', 'terms_and_condition']);
                                    }
                                })
                        }
                        else {
                            generateResponse(false, 'Record not found.', [], res, [], []);

                        }
                    }
                    else {
                        generateResponse(false, 'Record not found', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
