/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import Brand from '../models/brand';
import { encryptValue, decryptValue } from '../utilites/encryption-module';
import _ from 'underscore'
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'offer.title': { $regex: queryParams.search, $options: 'i' } },
                { 'offer.offer_description': { $regex: queryParams.search, $options: 'i' } },
                { 'offer.image': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.title != undefined && queryParams.title != "") {
        findParams['offer.title'] = queryParams.title;
    }
    if (queryParams.offer_description != undefined && queryParams.offer_description != "") {
        findParams['offer.offer_description'] = queryParams.offer_description;
    }
    if (queryParams.image != undefined && queryParams.image != "") {
        findParams['offer.image'] = queryParams.image;
    }
    if (queryParams.city_id != undefined && queryParams.city_id != "") {
        findParams['offer.city_id'] = queryParams.city_id;
    }
    if (queryParams.address_id != undefined && queryParams.address_id != "") {
        findParams['offer.address_id'] = queryParams.address_id;
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['offer.timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.latestoffers != undefined && queryParams.latestoffers != "") {
        findParams['offer.timestamps.created_at'] = { $gte: new Date() - 1000 * 3600 * 24 * queryParams.latestoffers, $lt: new Date() };
    }
    if (queryParams.status) {
        findParams['offer.status.is_activated'] = queryParams.status
    }
    // if (queryParams.id != undefined && queryParams.id != "") {
    //     findParams['offer._id'] = decryptValue(queryParams.id) || "";
    // }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams['offer._id'] = queryParams.id || "";
    }
    if (queryParams.limit != undefined && queryParams.limit != "") {
        findParams['offer.views'] = { $gte: 0 };
    }
    return findParams;
}
// export function get(req, res) {
//     try {
//         var queryString = req.query;
//         searchQuery(Brand, function (err, brand) {
//             if (err) {
//                 console.log(err)
//                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//             } else {
//                 if (brand.length > 0) {
//                     if (queryString != null) {
//                         if (queryString.id != null && brand.length == 1) {
//                             // queryString.id = decryptValue(queryString.id)
//                             Brand.updateOfferViews(queryString.id, (err, update) => {
//                                 if (err) {
//                                     generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//                                     console.log(err)
//                                 }
//                                 else {
//                                     generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
//                                 }
//                             });
//                         }
//                         else {
//                             generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
//                         }
//                     }
//                     else {
//                         generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
//                     }
//                 }
//                 else {
//                     generateResponse(false, 'Record not found.', brand, res, [], []);
//                 }
//             }
//         }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
//     }
//     catch (err) {
//         generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//     }
// }
export function create(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body != undefined && req.files != undefined) {
                body.speciality_icon = req.files[0]['path']
                body.specialties = {
                    speciality_name: body.speciality_name,
                    speciality_icon: body.speciality_icon
                }
                Brand.get({
                    _id: req.params.id
                }, (err, brand) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
                    } else {
                        if (brand.length > 0) {
                            Brand.update(req.params.id,
                                { $push: body }
                                , (err, update) => {
                                    if (err) {
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                    } else {
                                        generateResponse(true, 'Updated Successfully', update, res, [], []);
                                    }
                                })
                        } else {
                            generateResponse(false, 'Record not found.', [], res, [], []);
                        }
                    }
                });

            } else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        console.log(err)
        generateResponse(false, 'aUnable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Brand.get({
                _id: req.params.id
            }, (err, brand) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
                } else {
                    if (brand.length > 0) {
                        let body = parseBody(req);
                        Brand.get({
                            "specialties._id": body.speciality_id
                        }, (err, speciality) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
                            } else {
                                if (speciality.length > 0) {
                                    Brand.remove_speciality(
                                        body.speciality_id,
                                        (err, update) => {
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            }
                                            else {
                                                generateResponse(true, 'Removed Successfully.', [], res, [], ['offer', 'terms_and_condition']);
                                            }
                                        })

                                }
                                else {
                                    generateResponse(false, 'Record not found', [], res, [], []);

                                }
                            }
                        })

                    }
                    else {
                        generateResponse(false, 'Record not found', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}