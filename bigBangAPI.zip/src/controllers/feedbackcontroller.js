import {parseBody, generateResponse} from '../utilites';
import {hashSync, genSalt, compare} from "bcrypt";
import {searchQuery} from '../utilites/query-module';
import {decryptValue} from '../utilites/encryption-module';
import Feedback from '../models/feedback'

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                {'type': {$regex: queryParams.search, $options: 'i'}},
                {'customer_name': {$regex: queryParams.search, $options: 'i'}},
                {'customer_phone': {$regex: queryParams.search, $options: 'i'}},
                {'customer_email': {$regex: queryParams.search, $options: 'i'}}

            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}

const lodash = require('lodash');

export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            Feedback.add(body, (err, result) => {
                if (err) {
                    var errors = {};
                    if (err.name == "ValidationError") {
                        for (var i in err.errors) {
                            errors[i] = err.errors[i].message;
                        }
                    } else {
                        errors[i] = err.errmsg;
                    }
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                } else {
                    generateResponse(true, "Added Successfully", result, res, ['_id'], []);
                }
            })
        }
    } catch (err) {
        console.log(err)
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
    }
}

export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Feedback, function (err, feedback) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
            } else {
                if (feedback.length > 0) {
                    generateResponse(true, 'Success', feedback, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found.', feedback, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getType(req, res) {
    try {
        let type = [
            "Complaint",
            "Request a Feature",
            "Suggest a Brand",
            "Other"
        ]
        generateResponse(true, 'Success', type, res, ['_id'], []);
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
