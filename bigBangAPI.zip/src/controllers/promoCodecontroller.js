'use strict';
import { parseBody, generateResponse } from '../utilites';
import { searchQuery } from "../utilites/query-module";
import Promocode from '../models/promocode';
import {decryptValue, encryptValue} from '../utilites/encryption-module';
import Package from "../models/package";
import mongoose from "mongoose";
let ObjectId = mongoose.Schema.Types.ObjectId;
var lodash = require('lodash');


function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'package_id': { $regex: queryParams.search, $options: 'i' } },
                { 'code': { $regex: queryParams.search, $options: 'i' } },
                { 'validity': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}

export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Promocode, function (err, promocode) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
            } else {
                // console.log(promocode);
                if (promocode.length > 0) {
                    generateResponse(true, 'Success', promocode, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', promocode, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            Package.get({
                _id: body.package_id
            }, (err, pkg) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                } else {
                    if (pkg.length > 0) {
                        Promocode.get({
                            code: body.code
                        }, (err, promocode) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            } else {
                                if (promocode.length == 0) {
                                    var pkg_epiry;
                                    lodash.forEach(pkg, (val1) => {                                       
                                        pkg_epiry = val1.is_expirable.is_expire;
                                    })
                                    if (pkg_epiry == false) {
                                        Promocode.add(body, (err, data) => {
                                            if (err) {
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            }
                                            else {
                                                generateResponse(true, "Added Successfully", data, res, ['_id'], []);

                                            }
                                        })

                                    }
                                    else {
                                        var errors = {
                                            error: " Package is expired"
                                        };
                                        generateResponse(false, 'Unable to process your request', errors, res, [], []);
    
                                    }
                                    

                                } else {
                                    var errors = {
                                        error: " Promo Code Already Exist"
                                    };
                                    generateResponse(false, 'Unable to process your request', errors, res, [], []);

                                }
                            }
                        })
                    } else {
                        var errors = {
                            error: " package does not exist"
                        };
                        generateResponse(false, 'Unable to process your request', errors, res, [], []);

                    }
                }
            })

        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

        }

    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Promocode.get(
                { _id: req.params.id },
                (err, code) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
                    } else {
                        if (code.length > 0) {
                            Promocode.remove(req.params.id, (err, update) => {
                                console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    generateResponse(true, 'Removed Successfully', [], res, [], []);
                                }
                            })
                        } else {
                            generateResponse(false, "Record not found", [], res, [], []);
                        }
                    }
                })


        } else {
            generateResponse(false, 'Record not found.', [], res, [], []);

        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }

}

export function getRegPromo(req, res) {
    try {
        var queryString = req.query;
        Package.get(
            { city_id : mongoose.Types.ObjectId(queryString.city_id)
            }, function (err, data) {
                data.forEach(function(val) {
                    Promocode.getRegPromo(
                        { "package_id" : val._id, "reg_active" : true },
                        function (err, result) {
                            if(result.length > 0){
                                generateResponse(true, 'Success', result, res, ['_id'], []);
                            }

                        }
                    )
                })
            }

        )

    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
