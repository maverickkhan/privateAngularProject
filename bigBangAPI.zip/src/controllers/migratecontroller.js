/**
 * Created by Annas on 12/24/2018.
 */

'use strict';
import {parseBody, generateResponse} from '../utilites';
import Category from '../models/category';
import Country from '../models/country';
import async from 'async';
import BrandLocation from '../models/brandLocation'
import Customer from '../models/customer'
import Package from '../models/package'
import ActivationCode from '../models/activationcode'
import CustomerPackageRequest from '../models/customerPackageRequest'
import Brand from '../models/brand'
import {searchQuery} from '../utilites/query-module';
import mongoose from 'mongoose';
import {decryptValue, encryptValue} from '../utilites/encryption-module';
import moment from "moment";

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                {'name': {$regex: queryParams.search, $options: 'i'}},
                {'bgcolor': {$regex: queryParams.search, $options: 'i'}},
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = {$gte: new Date(queryParams.from), $lt: new Date(queryParams.to)};
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}

export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Category, function (err, category) {
            if (err) {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
            } else {
                if (category.length > 0) {
                    generateResponse(true, 'Success', category, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', category, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}

function getSecondPart(str) {
    return str.split('-')[1];
}

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}
function cleanArray(actual) {
    var newArray = new Array();
    for (var i = 0; i < actual.length; i++) {
        if (actual[i]) {
            newArray.push(actual[i]);
        }
    }
    return newArray;
}
function pad(num, size) {
    var s = num+"";
    while (s.length < size) s = "0" + s;
    return s;
}
export function create(req, res) {
    try {
        let body = parseBody(req);
        // var icon_path;
        // var subCat_icon_path = [];
        if (body != undefined && req.files != undefined) {
            body.icon1 = req.files[0]['path']
            console.log(body.icon1);
            const fs = require('fs');
            const csvjson = require('csvjson')

            // CSV Start
            let rawdata = fs.readFileSync(body.icon1, {encoding: 'utf8'});
            var options = {
                delimiter: ',', // optional
                quote: '"' // optional
            };
            let csv_data = csvjson.toObject(rawdata, options);
            // let cust = csvjson.toSchemaObject(rawdata, options)
            // console.log(csv_data); return;
            let file_name = getSecondPart(body.icon1);
            if (file_name === "customer.csv") {
                csv_data.forEach(function (data) {
                    Country.getRecordByOldId(data.city_id, (err, city) => {
                        let city_id = "5d6fafacdd5a444cf6925cf2"
                        if (city.length > 0) {
                            if (city[0].cities._id !== undefined || city[0].cities._id !== null) {
                                city_id = city[0].cities._id
                            }
                        }
                        let gender = "male"
                        if (data.gender === "F") {
                            gender = "female"
                        }

                        let customer = {
                            old_id: data.customer_id,
                            first_name: data.first_name,
                            email: data.email,
                            password: data.password,
                            phone: data.telephone,
                            activation_code: data.activation_code,
                            date_added: data.date_added,
                            refer_id: data.refer_code,
                            city: mongoose.Types.ObjectId(city_id),
                            gender: gender,
                            role_id: mongoose.Types.ObjectId("5cc2c0150c5ab3ed6e5c0231")

                        }
                        Customer.addCustomer(customer, (err, cust_res) => {
                            if (err) {
                                console.log(err)
                            } else {
                                console.log(cust_res)
                            }
                        })

                    })

                })
            }
            else if (file_name === "brands.csv") {
                csv_data.forEach(function (data) {
                    let is_featured = false;
                    let banner = "";
                    let icon = "";
                    if (data.is_featured === 1 || data.is_featured === "1" ){
                        is_featured = true
                    }
                    if(data.banner !== ""){
                        banner = 'uploads/' + data.banner
                    }
                    if(data.logo !== ""){
                        icon = 'uploads/' + data.logo
                    }

                  let brand_data = {
                      old_id : parseInt(data.brand_id),
                      name : data.name,
                      banner : banner,
                      icon: icon,
                      menuImages : [],
                      is_show_at_package_screen : false,
                      offer : [],
                      socialMediaLinks : [],
                      categories : {
                          parent : [],
                          child : []
                      },
                      tags : [],
                      phone_number: data.telephone,
                      description : data.description,
                      specialties : [],
                      facilities : [],
                      is_featured : is_featured,
                      sort_order: data.sort_order
                  }
                    console.log(brand_data)
                    Brand.add(brand_data, function (err, result) {
                        if (err){
                            console.log(err)
                        } else {
                            console.log(data.brand_id)
                        }
                    })
                })
            }
            else if (file_name === "purchase_request.csv") {
                csv_data.forEach(function (data) {
                    Package.getPackageByOldID({old_id: data.package_id}, (err, packages) => {
                        if (packages.length > 0) {
                            let new_package_id = packages[0]._id;
                            let package_data = {
                                name: data.name,
                                phone: data.phone_number,
                                address: data.address,
                                package_Id: mongoose.Types.ObjectId(new_package_id)
                            }
                            CustomerPackageRequest.addPackage(package_data, (err, customer_request) => {
                                if (err) {
                                    console.log(err)
                                } else {
                                    console.log(customer_request)
                                }

                            })

                        }

                    })
                })
            }
            // From Here
            else if (file_name === "offers.csv") {

                csv_data.forEach(function (data) {
                    // console.log(data)
                    Country.getRecordByOldId(data.city_id, (err, city) => {
                        let city_id = "5d6fafacdd5a444cf6925cf2"
                        if (city.length > 0) {
                            if (city[0].cities._id !== undefined || city[0].cities._id !== null) {
                                city_id = city[0].cities._id
                            }
                        }
                        Brand.getBrandByOldId(data.brand_id, (err, brand) => {
                            // console.log(brand[0]._id)

                            if (brand.length > 0) {
                                let brand_id = brand[0]._id;
                                console.log(data.offer_id)
                                if (parseInt(data.percentage) > 0) {
                                    // if(data.percentage === "0"){
                                    //     body.offer = {
                                    //         old_id: data.offer_id,
                                    //         title: data.title,
                                    //         sub_title: data.discount_message,
                                    //         offer_description: data.custom_message,
                                    //         city_id: mongoose.Types.ObjectId(city_id),
                                    //         country_id: mongoose.Types.ObjectId("5d6f8cf82c94f35475f82401"),
                                    //         address_id: [],
                                    //         terms_and_condition: "",
                                    //         tags: [],
                                    //         image: data.inner_banner,
                                    //         offer_start_date: data.offer_start_date, //Date format se kheelna hai.
                                    //         offer_end_date: data.offer_end_date,
                                    //         // lock_offer: data.lock_offer,
                                    //         days: [],
                                    //         per_day_number_of_avails: 2,
                                    //         per_app_number_of_avails: parseInt(data.avail_limit),
                                    //         hyper: {
                                    //             is_hyper: false,
                                    //             start_datetime: "",
                                    //             expair_datetime: "",
                                    //             number_of_unit: 0,
                                    //             amount: 0,
                                    //             save_amount: 0
                                    //
                                    //         },
                                    //         is_premium: false,
                                    //         is_other: false,
                                    //         baga: {
                                    //             is_baga: true,
                                    //             amount: data.price,
                                    //             save_amount: data.price,
                                    //         },
                                    //         flat_discount: {
                                    //             is_flat_discount: false,
                                    //             actual_amount: 0,
                                    //             discounted_amount: 0,
                                    //             discounted_percent: 0,
                                    //         },
                                    //         online_store: {
                                    //             couponcode: "",
                                    //             weburl: ""
                                    //         },
                                    //         is_deliverable: (data.is_deliverable === "0") ? false : true,
                                    //         status : {
                                    //             "is_deleted" : false,
                                    //             "is_activated" : true
                                    //         },
                                    //         sort_order : data.sort_order
                                    //     }
                                    // } else {
                                        body.offer = {
                                            old_id: data.offer_id,
                                            title: data.title,
                                            sub_title: data.discount_message,
                                            offer_description: data.custom_message,
                                            city_id: mongoose.Types.ObjectId(city_id),
                                            country_id: mongoose.Types.ObjectId("5d6f8cf82c94f35475f82401"),
                                            address_id: [],
                                            terms_and_condition: "",
                                            tags: [],
                                            image: data.inner_banner,
                                            offer_start_date: data.offer_start_date, //Date format se kheelna hai.
                                            offer_end_date: data.offer_end_date,
                                            // lock_offer: data.lock_offer,
                                            days: [],
                                            per_day_number_of_avails: parseInt(data.avail_limit),
                                            hyper: {
                                                is_hyper: false,
                                                start_datetime: "",
                                                expair_datetime: "",
                                                number_of_unit: 0,
                                                amount: 0,
                                                save_amount: 0

                                            },
                                            is_premium: false,
                                            is_other: false,
                                            baga: {
                                                is_baga: false,
                                                amount: 0,
                                                save_amount: 0,
                                            },
                                            flat_discount: {
                                                is_flat_discount: true,
                                                actual_amount: 0,
                                                discounted_amount: 0,
                                                discounted_percent: parseInt(data.percentage),
                                            },
                                            online_store: {
                                                couponcode: "",
                                                weburl: ""
                                            },
                                            is_deliverable: (data.is_deliverable === "0") ? false : true,
                                            status : {
                                                "is_deleted" : false,
                                                "is_activated" : true
                                            }
                                        // }
                                    }

                                } else {
                                    // console.log('aaya')
                                    // body.offer = []
                                    body.offer = {
                                        old_id: data.offer_id,
                                        title: data.title,
                                        sub_title: data.discount_message,
                                        offer_description: data.custom_message,
                                        city_id: mongoose.Types.ObjectId(city_id),
                                        country_id: mongoose.Types.ObjectId("5d6f8cf82c94f35475f82401"),
                                        address_id: [],
                                        terms_and_condition: "",
                                        tags: [],
                                        image: "uploads/" + data.inner_banner,
                                        offer_start_date: data.offer_start_date, //Date format se kheelna hai.
                                        offer_end_date: data.offer_end_date,
                                        // lock_offer: data.lock_offer,
                                        days: [],
                                        per_day_number_of_avails: parseInt(data.avail_limit),
                                        hyper: {
                                            is_hyper: false,
                                            start_datetime: "",
                                            expair_datetime: "",
                                            number_of_unit: 0,
                                            amount: 0,
                                            save_amount: 0

                                        },
                                        is_premium: false,
                                        is_other: false,
                                        baga: {
                                            is_baga: true,
                                            amount: parseInt(data.price),
                                            save_amount: parseInt(data.price),
                                        },
                                        flat_discount: {
                                            is_flat_discount: false,
                                            actual_amount: 0,
                                            discounted_amount: 0,
                                            discounted_percent: 0,
                                        },
                                        online_store: {
                                            couponcode: "",
                                            weburl: ""
                                        },
                                        is_deliverable: (data.is_deliverable === "0") ? false : true,
                                        status : {
                                            "is_deleted" : false,
                                            "is_activated" : true
                                        }
                                    }
                                    // console.log(body)
                                }
                                // BrandLocation.getMapedLocation({ brand_id : mongoose.Types.ObjectId(brand_id)}, (err, locationData) => {
                                    // console.log(mongoose.Types.ObjectId(brand_id) + ' ===================== ')
                                    // console.log(locationData)
                                    // let locaiton = []
                                    // locationData.forEach(function (location_value) {
                                    //
                                    //     locaiton.push(mongoose.Types.ObjectId(location_value._id));
                                    //
                                    // })
                                    // body.offer.address_id = locaiton;
                                    // console.log(body.offer)
                                    // if(locationData.length > 0){
                                    //     let address = []
                                    //     locationData.forEach(function (value) {
                                    //         address.push(value._id)
                                    //     })
                                    //     body.offer.address_id.push(address)
                                    //     console.log(body.offer)
                                    // }



                                    Brand.updateWithCsv(mongoose.Types.ObjectId(brand_id),
                                        {$push: body}
                                        , (err, update) => {
                                            if (err) {
                                                console.log(err)
                                            } else {
                                                console.log(update)
                                            }


                                        // })
                                })


                                // console.log(body.offer)
                            }

                        })


                    })

                })
            }
            else if (file_name === "offer_filter.csv") {
                csv_data.forEach(function (data) {
                    Category.getCategoryByOldId(data.filter_value_id, (err, category) => {
                        if (category.length > 0) {
                            let category_id = category[0]._id;
                            // console.log(category_id)
                            console.log(data.offer_id)
                            Brand.getBrandByOldOfferId(data.offer_id, (err, brand) => {
                                if (brand.length > 0) {
                                    let brand_id = brand[0]._id;
                                    let category_data = {"categories.parent": [mongoose.Types.ObjectId(category_id)]}
                                    body = category_data;
                                    // console.log('aaya')
                                    // console.log(body.categories)
                                    // body.categories.parent = [mongoose.Types.ObjectId(category_id)]
                                    // console.log(data)
                                    Brand.updateCsv(brand_id, {"$push": body}, (err, result) => {
                                        if (err) {
                                            console.log(err)
                                        } else {
                                            console.log(result)
                                        }
                                    })
                                }


                            })
                        }

                    })
                })
            }
            else if (file_name === "package_offers.csv") {
                csv_data.forEach(function (data) {
                    Brand.getOfferByOldId(data.offer_id, (err, offer) => {
                        if (offer.length > 0) {
                            let offer_id = offer[0]._id;
                            // console.log(offer_id)
                            Package.getPackageByOldID({old_id: data.Package_id}, (err, package_data) => {
                                if (err) {
                                    console.log(err)
                                } else {
                                    if (package_data.length > 0) {
                                        let package_id = package_data[0]._id;
                                        let data = {"features.offers": [mongoose.Types.ObjectId(offer_id)]}


                                        // body.features.'$'.offers = {
                                        //     offers :[offer_id]
                                        // }
                                        // console.log(body)
                                        Package.updatePackageCsv(mongoose.Types.ObjectId(package_id), {"$push": data}, (err, result) => {
                                            if (err) {
                                                console.log(err)
                                            } else {
                                                console.log(result)
                                            }
                                        })
                                    }
                                }


                            })
                        }

                    })
                })
            }
            else if(file_name === "offer_unlock.csv"){
                csv_data.forEach(function(data){
                    Brand.getOffersByOldId(data.offer_id, (err, offer_data)=>{
                        if(err){
                            console.log(err);
                        } else {
                            if(offer_data.length > 0){
                                // console.log(offer_data[0]._id);
                                // console.log(offer_data[0].offer._id);
                                let data = {"features.offers": [mongoose.Types.ObjectId(offer_data[0].offer._id)]}
                                        Package.updatePackageCsv(mongoose.Types.ObjectId("5c8b7bc33e28ae1170483bc8"), {"$push": data}, (err, result) => {
                                            if (err) {
                                                console.log(err)
                                            } else {
                                                console.log(result)
                                            }
                                        })

                            } else {
                                console.log(data.offer_id);
                            }
                        }

                    })
                })
            }
            else if (file_name === "activation_code1.csv" || file_name === "activation_code2.csv" || file_name === "activation_code3.csv" || file_name === "activation_code4.csv" || file_name === "activation_code5.csv" || file_name === "activation_code6.csv" || file_name === "activation_code7.csv" || file_name === "activation_code8.csv" || file_name === "activation_code9.csv" || file_name === "activation_code10.csv" || file_name === "activation_code11.csv" || file_name === "activation_code12.csv") {
                csv_data.forEach(function (data) {
                    let is_used = false;
                    if (data.customer_id > 0) {
                        is_used = true
                    }
                    ActivationCode.getCodeByOldId({old_id: data.id}, (err, activation_code) => {
                        if (err) {
                            console.log(err)
                        } else {
                            // console.log(activation_code); return;
                            if (activation_code.length > 0) {
                                console.log("Code already exist.")
                            } else {
                                let activation_code = {
                                    is_used: is_used,
                                    verified: true,
                                    validity: data.validity_days,
                                    code: data.code,
                                    prefix: data.prefix,
                                    type: data.code_type,
                                    old_id: data.id,
                                    package_id: mongoose.Types.ObjectId("5d443be85f4c96224cd23060")
                                }
                                console.log("code ====> " + data.code)
                                ActivationCode.addMigrate(activation_code, (err, activaton) => {
                                    if (err) {
                                        console.log(err)
                                    } else {
                                        console.log(activaton)
                                    }
                                })
                            }
                        }
                    })


                })
            }
            else if (file_name === "activationpackage.csv" || file_name === "activationpackage1.csv" || file_name === "activationpackage2.csv" || file_name === "activationpackage3.csv" || file_name === "activationpackage4.csv" || file_name === "activationpackage5.csv" || file_name === "activationpackage6.csv" || file_name === "activationpackage7.csv" || file_name === "activationpackage8.csv" || file_name === "activationpackage9.csv" || file_name === "activationpackage10.csv" || file_name === "activationpackage11.csv" || file_name === "activationpackage12.csv" || file_name === "activationpackage13.csv" || file_name === "activationpackage14.csv") {
                csv_data.forEach(function (data) {
                    console.log(data.activation_code_id)

                    ActivationCode.getCodeByOldId({old_id: data.activation_code_id}, (err, activation_code) => {
                        if (err) {
                            console.log(err)
                        } else {
                            // console.log(activation_code); return;
                            if (activation_code.length > 0) {
                                let activation_id = mongoose.Types.ObjectId(activation_code[0]._id);
                                Package.getPackageByOldID({old_id: data.package_id}, (err, package_data) => {
                                    if (err) {
                                        console.log(err)
                                    } else {
                                        if (package_data.length > 0) {
                                            let package_id = package_data[0]._id;
                                            // let push_data = { package_id : mongoose.Types.ObjectId(package_id)}
                                            // console.log(push_data)
                                            ActivationCode.updateCodeCsv(activation_id, package_id, (err, activation) => {
                                                if (err) {
                                                    console.log(err)
                                                } else {
                                                    console.log(activation)
                                                }
                                            })

                                        } else {
                                            console.log("Package count is 0.")
                                        }
                                    }
                                })
                            } else {
                                console.log("Activation code count is 0.")
                            }
                        }

                    })
                })
            }
            else if (file_name === "sub1.csv" || file_name === "sub2.csv" || file_name === "sub3.csv" || file_name === "sub4.csv") {
                csv_data.forEach(function (data) {
                    Customer.getCustomerByOldId({old_id: data.customer_id}, (err, customer_data) => {

                        if (customer_data.length > 0) {
                            // console.log(customer_data[0]._id)
                            let push_data;
                            let start_date = new Date()
                            let end_date = data.expiry_date.split("/").reverse().join("-");
                            // console.log(end_date)
                            ActivationCode.getCodeByOldId({old_id: data.id}, (err, activation_code) => {
                                if (err) {
                                    console.log(err)
                                } else {
                                    if (activation_code.length > 0) {
                                        // console.log(activation_code)
                                        let push_data = {
                                            $push: {
                                                "subscription": {
                                                    "package_id": mongoose.Types.ObjectId(activation_code[0].package_id),
                                                    "start_at": new Date(),
                                                    "end_at": new Date(end_date),
                                                    "activation_code_id": mongoose.Types.ObjectId(activation_code[0]._id),
                                                    "subscription_status": true
                                                }
                                            }

                                        }
                                        // console.log(push_data)
                                        Customer.addSubscription(customer_data[0]._id, push_data, (err, subscription) => {
                                            if (err) {
                                                console.log(err)
                                            } else {
                                                console.log(subscription)
                                            }

                                        })
                                    } else {
                                        console.log("No activation code found.")
                                    }
                                }


                            })
                        }


                    })
                })
            }
            else if (file_name === "offeramount.csv") {
                csv_data.forEach(function (data) {
                    // console.log(data.percentage)
                    let push_data;
                    if (data.percentage === "0") {
                        push_data = {
                            "offer.$.baga": {
                                is_baga: true,
                                amount: data.price,
                                save_amount: data.price
                            },
                            "offer.$.flat_discount": {
                                is_flat_discount: false,
                                actual_amount: 0,
                                discounted_amount: 0,
                                discounted_percent: 0,
                            },

                        }
                    } else {
                        let discounted_amount = (data.price / 100) * data.percentage;
                        push_data = {
                            "offer.$.baga": {
                                is_baga: false,
                                amount: 0,
                                save_amount: 0
                            },
                            "offer.$.flat_discount": {
                                is_flat_discount: true,
                                actual_amount: data.price,
                                discounted_amount: discounted_amount,
                                discounted_percent: data.percentage,
                            },

                        }
                    }
                    Brand.updateOfferCsv(data.brand_id,data.offer_id,push_data,(err, offer_data)=>{
                        console.log(offer_data)
                    })
                    // console.log(push_data)
                })
            }
            else if (file_name === "brand_location.csv") {
                csv_data.forEach(function (data) {
                    Brand.getBrandByOldId(data.brand_id, (err, brand) => {
                        // console.log(data.code.length)
                        let code = pad(data.code, 5)
                        // console.log(data.brand_id + ' ' +code)
                        if (brand.length > 0) {
                            let brand_id = brand[0]._id;
                            let city_id = mongoose.Types.ObjectId("5d6fafacdd5a444cf6925cf2")
                            if(data.city_id === "2"){
                                city_id = mongoose.Types.ObjectId("5d6fafacdd5a444cf6925cf3")
                            } else if(data.city_id === "3"){
                                city_id = mongoose.Types.ObjectId("5d6fafacdd5a444cf6925cf4")
                            } else if(data.city_id === "4"){
                                city_id = mongoose.Types.ObjectId("5d6fafacdd5a444cf6925cf5")
                            }
                            let insert_data = {
                                brand_id : mongoose.Types.ObjectId(brand_id),
                                address: data.location,
                                code : code,
                                country_id : mongoose.Types.ObjectId("5d6f8cf82c94f35475f82401"),
                                city_id : city_id,
                                geometry: {
                                    coordinates: [data.latitude, data.longitude]
                                },
                            }
                        BrandLocation.addLocationCsv(insert_data,(err, location_data)=>{
                            if(err){
                                console.log(err)
                            } else {
                                console.log(location_data)
                            }
                        })
                        }
                    })
                })
            }
            else if (file_name === "tags.csv"){
                csv_data.forEach(function (data){
                    // console.log(data)
                    data.tags = data.tags.replace(/\s*,\s*/g, ",");
                    let tags = data.tags.split(',');
                    let push_data =  {
                            tags : tags
                        }
                    Brand.updateBrandCommon(data.brand_id,push_data,(err, result) => {
                        if(err){
                            console.log(err)
                        } else {
                            console.log(result)
                        }
                    })

                })
            }
            else if (file_name === "facilities.csv"){
                csv_data.forEach(function (data){
                    // console.log(data)
                    data.facilities = data.facilities.replace(/\s*,\s*/g, ",");
                    let facilities = data.facilities.split(',');

                    if (facilities !== null){
                       let facility = cleanArray(facilities);
                       console.log(facility)
                        facility.forEach(function (facility_data) {
                            let push_data =  {
                                facilities : {
                                    facility_name : facility_data,
                                    facility_icon : "uploads/1552546549940-Jellyfish.jpg"
                                }
                            }
                            Brand.updateBrandCommon(data.brand_id,push_data,(err, result) => {
                                if(err){
                                    console.log(err)
                                } else {
                                    console.log(result)
                                }
                            })

                        })


                    }


                })
            }
            else if (file_name === "specialties.csv"){
                csv_data.forEach(function (data){
                    // console.log(data)
                    data.specialties = data.specialties.replace(/\s*,\s*/g, ",");
                    let specialties = data.specialties.split(',');

                    if (specialties !== null){
                        let specialty = cleanArray(specialties);
                        console.log(specialty)
                        specialty.forEach(function (specialty_data) {
                            let push_data =  {
                                specialties : {
                                    speciality_name : specialty_data,
                                    speciality_icon : "uploads/1552546549940-Jellyfish.jpg"
                                }
                            }
                            Brand.updateBrandCommon(data.brand_id,push_data,(err, result) => {
                                if(err){
                                    console.log(err)
                                } else {
                                    console.log(result)
                                }
                            })

                        })


                    }


                })
            }
            else if (file_name === "social.csv"){
                csv_data.forEach(function (data){
                    if(data.web_URL !== ""){
                        let push_data = {
                                webUrl : data.web_URL
                         }
                        Brand.updateBrandCommonSet(data.brand_id,push_data,(err, result) => {
                                        if(err){
                                            console.log(err)
                                        } else {
                                            console.log(result)
                                        }
                                    })
                    }
                    if(data.facebook !== ""){
                        let push_data  = {
                            socialMediaLinks : {
                                name : "Facebook",
                                link : data.facebook
                            }
                        }
                        Brand.updateBrandCommon(data.brand_id,push_data,(err, result) => {
                            if(err){
                                console.log(err)
                            } else {
                                console.log(result)
                            }
                        })
                    }

                    // data.facebook = data.facebook.replace(/\s*,\s*/g, ",");
                    // let facebook = data.facebook.split(',');

                    // if (specialties !== null){
                    //     let specialty = cleanArray(specialties);
                    //     console.log(specialty)
                    //     specialty.forEach(function (specialty_data) {
                    //         let push_data =  {
                    //             specialties : {
                    //                 speciality_name : specialty_data,
                    //                 speciality_icon : "uploads/1552546549940-Jellyfish.jpg"
                    //             }
                    //         }
                    //         Brand.updateBrandCommon(data.brand_id,push_data,(err, result) => {
                    //             if(err){
                    //                 console.log(err)
                    //             } else {
                    //                 console.log(result)
                    //             }
                    //         })
                    //
                    //     })
                    //
                    //
                    // }


                })
            }
            else if (file_name === "customer_phone.csv"){
                csv_data.forEach(function (data){
                    if(data.telephone !== ""){
                        Customer.getCustomerByPhone({ phone : "0".data.telephone },(err, result) => {
                            if(err){
                                console.log(err)
                            } else {
                                if(result.length > 0){
                                    result.forEach(function (customer) {
                                        var today = new Date();
                                        var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                                        var new_date = moment(date, "YYYY-MM-DD").add(270, 'days');
                                        var day = new_date.format('DD');
                                        var month = new_date.format('MM');
                                        var year = new_date.format('YYYY');
                                        let customer_package;
                                        if (customer.city.equals(mongoose.Types.ObjectId("5d6fafacdd5a444cf6925cf3"))) {
                                            customer_package = {
                                                package_id: mongoose.Types.ObjectId("5dd7bccbac196871687c7432"),
                                                start_at: body.start_at,
                                                end_at: year + '-' + month + '-' + day,
                                                // status: true,
                                                activation_code_id: mongoose.Types.ObjectId("5e3cf840f33c2e4fd2844473"),
                                            }
                                        } else {
                                            customer_package = {
                                                package_id: mongoose.Types.ObjectId("5d443be85f4c96224cd23060"),
                                                // start_at: body.start_at,
                                                end_at: year + '-' + month + '-' + day,
                                                // status: true,
                                                activation_code_id: mongoose.Types.ObjectId("5e3cf840f33c2e4fd2844473"),
                                            }
                                        }

                                        Customer.updateByGetPackage(customer._id, body, customer_package, (err, update_result) => {
                                            if (err) {
                                                console.log(err);
                                            } else {
                                                console.log(update_result);
                                            }
                                        })
                                    })
                                } else {
                                    console.log("phone number not found!")
                                }


                            }
                        })
                    }
                })
            }
            // Add addresses to brands
            // else {
            //     Brand.getBrandLocations((err, location_data) =>{
            //         // console.log(location_data)
            //         location_data.forEach(function (data) {
            //             // console.log(data._id)
            //             if(data.locations.length > 0){
            //                 if(data.offer !== undefined){
            //                     if(data.offer.length > 0){
            //                         // console.log(data)
            //                         data.offer.forEach(function (offers) {
            //                             let push_data = {
            //                                     "offer.$.address_id" : data.locations
            //                             }
            //                             // console.log(push_data)
            //                             Brand.updateOfferLocationCsv(data._id, offers._id, push_data, (err, offerlocation)=>{
            //                                 //check
            //                                 console.log(offerlocation)
            //                             } )
            //                         })
            //
            //                     } else {
            //                         console.log("offer")
            //                     }
            //                 }
            //
            //             } else {
            //                 console.log("location")
            //             }
            //         })
            //     })
            // }


            // CSV END


            // Json start
            //      fs.readFile(body.icon, 'utf8', (err, data) => {
            //          // const jsonObj = csvjson.toObject(data);
            //          // console.log(jsonObj);
            //          let collection = getSecondPart(body.icon)
            //          console.log(data); return;
            //          let data1 = JSON.parse(data);
            //          console.log(collection)
            //          console.log(data1); return;
            //          if (collection == "customer.json") {
            //
            //              data1.RECORDS.forEach(function (values) {
            //                  if (values.is_deleted == "0") {
            //                      let brand_data = {};
            //                      // let i = 0;
            //                      // if(i < 1){
            //                      //     i++;
            //
            //                      // Brand.add1(brand_data, function (err, brands) {
            //                      //     console.log("test")
            //                      //     if (err) {
            //                      //         console.log(err)
            //                      //         var errors = err.errmsg;
            //                      //         generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
            //                      //     } else {
            //                      //         generateResponse(true, "Added Successfully", brands, res, ['_id'], ['offer', 'terms_and_condition']);
            //                      //     }
            //                      // });
            //
            //                      // }
            //
            //                  }
            //              })
            //          }
            //      })
            //Json End

            //  let rawdata = fs.readFileSync(body.icon);
            // var options = {
            //     delimiter : ',', // optional
            //     quote     : '"' // optional
            // };
            //  let hhh = csvjson.toArray(rawdata,options)
            // // let data = JSON.parse(rawdata);
            //
            // console.log(hhh)

            // const fs = require('fs');
            // const csvjson = require('csvjson');
            // let rawdata = fs.readFileSync(body.icon);
            // let data = JSON.parse(rawdata);
            // console.log(data)
            // data.RECORDS.forEach(function (value) {
            //
            // Brand insertion start
            //
            // if(value.is_deleted === "0") {
            //                     let brand_data = {};
            //                     brand_data.old_id = parseInt(value.brand_id);
            //                     brand_data.name = value.name;
            //                     brand_data.phone = value.telephone;
            //                     brand_data.icon = 'uploads/' + value.logo;
            //                     brand_data.description = value.description;
            //                     // console.log(brand_data); return;
            //     Brand.add1(brand_data, function (err, brands) {
            //                             console.log("test")
            //                             if (err) {
            //                                 console.log(err)
            //                                 var errors = err.errmsg;
            //                                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
            //                             }
            //                             else {
            //                                 generateResponse(true, "Added Successfully", brands, res, ['_id'], ['offer', 'terms_and_condition']);
            //                             }
            //                         });
            // }
            //
            // Brand insertion end
            //
            // })
            // let data = fs.createReadStream(body.icon,'utf8');
            // Brand.getRecord(function (err, aaya) {
            //     console.log(aaya)
            // })
            // fs.readFile(body.icon, 'utf8', (err, data) => {
            //     // const jsonObj = csvjson.toObject(data);
            //     // console.log(jsonObj);
            //     let collection = getSecondPart(body.icon)
            //     // console.log(data); return;
            //     let data1 = JSON.parse(data);
            //     if(collection == "brand.json"){
            //
            //         data1.RECORDS.forEach(function (values) {
            //             if(values.is_deleted == "0"){
            //                 let brand_data = {};
            //                 brand_data.old_id = parseInt(values.brand_id);
            //                 brand_data.name = values.name;
            //                 brand_data.phone = values.telephone;
            //                 brand_data.icon = 'uploads/' + values.logo;
            //                 brand_data.description = values.description;
            //                 // let i = 0;
            //                 // if(i < 1){
            //                 //     i++;
            //
            //                 Brand.add1(brand_data, function (err, brands) {
            //                     console.log("test")
            //                     if (err) {
            //                         console.log(err)
            //                         var errors = err.errmsg;
            //                         generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
            //                     }
            //                     else {
            //                         generateResponse(true, "Added Successfully", brands, res, ['_id'], ['offer', 'terms_and_condition']);
            //                     }
            //                 });
            //
            //                 // }
            //
            //             }
            //         })
            //                 generateResponse(true, "Added Successfully", [], res, ['_id'], ['offer', 'terms_and_condition']);
            //
            //     } else {
            //         console.log("Collection not found.")
            //     }
            //
            //
            // })
            // console.log(data)

            // Category.add(body, function (err, data) {
            //     if (err) {
            //         var errors = err.errmsg;
            //         generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
            //     }
            //     else {
            //         generateResponse(true, "Added Successfully", data, res, ['_id'], []);
            //     }
            // });
        } else {

            // Brand.getAllBrand({}, (err, brand_list) => {
            //     brand_list.forEach(function (brand) {
            //         let rand = getRandomArbitrary(500, 5000)
            //         console.log(parseInt(rand))
            //         Brand.setViews(brand._id,rand, (err, view) => {
            //             if(err){
            //                 console.log(err)
            //             } else {
            //                 console.log(view)
            //             }
            //         })
            //     })
            // })
            generateResponse(false, 'One or more fields required', [], res, [], []);

        }
    } catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', err, res, [], []);
    }
}

export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Category.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                } else {
                    if (data.length > 0) {
                        // var icon_path;
                        // var subCat_icon_path = [];
                        if (body != undefined && req.files != undefined) {
                            // for (var i = 0; i < req.files.length; i++) {
                            //     if (req.files[i]['fieldname'] === 'icon') {
                            //         icon_path = req.files[i]['path']
                            //     }
                            // }
                            // for (var i = 0; i < body.subCategory.length; i++) {
                            //     for (var j = 0; j < req.files.length; j++) {
                            //         if (req.files[j]['fieldname'] === `subCategory[${i}][icon]`) {
                            //             subCat_icon_path.push(req.files[j]['path']);
                            //         }
                            //     }

                            // }
                            // if ((body.subCategory.length === subCat_icon_path.length) && (icon_path != undefined || icon_path != null)) {
                            //     for (var i = 0; i < body.subCategory.length; i++) {
                            //         body.subCategory[i]['icon'] = subCat_icon_path[i];
                            //     }
                            // body.icon = icon_path;
                            body.icon = req.files[0]['path']
                            console.log(body);
                            Category.update(req.params.id, body, (err, update) => {
                                console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    generateResponse(true, 'Updated Successfully.', update, res, [], []);
                                }
                            });
                            // }
                            // else {
                            //     generateResponse(false, 'One or more fields required', [], res, [], []);

                            // }
                        } else {
                            generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
                        }
                    } else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Category.get({
                _id: req.params.id
            }, (err, category) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                } else {
                    if (category.length > 0) {
                        Category.remove(req.params.id, (err, update) => {
                            console.log(update);
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            } else {
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    } else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getBrandByCategory(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            req.query.customer_id = decryptValue(req.query.customer_id);
            Category.getBrandByCategory(req.params.id, req.query.city_id, function (err, result) {
                if (err) {
                    generateResponse(false, 'Request Fail', err, res, [], []);
                } else {
                    if (result.length > 0) {
                        var temp_result = result[0]
                        var finalResult = (temp_result.result ? temp_result.result : [])
                        if (finalResult) {
                            async.eachSeries(finalResult, function (item, callback) {
                                var percentageDiscount = [];
                                item.offer.forEach(checkOffer => {
                                    let check1 = checkOffer.flat_discount;
                                    if (check1 != undefined) {
                                        if (check1.is_flat_discount) {
                                            if (check1.discounted_percent != 0)
                                                percentageDiscount.push(check1.discounted_percent)
                                            item.percentageDiscount = Math.max(...percentageDiscount)
                                        }
                                    }
                                });

                                callback()

                            }, function (err) {
                                Customer.get({_id: req.query.customer_id}, (err, customer) => {
                                    if (err) {
                                        var errors = {};
                                        if (err.name == "ValidationError") {
                                            for (var i in err.errors) {
                                                errors[i] = err.errors[i].message;
                                            }
                                        } else {
                                            errors[i] = err.errmsg;
                                        }
                                        generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);

                                    } else {
                                        if (customer.length > 0) {
                                            customer = customer[0]
                                            if (customer.favouriteBrand) {
                                                finalResult.forEach(item => {
                                                    item._id = encryptValue(item._id)
                                                    customer.favouriteBrand.forEach((favBrand) => {
                                                        if (favBrand) {
                                                            if (!favBrand.status.is_deleted) {
                                                                if (favBrand.brand.toString() === item._id.toString()) {
                                                                    item.customerFavBrand = true
                                                                }
                                                            }
                                                        }
                                                    });
                                                });

                                            }
                                            let resultArray = [];
                                            finalResult.forEach(data => {
                                                let offer_count = 1;
                                                if (data.offer.length > 0) {
                                                    data.offer.forEach(value => {
                                                        if (value.city_id.equals(mongoose.Types.ObjectId(req.query.city_id))) {
                                                            if (offer_count == 1) {
                                                                resultArray.push(data)
                                                                offer_count = 2;
                                                            }

                                                        }
                                                    })
                                                }
                                            })
                                            console.log(resultArray)
                                            result[0].result = resultArray
                                            generateResponse(true, 'Success', result, res, ['_id'], []);

                                        } else {
                                            generateResponse(false, 'No Customer Found', customer, res, [], []);

                                        }
                                    }
                                })


                            })
                        } else {
                            generateResponse(true, 'No record found', [], res, [], []);
                        }
                    } else {
                        generateResponse(true, 'No category found', [], res, [], []);
                    }


                    // finalResult.forEach(fnlResult => {
                    //     console.log(req.params, req.params.lat)
                    // BrandLocation.getDistanceOfNearByLocation(req.params.lng, req.params.lat, fnlResult._id,
                    //     (err, minDistance) => {
                    //         if (err) {
                    //             console.log(err);
                    //             var errors = {};
                    //             if (err.name == "ValidationError") {
                    //                 for (var i in err.errors) {
                    //                     errors[i] = err.errors[i].message;
                    //                 }
                    //             } else {
                    //                 errors[i] = err.errmsg;
                    //             }
                    //             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);

                    //         }
                    //         else {
                    //             console.log(minDistance)
                    //         }
                    //     })
                    // });

                    // if(result.length > 0){
                    //     generateResponse(true, 'Success', result, res, ['_id'], []);
                    // } else
                    // {
                    //     generateResponse(true, 'Record Not Found', [], res, ['_id'], []);
                    // }
                }

            })

        }
    } catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getBrandBySubCategory(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            // req.params.id = decryptValue(req.params.id);
            Category.getBrandBySubCategory(req.params.id, function (err, result) {
                if (err) {
                    generateResponse(false, 'Request Fail', err, res, ['_id'], []);
                } else {
                    generateResponse(true, 'Success', result, res, ['_id'], []);
                }

            })

        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
