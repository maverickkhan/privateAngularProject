/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import Brand from '../models/brand';
import Package from '../models/package';
import Country from '../models/country';
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import { encryptValue, decryptValue } from '../utilites/encryption-module';
import _ from 'underscore'
import BrandLocation from '../models/brandLocation';
import Category from "../models/category";

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'offer.title': { $regex: queryParams.search, $options: 'i' } },
                { 'offer.offer_description': { $regex: queryParams.search, $options: 'i' } },
                { 'offer.image': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.title != undefined && queryParams.title != "") {
        findParams['offer.title'] = queryParams.title;
    }
    if (queryParams.offer_description != undefined && queryParams.offer_description != "") {
        findParams['offer.offer_description'] = queryParams.offer_description;
    }
    if (queryParams.image != undefined && queryParams.image != "") {
        findParams['offer.image'] = queryParams.image;
    }
    if (queryParams.city_id != undefined && queryParams.city_id != "") {
        findParams['offer.city_id'] = queryParams.city_id;
    }
    if (queryParams.address_id != undefined && queryParams.address_id != "") {
        findParams['offer.address_id'] = queryParams.address_id;
    }
    if (queryParams.is_hyper != undefined && queryParams.is_hyper != "") {
        findParams['offer.hyper.is_hyper'] = queryParams.is_hyper;
        findParams['offer.status.is_deleted'] = false;
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['offer.timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.latestoffers != undefined && queryParams.latestoffers != "") {
        findParams['offer.timestamps.created_at'] = { $gte: new Date() - 1000 * 3600 * 24 * queryParams.latestoffers, $lt: new Date() };
    }
    if (queryParams.status) {
        findParams['offer.status.is_activated'] = queryParams.status
    }
    // if (queryParams.id != undefined && queryParams.id != "") {
    //     findParams['offer._id'] = decryptValue(queryParams.id) || "";
    // }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams['offer._id'] = queryParams.id || "";
    }
    if (queryParams.limit != undefined && queryParams.limit != "") {
        findParams['offer.views'] = { $gte: 0 };
    }
    return findParams;
}
export function getLatestOffers(req, res) {
    try {
        var queryString = req.query;
        Brand.getLatestOffers(queryString.latestoffers, queryString.city_id, (err, latestOffer) => {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
            } else {
                if (latestOffer.length > 0) {
                    generateResponse(true, 'Success', latestOffer, res, ['_id'], ['offer', 'terms_and_condition']);
                }
                else {
                    generateResponse(false, 'Record not found', latestOffer, res, [], []);
                }
            }
        });
        // var queryString = req.query;
        // console.log(queryString);
        // searchQuery(Brand, function (err, brand) {
        //     if (err) {
        //         var errors = err.errmsg;
        //         generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
        //     } else {
        //         if (brand.length > 0) {
        //             generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
        //         }
        //         else {
        //             generateResponse(false, 'Record not found', brand, res, [], []);
        //         }
        //     }
        // }, queryString.limit, queryString.page, { 'offer.timestamps.created_at': 'descending' }, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}
export function getPopularOffers(req, res) {
    try {
        var queryString = req.query;
        // console.log(queryString);
        // return
        // console.log(Brand.getPopularOffer(queryString.limit));
        Brand.getPopularOffer(queryString.limit, queryString.city_id, (err, popularOffer) => {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', errors, res, [], []);
            } else {
                if (popularOffer.length > 0) {
                    generateResponse(true, 'Success', popularOffer, res, ['_id'], ['offer', 'terms_and_condition']);
                }
                else {
                    generateResponse(false, 'Record not found', popularOffer, res, [], []);
                }
            }
        });
        {
            // var queryString = req.query;
            // console.log(queryString);
            // searchQuery(Brand, function (err, brand) {
            //     // db.getCollection('brands').aggregate([ { $unwind : "$offer" }, { $sort : { 'offer.views' : -1 }} ])
            //     if (err) {
            //         var errors = err.errmsg;
            //         generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, []);
            //     } else {
            //         if (brand.length > 0) {
            //             generateResponse(true, 'Success', brand, res, ['_id']);
            //         }
            //         else {
            //             generateResponse(true, 'Record not found', brand, res, []);
            //         }
            //     }
            // }, queryString.limit, queryString.page, { 'offer.views': -1 }, getQueryParams(queryString), '');
        }
    }
    catch (err) {
        console.log(err);
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}
export function getRelatedOffers(req, res) {
    try {
        var queryString = req.query;
        var arrObj = function arr_Obj(input) {
            var count = _.keys(input).length
            var arrObj = new Array();
            if ((count == 0) && (input != undefined || input != null)) {
                var obj = JSON.stringify(input, function (key, value) {
                    arrObj.push(value);
                })
                return arrObj;
            }
            else {
                if ((count > 0) && (input != undefined || input != null)) {
                    // var arrObj = [];
                    for (var i = 0; i < input.length; i++) {
                        arrObj[i] = mongoose.Types.ObjectId(input[i]);
                    }
                    return arrObj;
                }
            }
        }
        Brand.get({
            "offer._id": queryString.id
        }, (err, brand) => {
            if (err) {
                generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], [])
            }
            else {
                if (brand.length > 0) {
                    var tags;
                    var city_id;
                    for (var i = 0; i < brand[0]['offer'].length; i++) {
                        if (queryString.id == brand[0]['offer'][i]['_id']) {
                            tags = brand[0]['offer'][i]['tags']
                            city_id = brand[0]['offer'][i]['city_id']
                        }
                    }
                    Brand.getRelatedOffers(
                        "categories.parent",
                        arrObj(brand[0]['categories']['parent']),
                        "offer.tags",
                        tags.join('|'),
                        "offer._id",
                        mongoose.Types.ObjectId(queryString.id),
                        "offer.city_id",
                        mongoose.Types.ObjectId(city_id)

                        , (err, data) => {
                            if (err) {
                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], [])
                            }
                            else {
                                if (data.length > 0) {
                                    generateResponse(true, "Success", data, res, ['_id'], ['offer', 'terms_and_condition']);
                                }
                                else {
                                    generateResponse(false, 'Record not found.', [], res, [], []);
                                }
                            }
                        }
                    )
                }
                else {
                    generateResponse(false, 'Record not found.', [], res, [], []);
                }
            }
        });
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], [])
    }
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Brand, function (err, brand) {
            if (err) {
                console.log(err)
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            } else {
                if (brand.length > 0) {
                    if (queryString != null) {
                        if (queryString.id != null && brand.length == 1) {
                            // queryString.id = decryptValue(queryString.id)
                            Brand.updateOfferViews(queryString.id, (err, update) => {
                                if (err) {
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                                    console.log(err)
                                }
                                else {
                                    generateResponse(true, 'Success', brand, res, ['_id'], ['offer','terms_and_condition']);
                                }
                            });
                        }
                        else {
                            generateResponse(true, 'Success', brand, res, ['_id'], ['offer']);
                        }
                    }
                    else {
                        generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
                    }
                }
                else {
                    generateResponse(false, 'Record not found.', brand, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function create(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            // console.log(body)
            body.package_id = JSON.parse(body.package_id)
            body.address_id = JSON.parse(body.address_id)
            body.days = JSON.parse(body.days)
            body.tags = JSON.parse(body.tags)
            // console.log(body.package_id , "Package")
            if (body != undefined) {
                if ((body.terms_and_condition != null || body.terms_and_condition != undefined)) {
                    body.terms_and_condition = encryptValue(body.terms_and_condition)
                    // if(req.files != undefined){
                    //     body.image = req.files[0]['path']
                    // } else {
                    //     body.image = ''
                    // }

                    body.offer = {
                        title: body.title,
                        sub_title: body.sub_title,
                        offer_description: body.offer_description,
                        city_id: body.city_id,
                        country_id: body.country_id,
                        address_id: body.address_id,
                        terms_and_condition: body.terms_and_condition,
                        tags: body.tags,
                        // image: body.image,
                        offer_start_date: body.offer_start_date,
                        offer_end_date: body.offer_end_date,
                        lock_offer: body.lock_offer,
                        days: body.days,
                        per_day_number_of_avails: body.per_day_number_of_avails,
                        hyper: {
                            is_hyper: body.is_hyper,
                            start_datetime: body.start_datetime,
                            expair_datetime: body.expair_datetime,
                            number_of_unit: body.number_of_unit,
                            amount: body.hyper_amount,
                            save_amount: body.hyper_save_amount

                        },
                        is_premium: body.is_premium,
                        is_other: body.is_other,
                        baga: {
                            is_baga: body.is_baga,
                            amount: body.amount,
                            save_amount: body.save_amount,
                        },
                        flat_discount: {
                            is_flat_discount: body.is_flat_discount,
                            actual_amount: body.actual_amount,
                            discounted_amount: body.discounted_amount,
                            discounted_percent: body.discounted_percent,
                        },
                        online_store: {
                            couponcode: body.couponcode,
                            weburl: body.weburl
                        },
                        is_deliverable: body.is_deliverable
                    }
                    // console.log(body)
                    Brand.get({
                        _id: req.params.id
                    }, (err, brand) => {
                        if (err) {
                            console.log(err)
                            var errors = err.errmsg;
                            generateResponse(false, '1Unable to process your request, Please retry in few minutes.', errors, res, [], []);
                        } else {
                            if (brand.length > 0) {
                                let input = [
                                    // { _id: mongoose.Types.ObjectId(req.params.id) },
                                    { "cities._id": mongoose.Types.ObjectId(body.city_id) },
                                    { "cities.status.is_deleted": false },
                                    { "cities.status.is_activated": true }
                                ]
                                Country.verifyExistance(
                                    input
                                    , (err, country) => {
                                        if (err) {
                                            generateResponse(false, '2Unable to process your request, Please retry in few minutes', [], res, [], []);
                                        } else {
                                            if (country.length > 0) {
                                                BrandLocation.get({
                                                    _id: { $in: body.address_id },
                                                    brand_id: req.params.id
                                                },
                                                    (err, location) => {
                                                        if (err) {
                                                            var errors = {};
                                                            if (err.name == "ValidationError") {
                                                                for (var i in err.errors) {
                                                                    errors[i] = err.errors[i].message;
                                                                }
                                                            } else {
                                                                errors[i] = err.errmsg;
                                                            }
                                                            generateResponse(false, "3Unable to process your request, Please retry in few minutes.", errors, res, [], []);

                                                        }
                                                        else {
                                                            if (location.length > 0) {
                                                                Brand.update(req.params.id,
                                                                    { $push: body }
                                                                    , (err, update) => {
                                                                        if (err) {
                                                                            var errors = {};
                                                                            if (err.name == "ValidationError") {
                                                                                for (var i in err.errors) {
                                                                                    errors[i] = err.errors[i].message;
                                                                                }
                                                                            } else {
                                                                                errors[i] = err.errmsg;
                                                                            }
                                                                            generateResponse(false, "4Unable to process your request, Please retry in few minutes.", err, res, [], []);

                                                                        } else {
                                                                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                                                                            Brand.getCurrentOffer(req.params.id, (err, offer_id) => {
                                                                                if (err) {
                                                                                    var errors = {};
                                                                                    if (err.name == "ValidationError") {
                                                                                        for (var i in err.errors) {
                                                                                            errors[i] = err.errors[i].message;
                                                                                        }
                                                                                    } else {
                                                                                        errors[i] = err.errmsg;
                                                                                    }
                                                                                    generateResponse(false, "5Unable to process your request, Please retry in few minutes.", err, res, [], []);

                                                                                }
                                                                                else {
                                                                                    var currentOfferId = offer_id[0]

                                                                                    body.package_id.forEach(pkgL => {
                                                                                        Package.updatePkgOffer(mongoose.Types.ObjectId(pkgL),
                                                                                            { $push: { 'features.offers': currentOfferId.offer._id } }
                                                                                            , (err, pkgUpdate) => {
                                                                                                if (err) {
                                                                                                    var errors = {};
                                                                                                    if (err.name == "ValidationError") {
                                                                                                        for (var i in err.errors) {
                                                                                                            errors[i] = err.errors[i].message;
                                                                                                        }
                                                                                                    } else {
                                                                                                        errors[i] = err.errmsg;
                                                                                                    }
                                                                                                    // generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                                                                                    console.log('Error on package insert', pkgUpdate)
                                                                                                }
                                                                                                else {
                                                                                                    console.log('Offer Added In Package', pkgUpdate)

                                                                                                }
                                                                                            })
                                                                                    });

                                                                                }

                                                                            })
                                                                        }
                                                                    })
                                                            }

                                                            else {
                                                                generateResponse(false, 'Address not found.', [], res, [], []);

                                                            }
                                                        }
                                                    })


                                            } else {
                                                generateResponse(false, 'Country not found.', [], res, [], []);
                                            }
                                        }
                                    });
                            } else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
                }
                else {
                    generateResponse(false, 'Please select terms and condition', [], res, [], []);
                }
            } else {
                generateResponse(false, '6Unable to process your request, Please fill all required fields', [], res, [], []);
            }
        } else {
            generateResponse(false, '7Unable to process your request, ID can not be null', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, '8Unable to process your request, please try in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            body.package_id = JSON.parse(body.package_id)
            body.address_id = JSON.parse(body.address_id)
            body.days = JSON.parse(body.days)
            body.tags = JSON.parse(body.tags)
            // console.log(body); return;
            if (body != undefined && req.files != undefined) {
                if ((body.terms_and_condition != null || body.terms_and_condition != undefined)) {
                    body.terms_and_condition = encryptValue(body.terms_and_condition)
                    body.image = ''
                    // "favouriteOffer.$.status.is_deleted": true,
                    // "favouriteOffer.$.status.is_activated": false,
                    // "favouriteOffer.$.timestamps.updated_at": new Date()
                    // console.log(body,'here')
                    // return;
                    let body1 = {
                        "offer.$.title": body.title,
                        "offer.$.sub_title": body.sub_title,
                        "offer.$.offer_description": body.offer_description,
                        "offer.$.city_id": body.city_id,
                        "offer.$.country_id": body.country_id,
                        "offer.$.address_id": body.address_id,
                        "offer.$.terms_and_condition": body.terms_and_condition,
                        "offer.$.tags": body.tags,
                        "offer.$.image": body.image,
                        "offer.$.timestamps.updated_at": new Date(),
                        "offer.$.offer_start_date": body.offer_start_date,
                        "offer.$.offer_end_date": body.offer_end_date,
                        "offer.$.lock_offer": body.lock_offer,
                        "offer.$.days": body.days,
                        "offer.$.per_day_number_of_avails": body.per_day_number_of_avails,
                        "offer.$.hyper": {
                            is_hyper: body.is_hyper,
                            start_datetime: body.start_datetime,
                            expair_datetime: body.expair_datetime,
                            number_of_unit: body.number_of_unit,
                            amount: body.amount,
                            save_amount: body.save_amount
                        },
                        "offer.$.is_premium": body.is_premium,
                        "offer.$.is_other": body.is_other,
                        "offer.$.baga": {
                            is_baga: body.is_baga,
                            amount: body.amount,
                            save_amount: body.save_amount

                        },
                        "offer.$.flat_discount": {
                            is_flat_discount: body.is_flat_discount,
                            actual_amount: body.actual_amount,
                            discounted_amount: body.discounted_amount,
                            discounted_percent: body.discounted_percent,
                        },
                        "offer.$.online_store": {
                            couponcode: body.couponcode,
                            weburl: body.weburl
                        },
                        "offer.$.is_deliverable": body.is_deliverable


                    }
                     // console.log(body1);
                    //  return;
                    let input1 = [
                        { _id: mongoose.Types.ObjectId(req.params.id) },
                        { "offer._id": mongoose.Types.ObjectId(body.offer_id) },
                        { "offer.status.is_deleted": false },
                        { "offer.status.is_activated": true }
                    ]
                    Brand.verifyExistance(
                        input1
                        , (err, brand) => {
                            if (err) {
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes111', err, res, [], []);
                            } else {
                                if (brand.length > 0) {
                                    var temp_count = 0
                                    for (var i = 0; i < brand.length; i++) {
                                        if (brand[i]['status']['is_deleted'] == false) {
                                            for (var j = 0; j < brand[i]['offer'].length; j++) {
                                                if ((brand[i]['offer'][j]['_id'] == body.offer_id) && (brand[i]['offer'][j]['status']['is_deleted'] == false)) {
                                                    temp_count++;
                                                }
                                            }
                                        }
                                    }
                                    if (brand.length > 0 && (temp_count == brand.length)) {
                                        let input = [
                                            // { _id: mongoose.Types.ObjectId(req.params.id) },
                                            { "cities._id": mongoose.Types.ObjectId(body.city_id) },
                                            { "cities.status.is_deleted": false },
                                            { "cities.status.is_activated": true }
                                        ]
                                        Country.verifyExistance(
                                            input
                                            , (err, country) => {
                                                if (err) {
                                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes222', err, res, [], []);
                                                } else {
                                                    if (country.length > 0) {
                                                        BrandLocation.getRecord({
                                                            _id: { $in : body.address_id},
                                                            brand_id: req.params.id
                                                        },
                                                            (err, location) => {
                                                                if (err) {
                                                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes333', err, res, [], []);

                                                                }

                                                                else {
                                                                    if (location.length > 0) {
                                                                        Brand.updateOffer(req.params.id,
                                                                            body.offer_id,
                                                                            body1
                                                                            , (err, update) => {
                                                                                if (err) {
                                                                                    var errors = err.errmsg;
                                                                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes444', err, res, [], []);
                                                                                } else {
                                                                                    // generateResponse(true, 'Updated Successfully', update, res, [], []);
                                                                                    // console.log(body.offer_id)
                                                                                    Package.removeOfferIdFromAllPackages(body.offer_id, (err, offerRemove) => {
                                                                                        if (err) {
                                                                                            var errors = {};
                                                                                            if (err.name == "ValidationError") {
                                                                                                for (var i in err.errors) {
                                                                                                    errors[i] = err.errors[i].message;
                                                                                                }
                                                                                            } else {
                                                                                                errors[i] = err.errmsg;
                                                                                            }
                                                                                            generateResponse(false, "Unable to process your request, Please retry in few minutes.555", err, res, [], []);

                                                                                        }
                                                                                        else {
                                                                                            console.log('Offer Removed From All Packages', offerRemove)
                                                                                            body.package_id.forEach(pkgL => {
                                                                                                Package.updatePkgOffer(mongoose.Types.ObjectId(pkgL),
                                                                                                    { $push: { 'features.offers': body.offer_id } }
                                                                                                    , (err, pkgUpdate) => {
                                                                                                        if (err) {
                                                                                                            var errors = {};
                                                                                                            if (err.name == "ValidationError") {
                                                                                                                for (var i in err.errors) {
                                                                                                                    errors[i] = err.errors[i].message;
                                                                                                                }
                                                                                                            } else {
                                                                                                                errors[i] = err.errmsg;
                                                                                                            }
                                                                                                            generateResponse(false, "Unable to process your request, Please retry in few minutes.666", err, res, [], []);

                                                                                                        }
                                                                                                        else {
                                                                                                            console.log('Offer Updated In Package', pkgUpdate)

                                                                                                        }
                                                                                                    })
                                                                                            });
                                                                                            generateResponse(true, 'Success', brand, res, ['_id'], []);
                                                                                        }

                                                                                    })


                                                                                }
                                                                            })
                                                                    } else {
                                                                        generateResponse(false, 'Address not found.', [], res, [], []);
                                                                    }
                                                                }
                                                            });
                                                    } else {
                                                        generateResponse(false, 'Country not found.', [], res, [], []);
                                                    }
                                                }
                                            });
                                    }
                                    else {
                                        generateResponse(false, 'Record not found.', [], res, [], []);
                                    }

                                }
                                else {
                                    generateResponse(false, 'Record not found.', [], res, [], []);
                                }
                            }
                        });
                }
                else {
                    generateResponse(false, 'One or more fields required', [], res, [], []);
                }
            } else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes777', [], res, [], []);
            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes888', [], res, [], []);
        }
    } catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes999', err, res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body != undefined || body != null) {
                let input = [
                    { _id: mongoose.Types.ObjectId(req.params.id) },
                    { "offer._id": mongoose.Types.ObjectId(body.offer_id) },
                    { "offer.status.is_deleted": false },
                    { "offer.status.is_activated": true }
                ]
                Brand.verifyExistance(
                    input
                    , (err, brand) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        } else {
                            if (brand.length > 0) {
                                var temp_count = 0
                                for (var i = 0; i < brand.length; i++) {
                                    if (brand[i]['status']['is_deleted'] == false) {
                                        for (var j = 0; j < brand[i]['offer'].length; j++) {
                                            if ((brand[i]['offer'][j]['_id'] == body.offer_id) && (brand[i]['offer'][j]['status']['is_deleted'] == false)) {
                                                temp_count++;
                                            }
                                        }
                                    }
                                }
                                if (brand.length > 0 && (temp_count == brand.length)) {
                                    Brand.removeOffer(req.params.id,
                                        body.offer_id,
                                        (err, update) => {
                                            // console.log(update);
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            }
                                            else {

                                                generateResponse(true, 'Removed Successfully.', [], res, [], ['offer', 'terms_and_condition']);

                                            }
                                        })
                                }
                                else {
                                    generateResponse(false, 'Record not found.', [], res, [], []);

                                }

                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    })
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function getOfferByBrand(req, res) {
    try {
        let id = decryptValue(req.query.id)
        // console.log(id)
        Brand.get_offer_by_brand(id, req.query.city_id, function (err, offer) {
            generateResponse(true, '', offer, res, [], []);

        })
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

    }
}

export function getIsDeliverableOffer(req, res) {
    try {

        if (req.query.is_deliverable != "") {
            Brand.getIsDeliverableOffer(req.query.is_deliverable, function (err, result) {
                if (err) {
                    generateResponse(false, 'Request Fail', err, res, ['_id'], []);
                } else {
                    generateResponse(true, 'Success', result, res, ['_id'], []);
                }

            })
        } else {
            generateResponse(false, 'Request Fail', err, res, ['_id'], []);
        }



    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getOfferPackages(req, res){
    try{
        Package.getOfferPackages(req.query.offer_id, (err, data) => {
         generateResponse(true, 'Success', data, res, ['_id'], []);
        })
    } catch(err){
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getHyperOffer(req, res) {
    try {
        Brand.getHyperOffers(req.query.city_id,(err, offers) => {
            if(err){
                generateResponse(false,"Unable to process your request.",err,res,[],[]);
            } else {
                generateResponse(true,"success.",offers,res,['_id'],[]);
            }
        });
    } catch (err) {
        generateResponse(false,"Unable to process your request.",err,res,[],[]);
    }
}
