/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import Category from '../models/category';
import async from 'async';
import Brandlocation from '../models/brandLocation'
import Customer from '../models/customer'
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import { decryptValue, encryptValue } from '../utilites/encryption-module';
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                { 'bgcolor': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Category, function (err, category) {
            if (err) {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
            } else {
                if (category.length > 0) {
                    generateResponse(true, 'Success', category, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', category, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {sort_order : 1}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}

export function create(req, res) {
    try {
        let body = parseBody(req);
        // var icon_path;
        // var subCat_icon_path = [];
        if (body != undefined && req.files != undefined) {
            body.icon = req.files[0]['path']
            Category.add(body, function (err, data) {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                }
                else {
                    generateResponse(true, "Added Successfully", data, res, ['_id'], []);
                }
            });
        }
        else {
            generateResponse(false, 'One or more fields required', [], res, [], []);

        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Category.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (data.length > 0) {
                        // var icon_path;
                        // var subCat_icon_path = [];
                        if (body != undefined && req.files != undefined) {
                            // for (var i = 0; i < req.files.length; i++) {
                            //     if (req.files[i]['fieldname'] === 'icon') {
                            //         icon_path = req.files[i]['path']
                            //     }
                            // }
                            // for (var i = 0; i < body.subCategory.length; i++) {
                            //     for (var j = 0; j < req.files.length; j++) {
                            //         if (req.files[j]['fieldname'] === `subCategory[${i}][icon]`) {
                            //             subCat_icon_path.push(req.files[j]['path']);
                            //         }
                            //     }

                            // }
                            // if ((body.subCategory.length === subCat_icon_path.length) && (icon_path != undefined || icon_path != null)) {
                            //     for (var i = 0; i < body.subCategory.length; i++) {
                            //         body.subCategory[i]['icon'] = subCat_icon_path[i];
                            //     }
                            // body.icon = icon_path;
                            body.icon = req.files[0]['path']
                            // console.log(body);
                            Category.update(req.params.id, body, (err, update) => {
                                // console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                }
                                else {
                                    generateResponse(true, 'Updated Successfully.', update, res, [], []);
                                }
                            });
                            // }
                            // else {
                            //     generateResponse(false, 'One or more fields required', [], res, [], []);

                            // }
                        }
                        else {
                            generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
                        }
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Category.get({
                _id: req.params.id
            }, (err, category) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (category.length > 0) {
                        Category.remove(req.params.id, (err, update) => {
                            // console.log(update);
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            else {
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getBrandByCategory(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            req.query.customer_id = decryptValue(req.query.customer_id);
            Category.getBrandByCategory(req.params.id,req.query.city_id, function (err, result) {
                if (err) {
                    generateResponse(false, 'Request Fail', err, res, [], []);
                } else {
                    if (result.length > 0) {
                        Brandlocation.getAllLocations({},(err, brand_location) => {
                        var temp_result = result[0]
                        var finalResult = (temp_result.result ? temp_result.result : [])

                            // New Category Code Start
                            finalResult.forEach(item => {
                                item._id = encryptValue(item._id)
                                // customer.favouriteBrand.forEach((favBrand) => {
                                //     if (favBrand) {
                                //         if (!favBrand.status.is_deleted) {
                                //             if (favBrand.brand.toString() === item._id.toString()) {
                                //                 item.customerFavBrand = true
                                //             }
                                //         }
                                //     }
                                // });
                            });
                            generateResponse(true, 'Success', result, res, ["_id"], []);
                            // New Category Code End


                        // Old Category Code Start
                        // if (finalResult) {
                        //     async.eachSeries(finalResult, function (item, callback) {
                        //         var percentageDiscount = [];
                        //         item.offer.forEach(checkOffer => {
                        //             let check1 = checkOffer.flat_discount;
                        //             if (check1 != undefined) {
                        //                 if (check1.is_flat_discount) {
                        //                     if (check1.discounted_percent != 0)
                        //                         percentageDiscount.push(check1.discounted_percent)
                        //                     item.percentageDiscount = Math.max(...percentageDiscount)
                        //                 }
                        //             }
                        //         });
                        //
                        //         callback()
                        //
                        //     }, function (err) {
                        //         Customer.get({_id: req.query.customer_id}, (err, customer) => {
                        //             if (err) {
                        //                 var errors = {};
                        //                 if (err.name == "ValidationError") {
                        //                     for (var i in err.errors) {
                        //                         errors[i] = err.errors[i].message;
                        //                     }
                        //                 } else {
                        //                     errors[i] = err.errmsg;
                        //                 }
                        //                 generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                        //
                        //             } else {
                        //                 if (customer.length > 0) {
                        //                     customer = customer[0]
                        //                     if (customer.favouriteBrand) {
                        //                         finalResult.forEach(item => {
                        //                             item._id = encryptValue(item._id)
                        //                             customer.favouriteBrand.forEach((favBrand) => {
                        //                                 if (favBrand) {
                        //                                     if (!favBrand.status.is_deleted) {
                        //                                         if (favBrand.brand.toString() === item._id.toString()) {
                        //                                             item.customerFavBrand = true
                        //                                         }
                        //                                     }
                        //                                 }
                        //                             });
                        //                         });
                        //                     }
                        //                     let resultArray = [];
                        //                     finalResult.forEach(function (data, key) {
                        //                         let offer_count = 1;
                        //                         if (data.offer.length > 0) {
                        //                             data.offer.forEach(value => {
                        //                                 if (value.city_id.equals(mongoose.Types.ObjectId(req.query.city_id))) {
                        //                                     // *******************
                        //                                     // Location Start here
                        //                                     // *******************
                        //                                     // let locations = []
                        //                                     // brand_location.forEach(function (location_data) {
                        //                                     //     let brand_id = decryptValue(data._id);
                        //                                     //     if(String(brand_id) === String(location_data.brand_id)){
                        //                                     //         locations.push(location_data)
                        //                                     //     }
                        //                                     // })
                        //                                     // data.locations = locations;
                        //                                     // ************
                        //                                     // Location End
                        //                                     // ************
                        //                                     if (offer_count == 1) {
                        //                                         resultArray.push(data)
                        //                                         offer_count = 2;
                        //                                     }
                        //
                        //                                 }
                        //                             })
                        //                         }
                        //                     })
                        //                     result[0].result = resultArray
                        //                     generateResponse(true, 'Success', result, res, ['_id'], []);
                        //
                        //                 } else {
                        //                     generateResponse(false, 'No Customer Found', customer, res, [], []);
                        //
                        //                 }
                        //             }
                        //         })
                        //
                        //
                        //     })
                        //
                        // } else {
                        //     generateResponse(true, 'No record found', [], res, [], []);
                        // }
                        // Old Category Code End
                    })
                    }
                    else {
                        generateResponse(true, 'No category found', [], res, [], []);
                    }



                    // finalResult.forEach(fnlResult => {
                    //     console.log(req.params, req.params.lat)
                    // BrandLocation.getDistanceOfNearByLocation(req.params.lng, req.params.lat, fnlResult._id,
                    //     (err, minDistance) => {
                    //         if (err) {
                    //             console.log(err);
                    //             var errors = {};
                    //             if (err.name == "ValidationError") {
                    //                 for (var i in err.errors) {
                    //                     errors[i] = err.errors[i].message;
                    //                 }
                    //             } else {
                    //                 errors[i] = err.errmsg;
                    //             }
                    //             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);

                    //         }
                    //         else {
                    //             console.log(minDistance)
                    //         }
                    //     })
                    // });

                    // if(result.length > 0){
                    //     generateResponse(true, 'Success', result, res, ['_id'], []);
                    // } else
                    // {
                    //     generateResponse(true, 'Record Not Found', [], res, ['_id'], []);
                    // }
                }

            })

        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getBrandBySubCategory(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            // req.params.id = decryptValue(req.params.id);
            Category.getBrandBySubCategory(req.params.id, function (err, result) {
                if (err) {
                    generateResponse(false, 'Request Fail', err, res, ['_id'], []);
                } else {
                    generateResponse(true, 'Success', result, res, ['_id'], []);
                }

            })

        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getBrandCategoryPagination(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            if(req.query.page != undefined || req.query.page != "" || req.query.limit != undefined || req.query.limit != "") {
                Category.getBrandByCategoryPagination(req.query.page, req.query.limit, req.query.city_id, req.params.id, (err, result) => {
                    if (result.length > 0) {
                        generateResponse(true, 'Success', result, res, ["_id"], []);
                    } else {
                        generateResponse(false, 'Record not found', [], res, [], []);
                    }
                });
            } else {
                generateResponse(false, 'Page and limit required.', [], res, [], []);

            }
        } else {
            generateResponse(false, 'Category not found.', [], res, [], []);

        }
    }catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', err, res, [], []);

    }
}
