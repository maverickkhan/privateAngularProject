'use strict';

import { parseBody, generateResponse } from '../utilites';
import Role from '../models/role';
import Auth from '../models/auth';
// import Employee from '../models/employee';
import { decryptValue } from '../utilites/encryption-module';
import _ from 'lodash';
import async from 'async';

export function addRole(req, res) {

    let body = parseBody(req);
    console.log(body);
    // return;
    Role.getSpecificRole({ name: body.name }, (err, data) => {
        // console.log(data.length);
        // return;
        if (data.length == 0) {
            Role.addRole(body, function (err, result) {
                if (err) {
                    console.log(err);
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', err, res, [], []);

                }
                generateResponse(true, 'Updated Successfully', result, res, [], []);

            });
        }
        else {
            generateResponse(false, 'Role already exist. ', err, res, [], []);

        }
    });
}

export function getRole(req, res) {

    let queryParams = {
        page: req.query.page || 1,
        limit: req.query.limit || 10,
        sort: req.query.sort,
        sortby: req.query.sortby,
    };
    Role.getRoles(queryParams, (err, roles) => {

        if(err) {
            console.log(err);
            generateResponse(false, "Unable to Fetch Roles", null, res);
        }


        Role.countRoles(queryParams, (err, count) => {

            if (count != 0) {
                let data = {
                    data: roles,
                    current: queryParams.page,
                    pages: Math.ceil(count / queryParams.limit),
                    totalrecords: count
                }
                generateResponse(true, "Fetch Roles", data, res);
            }
            else {

                let data = {
                    data: roles,
                    current: queryParams.page,
                    pages: queryParams.page,
                    totalrecords: count
                }
                generateResponse(true, "Fetch Roles", data, res);
            }


        });
        /* let userCountFunctions = [];
        roles.forEach(function (item){
            let id = item._id;
            userCountFunctions.push((callback) => {
                Employee.countEmployee({ roleid: id }, (err, count) => {
                    if (err) return callback(err);
                    callback(null, count);
                });
            });
        });

        async.parallel(userCountFunctions, (err, results) => {

            for (let i = 0; i < results.length; i++) {
                roles[i]['users'] = results[i];

            }

            Role.countRoles(queryParams, (err, count) => {

                if (count != 0) {
                    let data = {
                        data: roles,
                        current: queryParams.page,
                        pages: Math.ceil(count / queryParams.limit),
                        totalrecords: count
                    }
                    generateResponse(true, "Fetch Roles", data, res);
                }
                else {

                    let data = {
                        data: roles,
                        current: queryParams.page,
                        pages: queryParams.page,
                        totalrecords: count
                    }
                    generateResponse(true, "Fetch Roles", data, res);
                }


            });

        }); */
    });

}
export function deleteRole(req, res) {

    /* let roleid = req.query.id; */
    let roleid = decryptValue(req.query.id);


    Employee.countEmployee({ roleid: roleid }, (err, count) => {
        if (err) return callback(err);

        if(count > 0){
            generateResponse(false, 'Unable to delete Role, Users Exists', null, res);
        }
        else{

            Role.deleteRole(roleid, (err, update) => {
                console.log(update);
                if (err) {
                    generateResponse(false, 'Unable to delete Role', null, res);
                }
                generateResponse(true, 'Role Deleted Successfully', null, res);
            });

        }
    });
}
export function updateRole(req, res) {

    let updateBody = parseBody(req);
    console.log(updateBody);
    Role.updateRole(updateBody, (err, update) => {
        console.log(update);

        if (err) {
            generateResponse(true, 'Updated Successfully', err, res, [], []);
        }
        generateResponse(true, 'Updated Successfully', update, res, [], []);
    });
}

export function getSpecificRole(req, res) {

    let roleid = decryptValue(req.params.id);
    /* console.log(roleid); */

    Role.getSpecificRole({ _id: roleid }, (err, role) => {

        if (err) {
            console.log(err.message);
            generateResponse(false, 'Unable to Fetched Speicific Role', null, res);
        }
        /* console.log(role); */
        generateResponse(true, 'Fetched Speicific Role', role, res);
    });
}

export function getAllUserGroup(req,res) {
    Role.getRoles("", function (err, data) {
        // console.log(res)
        generateResponse(true, 'Data', data, res, [], []);
    })
}

export function addUserGroupToRoute(req, res) {
    if (req.body){
        req.body.forEach(function (result) {
            // console.log(result.permissions);
            // console.log(result._id);
            let body = {
                permissions : result.permissions
            }
            Role.updateall(result._id,body, function (err, data) {
                generateResponse(true, 'Data', data, res, [], []);
            })


        })
        return;
        // Role.updateall(req.body, function (err, data) {
        //     console.log(data)
        //     generateResponse(true, 'Data', data, res, [], []);
        // })
    }
}
