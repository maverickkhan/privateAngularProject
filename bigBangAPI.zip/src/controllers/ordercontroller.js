/**
 * Created by Annas on 12/24/2018.
 */

'use strict';
import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hash, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import Order from '../models/order';
import Brand from '../models/brand';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
import mongoose from 'mongoose';
import {RandomValue} from "../utilites/helper";
// function getQueryParams(queryParams) {
//     let findParams = {};
//     findParams = {
//         'status.is_deleted': false,
//     };
//     if (queryParams.search) {
//         findParams['$or'] =
//             [
//                 { 'name': { $regex: queryParams.search, $options: 'i' } },
//                 { 'cities.city_name': { $regex: queryParams.search, $options: 'i' } },
//                 { 'cities.areas.area_name': { $regex: queryParams.search, $options: 'i' } }
//             ];
//     }
//     if (queryParams.status) {
//         findParams['status.is_activated'] = queryParams.status
//     }
//     if (queryParams.id != undefined && queryParams.id != "") {
//         findParams._id = decryptValue(queryParams.id) || "";
//     }
//     return findParams;
// }
// export function get(req, res) {
//     try {
//         var queryString = req.query;
//         searchQuery(Country, function (err, country) {
//             if (err) {
//                 var errors = err.errmsg;
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             } else {
//                 if (country.length > 0) {
//                     generateResponse(true, 'Success', country, res, ['_id'], []);
//                 } else {
//                     generateResponse(false, 'Record not found', country, res, [], []);
//                 }
//             }
//         }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
//     }
//     catch (err) {
//         generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
//     }
// }
export function create(req, res) {
    try {
        let body = parseBody(req);
        // console.log(req); return;
        if (body) {
            // console.log(body.offer[0].offer_id); return;
            if(body.offer != undefined && body.offer[0].offer_id != undefined){
                // console.log(mongoose.Types.ObjectId(body.offer[0].offer_id))
                Brand.get({"offer._id" : body.offer[0].offer_id}, (err, brand) => {
                    // console.log(brand); return;
                    Order.getMaxOrderNumber( (err, data) => {
                        // let max = { order_number : data[0].order_number + 1}
                        // console.log(data)
                        if(data[0]){
                            body["order_number"] = parseInt(data[0].order_number) + 1;
                        } else {
                            body["order_number"] = 10001
                        }

                        Order.add(body, function (err, order) {
                            if (err) {
                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
                            }
                            else {
                                // Replacement of order number with delivery code with new requirement
                                // order.order_number = brand[0].delivery_code;
                                // var order_number = order.order_number;
                                // order.order_number = order_number.toString();
                                // console.log(brand[0].delivery_code);
                                // console.log(order.order_number);
                                order.order_number = brand[0].delivery_code;
                                // console.log(order); return;
                                // End Replacement of order number
                                generateResponse(true, "Added Successfully", order, res, ['_id'], []);
                            }
                        });

                    })
                })
            }
        }
        else {
            generateResponse(false, 'Input fields required.', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getOrderByBrand(req, res) {
    try {
        Brand.getOrderByBrand(req.query, (err, data) => {
            if (data.length > 0){
                let temp = []
                let count = 0;
                data.forEach(function (value) {
                    temp[count] = value.order_details[0];
                    temp[count]["offer"] = value.offers;
                    count++;
                })
                generateResponse(true, 'Success', temp, res, ['_id'], []);
            } else {
                    generateResponse(false, 'Record not found', data, res, [], []);
                }

        })
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

    }
}

function makeReferid(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < length; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}

export function updateRandomCode(req, res) {
    try {
        Brand.get((err, brand) => {
            brand.forEach(function (b) {
                let code = makeReferid(5);
                let data =  {delivery_code : code}
                Brand.update(b._id,data,(err,result)=>{
                  if(err){
                      console.log(err)
                  } else {
                      console.log(result);
                  }
                })
            })

        })


    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

    }
}
// export function update(req, res) {
//     try {
//         if (req.params.id != undefined || req.params.id != "") {
//             req.params.id = decryptValue(req.params.id);
//             let body = parseBody(req);
//             if (body) {
//                 body.cities = {
//                     city_name: body['city_name']
//                 }
//                 body.cities.areas = {
//                     area_name: body['area_name']
//                 }
//                 Country.get({
//                     _id: req.params.id
//                 }, (err, country) => {
//                     if (err) {
//                         var errors = err.errmsg;
//                         generateResponse(false, ' Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                     }
//                     else {
//                         if (country.length > 0) {
//                             Country.update(req.params.id, body, (err, update) => {
//                                 console.log(update);
//                                 if (err) {
//                                     var errors = err.errmsg;
//                                     generateResponse(false, ' Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                                 }
//                                 else {
//                                     generateResponse(true, 'Updated Successfully', update, res, [], []);
//                                 }
//                             })
//                         }
//                         else {
//                             generateResponse(false, 'Record not found', [], res, [], []);
//                         }
//                     }
//                 });
//             }
//             else {
//                 generateResponse(false, "Unable to process your request, Please retry in few minutes", [], res, [], []);
//             }
//         }
//         else {
//             generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//         }
//     }
//     catch (err) {
//         generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//     }
// }
// export function remove(req, res) {
//     try {
//         if (req.params.id != undefined || req.params.id != "") {
//             req.params.id = decryptValue(req.params.id);
//             Country.get({
//                 _id: req.params.id
//             }, (err, country) => {
//                 if (err) {
//                     var errors = err.errmsg;
//                     generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                 }
//                 else {
//                     if (country.length > 0) {
//                         Country.remove(req.params.id, (err, update) => {
//                             console.log(update);
//                             if (err) {
//                                 var errors = err.errmsg;
//                                 generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
//                             }
//                             generateResponse(true, 'Removed Successfully', [], res, [], []);
//                         })
//                     }
//                     else {
//                         generateResponse(false, 'Record not found', [], res, [], []);
//                     }
//                 }
//             })
//         }
//         else {
//             generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//         }
//     }
//     catch (err) {
//         generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
//     }
// }
