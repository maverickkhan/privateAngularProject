/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { parseBody, generateResponse } from '../utilites';
import Category from '../models/category';
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import { decryptValue } from '../utilites/encryption-module';
import Country from "../models/country";
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                { 'bgcolor': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
        try {
            let id = decryptValue(req.query.id);
            let subname = (req.query.search) ? req.query.search : "";
            Category.getAggregateSubcategory(id,subname, (err, sub) => {
                generateResponse(true, 'Success', sub, res, ['_id'], []);
            })
        }
        catch (err) {
            generateResponse(false, ' Unable to process your request, Please retry in few minutes.', [], res, [], []);
        }
}
export function getOne(req, res) {
    try {
        let id = decryptValue(req.query.id);
        let sub_id = (req.query.sub_id) ? req.query.sub_id : "";
        Category.getAggregateSubcategoryOne(id,sub_id, (err, sub) => {
            generateResponse(true, 'Success', sub, res, ['_id'], []);
        })
    }
    catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', [], res, [], []);
    }
}
export function create(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                if ((body.sub_name != null || body.sub_name != undefined) && (body.sub_bgcolor != null || body.sub_bgcolor != undefined) && (req.files != null || req.files != undefined)) {
                    body.sub_icon = req.files[0]['path']
                    body.subCategory = {
                        sub_name: body.sub_name,
                        sub_icon: body.sub_icon,
                        sub_bgcolor: body.sub_bgcolor
                    }
                    Category.get({
                        _id: req.params.id
                    }, (err, data) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        }
                        else {
                            if (data.length > 0) {
                                Category.update(req.params.id,
                                    { $push: body }
                                    , (err, update) => {
                                        if (err) {
                                            var errors = err.errmsg;
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                        } else {
                                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                                        }
                                    })
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);

                            }
                        }
                    })

                }
                else {
                    generateResponse(false, 'One or more fields required', [], res, [], []);

                }
            }
            else {
                generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
            }

        }
        else {
            generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                if ((body.sub_name != null || body.sub_name != undefined) && (body.sub_bgcolor != null || body.sub_bgcolor != undefined) && (req.files != null || req.files != undefined)) {
                    body.sub_icon = req.files[0]['path']
                    let input = {
                        "subCategory.$.sub_name": body.sub_name,
                        "subCategory.$.sub_icon": body.sub_icon,
                        "subCategory.$.sub_bgcolor": body.sub_bgcolor,
                        "subCategory.$.timestamps.updated_at": new Date()
                    }
                    // body.subCategory = {
                    //     sub_name: body.sub_name,
                    //     sub_icon: body.sub_icon,
                    //     sub_bgcolor: body.sub_bgcolor
                    // }
                    Category.get({
                        _id: req.params.id
                    }, (err, data) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        }
                        else {
                            if (data.length > 0) {
                                console.log(req.params.id, body.sub_category_id, input)
                                Category.updateSubCat(req.params.id,
                                    body.sub_category_id,
                                    input
                                    , (err, update) => {
                                        if (err) {
                                            var errors = err.errmsg;
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                        } else {
                                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                                        }
                                    })
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);

                            }
                        }
                    })

                }
                else {
                    generateResponse(false, 'One or more fields required', [], res, [], []);

                }
            }
            else {
                generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
            }

        }
        else {
            generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body != undefined || body != null) {
                let input = [
                    { _id: mongoose.Types.ObjectId(req.params.id) },
                    { "subCategory._id": mongoose.Types.ObjectId(body.sub_category_id) },
                    { "subCategory.status.is_deleted": false },
                    { "subCategory.status.is_activated": true }
                ]
                Category.verifyExistance(
                    input
                    , (err, cat) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        } else {
                            if (cat.length > 0) {
                                var temp_count = 0
                                for (var i = 0; i < cat.length; i++) {
                                    if (cat[i]['status']['is_deleted'] == false) {
                                        for (var j = 0; j < cat[i]['subCategory'].length; j++) {
                                            if ((cat[i]['subCategory'][j]['_id'] == body.sub_category_id) && (cat[i]['subCategory'][j]['status']['is_deleted'] == false)) {
                                                temp_count++;
                                            }
                                        }
                                    }
                                }
                                if (cat.length > 0 && (temp_count == cat.length)) {
                                    Category.removeSubCat(req.params.id,
                                        body.sub_category_id,
                                        (err, update) => {
                                            console.log(update);
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                            }
                                            else {
                                                generateResponse(true, 'Removed Successfully.', [], res, [], ['offer', 'terms_and_condition']);
                                            }
                                        })
                                }
                                else {
                                    generateResponse(false, 'Record not found.', [], res, [], []);

                                }

                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    })
            }
            else {
                generateResponse(false, 'aUnable to process your request, Please retry in few minutes', [], res, [], []);
            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
