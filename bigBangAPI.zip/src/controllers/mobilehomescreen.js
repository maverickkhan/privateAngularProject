/**
 * Created by Annas on 12/24/2018.
 */

'use strict';
import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hash, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import Mobilehomescreen from '../models/mobilehomescreen';
import Section from '../models/section';
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import { decryptValue } from '../utilites/encryption-module';
import Country from "../models/country";
import mobilehomescreen from "../api/mobilehomescreen";
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Mobilehomescreen, function (err, mobilehomescreen) {
            if (err) {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
            } else {
                if (mobilehomescreen.length > 0) {
                    if(queryString.id){
                        let screen_id = decryptValue(queryString.id);
                        Section.get({"screen_id" : screen_id}, function (err, data) {
                            // mobilehomescreen["section"] = data;
                            // mobilehomescreen.push( {"section" : data });
                            mobilehomescreen[0].section = data;
                            // mobilehomescreen.assign({"section" : data})
                            generateResponse(true, 'Success', mobilehomescreen, res, ['_id'], []);
                        })
                    } else {
                        generateResponse(true, 'Success', mobilehomescreen, res, ['_id'], []);

                    }

                } else {
                    generateResponse(false, 'Record not found', mobilehomescreen, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {"section.sort_order" : -1}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}

export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body != undefined) {
            Mobilehomescreen.add(body.name, function (err, data) {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, "Input Error", errors, res, [], []);
                }
                else {
                    let section = body.section;
                    let arr = [];
                    section.forEach(function (result) {
                        result.screen_id  = mongoose.Types.ObjectId(data._id);
                        arr.push(result);
                    })
                    Section.addsection(arr, function (err, datasection) {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, "Input Error", errors, res, [], []);
                        }
                        else {
                            generateResponse(true, "Added Successfully", data, res, ['_id'], []);
                        }
                    })
                }
            });
        }
        else {
            generateResponse(false, 'One or more fields required', [], res, [], []);

        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        let body = parseBody(req);
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Mobilehomescreen.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (data.length > 0) {
                        if (body != undefined) {
                            Mobilehomescreen.update(req.params.id,body.name, function (err, result) {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                }
                                else {
                                    let section = body.section;
                                    let arr = [];
                                    section.forEach(function (section_result) {
                                        result.screen_id  = mongoose.Types.ObjectId(data._id);
                                        Section.update(mongoose.Types.ObjectId(section_result._id),req.params.id,section_result, function (err, section_update) {
                                        })

                                    })
                                    generateResponse(true, 'Updated Successfully.', result, res, [], []);
                                }
                            })
                        }
                        else {
                            generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
                        }
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Mobilehomescreen.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (data.length > 0) {
                        Mobilehomescreen.remove(req.params.id, (err, update) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            else {
                                Section.remove(req.params.id,(err, result) => {
                                    console.log(result);
                                })
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function removeSection(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = mongoose.Types.ObjectId(req.params.id);
            Section.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (data.length > 0) {
                        Section.removeSingle(req.params.id, (err, update) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            else {
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function createSection(req, res) {
    try {
        let body = parseBody(req);
        if (body != undefined) {
            req.params.id = decryptValue(req.params.id);
            Mobilehomescreen.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Screen id not valid.', errors, res, [], []);
                } else {
                    body.screen_id = req.params.id;
                    Section.addsection(body, function (err, data) {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, "Input Error", errors, res, [], []);
                        } else {
                            generateResponse(true, "Added Successfully", data, res, ['_id'], []);
                        }
                    });
                }
            })
        }
        else {
            generateResponse(false, 'One or more fields required', [], res, [], []);

        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
