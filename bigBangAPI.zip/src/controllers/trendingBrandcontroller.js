/**
 * Created by Annas on 12/24/2018.
 */
'use strict'
import { parseBody, generateResponse } from '../utilites';
import { searchQuery } from '../utilites/query-module';
import { decryptValue, encryptValue } from '../utilites/encryption-module';
import Brand from '../models/brand';
import mongoose from 'mongoose';
import TrendingBrand from '../models/trendingBrand'
import BrandLoaction from "../models/brandLocation";
function getQueryParams(queryParams) {
    // console.log(queryParams)
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'title': { $regex: queryParams.search, $options: 'i' } },
                { 'trendingBrandImage': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.offer_id != undefined && queryParams.offer_id != "") {
        findParams['link.offer_id'] = queryParams.offer_id;
    }
    if (queryParams.brand_id != undefined && queryParams.brand_id != "") {
        findParams['link.brand_id'] = queryParams.brand_id;
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
const promiseToGetBrand = (_id) => {

    return new Promise((resolve, reject) => {
        var toReject;
        Brand.get({
            _id: _id
        }, (err, brand) => {
            if (err) {
                var errors = {};
                var message = 'Validation Error'
                if (err.name == "ValidationError") {
                    for (var i in err.errors) {
                        errors[i] = err.errors[i].message;
                    }
                } else {
                    errors[i] = err.errmsg;
                }
                toReject = { message: message, error: errors }
                reject(toReject)
            }
            else {
                if (brand.length > 0) {
                    resolve(true)
                }
                else {
                    toReject = { message: 'Brand not found', error: [] }

                    reject(toReject)
                }
            }
        })
    })
}
const promiseToGetTrendingBrand = (input) => {

    return new Promise((resolve, reject) => {
        var toReject;
        TrendingBrand.get(input, (err, TrendingBrand) => {
            if (err) {
                var errors = {};
                var message = 'Validation Error'
                if (err.name == "ValidationError") {
                    for (var i in err.errors) {
                        errors[i] = err.errors[i].message;
                    }
                } else {
                    errors[i] = err.errmsg;
                }
                toReject = { message: message, error: errors }
                reject(toReject)
            }
            else {
                if (TrendingBrand.length > 0) {
                    resolve(true)
                }
                else {
                    toReject = { message: 'Trending Brand not found', error: [], status: false }

                    reject(toReject)
                }
            }
        })
    })
}
const promiseToAddTrendingBrand = (data) => {
    return new Promise((resolve, reject) => {
        TrendingBrand.add(data,
            (err, trending_brand) => {
                if (err) {
                    var errors = {};
                    var message = 'Validation Error'
                    if (err.name == "ValidationError") {
                        for (var i in err.errors) {
                            errors[i] = err.errors[i].message;
                        }
                    } else {
                        errors[i] = err.errmsg;
                    }
                    var toReject = { message: message, error: errors }
                    reject(toReject)
                }
                else {

                    resolve(trending_brand)

                }
            })
    })
}
const promiseToUpdateTrendingBrand = (_id, data) => {
    return new Promise((resolve, reject) => {
        TrendingBrand.update(_id, data,
            (err, trending_brand) => {
                if (err) {
                    var errors = {};
                    var message = 'Validation Error'
                    if (err.name == "ValidationError") {
                        for (var i in err.errors) {
                            errors[i] = err.errors[i].message;
                        }
                    } else {
                        errors[i] = err.errmsg;
                    }
                    var toReject = { message: message, error: errors }
                    reject(toReject)
                }
                else {

                    resolve(trending_brand)

                }
            })
    })
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(TrendingBrand, function (err, trendingBrand) {
            if (err) {
                generateResponse(false, 'Unable to process your request. Please retry in few minutes', [], res, [], [], []);
            } else {
                if (trendingBrand.length > 0) {
                    let brand_id_arr = []
                    trendingBrand.forEach(function (val) {
                        brand_id_arr.push(mongoose.Types.ObjectId(val.brand_id))
                    })
                    let filter = {_id : {$in :  brand_id_arr }, "offer.city_id" : mongoose.Types.ObjectId(queryString.city_id)}
                    Brand.get(filter, (err , data) => {
                        if(data.length > 0 ){
                            data.forEach(function(brands , key){
                                // console.log(brands)
                                // let brandlocation;
                                BrandLoaction.getBrandLocationsByBrandId(brands._id, (err, location_data) => {
                                    if(err){
                                        generateResponse(false, 'Error', err, res, [], []);
                                    } else {
                                        if(location_data.length > 0){
                                            data[key].locations = location_data;
                                            if(key === data.length - 1){
                                                generateResponse(true, 'Success', data, res, ['_id'], []);
                                            }
                                        }
                                    }
                                })
                            })

                        } else {
                            generateResponse(true, 'Record not found', [], res, ['_id'], []);
                        }
                    })
                } else {
                    generateResponse(false, 'Record not found', trendingBrand, res, [], [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], [], []);
    }
}
export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            TrendingBrand.get({
                brand_id: body.brand_id
            }, (err, TrendingBrand) => {
                if (err) {
                    var errors = {};
                    if (err.name == "ValidationError") {
                        for (var i in err.errors) {
                            errors[i] = err.errors[i].message;
                        }
                    } else {
                        errors[i] = err.errmsg;
                    }
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], [], []);

                }
                else {
                    if (TrendingBrand.length == 0) {
                        promiseToGetBrand(body.brand_id)
                            .then((brandExist) => {
                                if (brandExist) {
                                    return (promiseToAddTrendingBrand(body))
                                }
                            }).then((DataAdded) => {
                                if (DataAdded) {
                                    generateResponse(true, "Added Successfully", DataAdded, res, ['_id'], []);

                                }
                                else {
                                    generateResponse(false, 'Unable to process your request.Please retry in few minutes', [], res, [], [], []);

                                }
                            }).catch((fromReject) => {
                                generateResponse(false, fromReject.message, fromReject.error, res, [], [], []);

                            })
                    }
                    else {
                        generateResponse(false, 'Trending brand already exist', [], res, [], [], []);

                    }
                }
            })

        }
        else {
            generateResponse(false, 'Unable to process your request.Please retry in few minutes', errors, res, [], [], []);
        }
    }
    catch (err) {

        console.log(err)
        generateResponse(false, 'Unable to process your request.Please retry in few minutes', [], res, [], [], []);
    }
}
export function update(req, res) {
    try {
        let body = parseBody(req);
        if (req.params.id && body) {
            req.params.id = decryptValue(req.params.id);
            promiseToGetTrendingBrand({ _id: req.params.id })
                //checking if trending brand already exist
                .then(() => {
                    return promiseToGetBrand(body.brand_id)
                })
                .then(() => {
                    return promiseToUpdateTrendingBrand(req.params.id, body)
                })
                .then((DataUpdated) => {
                    if (DataUpdated) {
                        generateResponse(true, "Updated Successfully", DataUpdated, res, ['_id'], []);

                    }
                    else {
                        generateResponse(false, 'Unable to process your request.Please retry in few minutes', [], res, [], [], []);

                    }
                })
                .catch((fromReject) => {
                    generateResponse(false, fromReject.message, fromReject.error, res, [], [], []);

                })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            promiseToGetTrendingBrand({ _id: req.params.id })
                .then(() => {
                    TrendingBrand.remove(mongoose.Types.ObjectId(req.params.id), (err, remove) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
                        }
                        else {
                            generateResponse(true, 'Removed Successfully', remove, res, [], []);
                        }
                    })
                })
                .catch((fromReject) => {
                    generateResponse(false, fromReject.message, fromReject.error, res, [], [], []);

                })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function get_E_D(req, res) {
    try {
        let body;
        if(req.query){
             body = req.query;
        } else {
             body = parseBody(req);
        }
        if (body.e_Key) {
            var d_Key = decryptValue(body.e_Key)
            generateResponse(true, 'Success', [{ 'Decrypted_id': d_Key }], res, [], []);

        }
        if (body.d_Key){
            var e_Key = encryptValue(body.d_Key)
            generateResponse(true, 'Success', [{ 'Encrypted_id': e_Key }], res, [], []);
        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
