/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hash, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import Country from '../models/country';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                { 'cities.city_name': { $regex: queryParams.search, $options: 'i' } },
                { 'cities.areas.area_name': { $regex: queryParams.search, $options: 'i' } }
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Country, function (err, country) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
            } else {
                if (country.length > 0) {
                    generateResponse(true, 'Success', country, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', country, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function create(req, res) {
    try {
        let body = parseBody(req);
        if (body) {
            // body.cities = {
            //     city_name: body.city_name
            // }
            // body.cities.areas = {
            //     area_name: body.area_name
            // }

            // console.log(body);
            // console.log()
            // return
            Country.add(body, function (err, country) {
                if (err) {
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
                }
                else {
                    generateResponse(true, "Added Successfully", country, res, ['_id'], []);
                }
            });
        }
        else {
            generateResponse(false, 'Input fields required.', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                body.cities = {
                    city_name: body['city_name']
                }
                body.cities.areas = {
                    area_name: body['area_name']
                }
                Country.get({
                    _id: req.params.id
                }, (err, country) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, ' Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    }
                    else {
                        if (country.length > 0) {
                            Country.update(req.params.id, body, (err, update) => {
                                // console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, ' Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                }
                                else {
                                    generateResponse(true, 'Updated Successfully', update, res, [], []);
                                }
                            })
                        }
                        else {
                            generateResponse(false, 'Record not found', [], res, [], []);
                        }
                    }
                });
            }
            else {
                generateResponse(false, "Unable to process your request, Please retry in few minutes", [], res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Country.get({
                _id: req.params.id
            }, (err, country) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (country.length > 0) {
                        Country.remove(req.params.id, (err, update) => {
                            // console.log(update);
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            generateResponse(true, 'Removed Successfully', [], res, [], []);
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
