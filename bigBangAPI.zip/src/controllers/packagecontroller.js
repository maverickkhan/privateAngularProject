/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hash, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import Package from '../models/package';
import Country from '../models/country'
import Brand from '../models/brand';
import Category from '../models/category';
import mongoose from 'mongoose';
import _ from 'underscore'
import { decryptValue } from '../utilites/encryption-module';
import { searchQuery } from '../utilites/query-module';
import { realpathSync } from 'fs';
// import lodash_ from lodash;
var lodash = require('lodash');

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                // { 'features.brands': { $regex: queryParams.search, $options: 'i' } },
                // { 'features.offers': { $regex: queryParams.search, $options: 'i' } },
                // { 'features.categories': { $regex: queryParams.search, $options: 'i' } }
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    if (queryParams.city_id != undefined && queryParams.city_id != "") {
        findParams.city_id = queryParams.city_id;
    }
    if (queryParams.offer_id != undefined && queryParams.offer_id != "") {
        findParams['features.offers'] = queryParams.offer_id;
    }
    return findParams;
}

export function get(req, res) {
    try {
        var queryString = req.query;

        searchQuery(Package, function (err, pkgs) {
            if (err) {
                var errors = err.errmsg;
                console.log(err)
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
            } else {
                if (pkgs.length > 0) {
                    generateResponse(true, 'Success', pkgs, res, ['_id'], []);
                } else {
                    generateResponse(true, 'Record not found', pkgs, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function create(req, res) {
    try {
        let body = parseBody(req);
        if (!body) {
            generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
        } else {
            body.features = {
                // brands: body.brands,
                offers: body.offers,
                // categories: body.categories
            }
            body.is_expirable = {
                start_at: body.start_at,
                end_at: body.end_at
            }

            // console.log(body);
            // return;
            var arrObj = function arr_Obj(input) {
                var count = _.keys(input).length
                var arrObj = new Array();
                if ((count == 0) && (input != undefined || input != null)) {
                    var obj = JSON.stringify(input, function (key, value) {
                        arrObj.push(value);
                    })
                    return arrObj;
                } else {
                    if ((count > 0) && (input != undefined || input != null)) {
                        // var arrObj = [];
                        for (var i = 0; i < input.length; i++) {
                            arrObj[i] = mongoose.Types.ObjectId(input[i]);
                        }
                        return arrObj;
                    }
                }
            }
            var count = function count(input) {
                var count = _.keys(input).length
                return count;
            }
            if ((body.offers != null || body.offers != undefined)) {
                Brand.getRecord(
                    "offer._id",
                    arrObj(body.offers)
                    , (err, offer) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                        } else {
                            // lodash.forEach(offer, (value) => {
                            //     lodash.forEach(value.offer, (val) => {
                            //         lodash.forEach(body.offer, (val1) => {
                            //     //    console.log(val._id,val.status)
                            //             console.log(val1)
                            //         })
                            //     })

                            // });


                            let temp_count = 0
                            for (var i = 0; i < offer.length; i++) {
                                if (offer[i]['status']['is_deleted'] == false) {
                                    for (var j = 0; j < offer[i]['offer'].length; j++) {
                                        for (var k = 0; k < count(arrObj(body.offers)); k++) {
                                            if ((offer[i]['offer'][j]['_id'] == body.offers[k]) && (offer[i]['offer'][j]['status']['is_deleted'] == false) || (offer[i]['offer'][j]['_id'] == body.offers) && (offer[i]['offer'][j]['status']['is_deleted'] == false)) {
                                                temp_count++;
                                            }
                                        }
                                    }
                                }
                            }
                            // console.log(temp_count,count(arrObj(body.offers)),offer.length);
                            // console.log(body)
                            // return
                            // if (offer.length === count(arrObj(body.offers)) && (temp_count == offer.length)) {
                            if (temp_count === count(arrObj(body.offers))) {
                                Country.get({
                                    "cities._id": body.city_id
                                }, (err, city) => {
                                    if (err) {
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                    }
                                    else {
                                        if (city.length > 0) {
                                            Package.add(body, function (err, pkg) {
                                                if (err) {
                                                    var errors = err.errmsg;
                                                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                                } else {
                                                    generateResponse(true, "Added Successfully", pkg, res, ['_id'], []);
                                                }
                                            });
                                        }
                                        else {
                                            var errors = {
                                                error: "City does not exist"
                                            };
                                            generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                        }
                                    }
                                })

                            } else {
                                var errors = {
                                    error: "Offer does not exist"
                                };
                                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                            }

                        }
                    })
            } else {
                if (body.name != "" || body.name != null) {
                    Package.add(body, function (err, pkg) {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                        } else {
                            generateResponse(true, "Added Successfully", pkg, res, ['_id'], []);
                        }
                    });
                }
                else {
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);

                }
            }

        }
    } catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}

export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                body.features = {
                    // brands: body.brands,
                    offers: body.offers,
                    // categories: body.categories
                }
                body.is_expirable = {
                    start_at: body.start_at,
                    end_at: body.end_at,
                    is_expire: body.is_expire
                }
                var arrObj = function arr_Obj(input) {
                    var count = _.keys(input).length
                    var arrObj = new Array();
                    if ((count == 0) && (input != undefined || input != null)) {
                        var obj = JSON.stringify(input, function (key, value) {
                            arrObj.push(value);
                        })
                        return arrObj;
                    } else {
                        if ((count > 0) && (input != undefined || input != null)) {
                            // var arrObj = [];
                            for (var i = 0; i < input.length; i++) {
                                arrObj[i] = mongoose.Types.ObjectId(input[i]);
                            }
                            return arrObj;
                        }
                    }
                }
                var count = function count(input) {
                    var count = _.keys(input).length
                    return count;
                }
                var temp_count = 0;
                Package.get({
                    _id: req.params.id
                }, (err, pkg) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Package not found.', errors, res, [], []);
                    } else {

                        if (pkg.length > 0) {
                            if ((body.offers != null || body.offers != undefined)) {
                                Brand.getRecord(
                                    "offer._id",
                                    arrObj(body.offers)
                                    , (err, offer) => {
                                        if (err) {
                                            generateResponse(false, 'Offer not found.', errors, res, [], []);
                                        } else {
                                            temp_count = 0
                                            for (var i = 0; i < offer.length; i++) {
                                                if (offer[i]['status']['is_deleted'] == false) {
                                                    for (var j = 0; j < offer[i]['offer'].length; j++) {
                                                        for (var k = 0; k < count(arrObj(body.offers)); k++) {
                                                            if ((offer[i]['offer'][j]['_id'] == body.offers[k]) && (offer[i]['offer'][j]['status']['is_deleted'] == false) || (offer[i]['offer'][j]['_id'] == body.offers) && (offer[i]['offer'][j]['status']['is_deleted'] == false)) {
                                                                temp_count++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (offer.length === count(arrObj(body.offers)) && (temp_count == offer.length)) {
                                                Country.get({
                                                    "cities._id": body.city_id
                                                }, (err, city) => {
                                                    if (err) {
                                                        var errors = err.errmsg;
                                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                    }
                                                    else {
                                                        if (city.length > 0) {
                                                            Package.update(req.params.id,
                                                                body,
                                                                function (err, pkg) {
                                                                    if (err) {
                                                                        var errors = err.errmsg;
                                                                        generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                                                    } else {
                                                                        generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
                                                                    }
                                                                });
                                                        }
                                                        else {
                                                            var errors = {
                                                                error: "City does not exist"
                                                            };
                                                            generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                                        }
                                                    }
                                                })

                                            } else {
                                                var errors = {
                                                    error: "Offer does not exist"
                                                };
                                                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                            }

                                        }
                                    })
                            } else {
                                if (body.name != "" || body.name != null) {
                                    Package.update(req.params.id,
                                        body,
                                        function (err, pkg) {
                                            if (err) {
                                                var errors = err.errmsg;
                                                generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                                            } else {
                                                generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
                                            }
                                        });
                                }
                                else {
                                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);

                                }
                            }
                        } else {
                            var errors = {
                                error: " package does not exist"
                            };
                            generateResponse(false, 'Unable to process your request', errors, res, [], []);
                        }
                    }
                })
            } else {
                generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        console.log(err)
        var errors = err.errmsg;
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
    }
}

export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Package.get({
                _id: req.params.id
            }, (err, pkg) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                } else {
                    if (pkg.length > 0) {
                        Package.remove(req.params.id, (err, update) => {
                            // console.log(update);
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request Please retry in few minutes.', errors, res, [], []);
                            } else {
                                generateResponse(true, 'Removed Successfully.', [], res, [], []);
                            }
                        })
                    } else {
                        generateResponse(true, 'Record not found.', [], res, [], []);
                    }
                }
            })
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getPackageByCity(req, res){
    try{
        Package.getPackageByCity(req.query.city_id , (err , data) => {
            if(err){
                generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
            } else {
                generateResponse(true, "Packages by City", data, res, ['_id'], []);
            }

        })

    } catch(err){
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", err, res, [], []);
    }
}

// condition for brand offer and category

// if ((body.brands != null || body.brands != undefined) && (body.offers != null || body.offers != undefined) && (body.categories != null || body.categories != undefined)) {
//     var temp_count = 0;
//     Brand.getRecord('_id',
//         arrObj(body.brands)
//         , (err, brand) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 for (var i = 0; i < brand.length; i++) {
//                     if (brand[i]['status']['is_deleted'] == false) {
//                         temp_count++;
//                     }
//                 }
//                 if (brand.length === count(arrObj(body.brands)) && (temp_count == brand.length)) {
//                     Brand.getRecord(
//                         "offer._id",
//                         arrObj(body.offers)
//                         , (err, offer) => {
//                             if (err) {
//                                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                             }
//                             else {
//                                 temp_count = 0
//                                 for (var i = 0; i < offer.length; i++) {
//                                     if (offer[i]['status']['is_deleted'] == false) {
//                                         for (var j = 0; j < offer[i]['offer'].length; j++) {
//                                             for (var k = 0; k < count(arrObj(body.offers)); k++) {
//                                                 if ((offer[i]['offer'][j]['_id'] == body.offers[k]) && (offer[i]['offer'][j]['status']['is_deleted'] == false) || (offer[i]['offer'][j]['_id'] == body.offers) && (offer[i]['offer'][j]['status']['is_deleted'] == false)) {
//                                                     temp_count++;
//                                                 }
//                                             }
//                                         }
//                                     }
//                                 }
//                                 if (offer.length === count(arrObj(body.offers)) && (temp_count == offer.length)) {
//                                     Category.getRecord(
//                                         "_id",
//                                         arrObj(body.categories)
//                                         , (err, category) => {
//                                             if (err) {
//                                                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                             }
//                                             else {
//                                                 temp_count = 0
//                                                 for (i = 0; i < category.length; i++) {
//                                                     if (category[i]['status']['is_deleted'] == false) {
//                                                         temp_count++;
//                                                     }
//                                                 }
//                                                 if (category.length === count(arrObj(body.categories)) && (temp_count == category.length)) {
//                                                     Package.update(req.params.id, body, function (err, pkg) {
//                                                         if (err) {
//                                                             var errors = err.errmsg;
//                                                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                                                         }
//                                                         else {
//                                                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                                                         }
//                                                     });
//                                                 }
//                                                 else {
//                                                     var errors = {
//                                                         error: "category does not exist"
//                                                     };
//                                                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                                 }
//                                             }
//                                         });
//                                 }
//                                 else {
//                                     var errors = {
//                                         error: "Offer does not exist"
//                                     };
//                                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                 }
//                             }
//                         });
//                 }
//                 else {
//                     var errors = {
//                         error: "Brand does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//             }
//         });
// }
// else if ((body.brands != null || body.brands != undefined) && (body.offers == null || body.offers == undefined) && (body.categories == null || body.categories == undefined)) {
//     var temp_count = 0;
//     Brand.getRecord('_id',
//         arrObj(body.brands)
//         , (err, brand) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 for (var i = 0; i < brand.length; i++) {
//                     if (brand[i]['status']['is_deleted'] == false) {
//                         temp_count++;
//                     }
//                 }
//                 if (brand.length === count(arrObj(body.brands)) && (temp_count == brand.length)) {
//                     Package.update(req.params.id, body, function (err, pkg) {
//                         if (err) {
//                             var errors = err.errmsg;
//                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                         }
//                         else {
//                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                         }
//                     });
//                 }
//                 else {
//                     var errors = {
//                         error: "Brand does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//
//             }
//         })
// }
// else if ((body.brands == null || body.brands == undefined) && (body.offers != null || body.offers != undefined) && (body.categories == null || body.categories == undefined)) {
//     Brand.getRecord(
//         "offer._id",
//         arrObj(body.offers)
//         , (err, offer) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 // lodash.forEach(offer, (value) => {
//                 //     lodash.forEach(value.offer, (val) => {
//                 //         lodash.forEach(body.offer, (val1) => {
//                 //     //    console.log(val._id,val.status)
//                 //             console.log(val1)
//                 //         })
//                 //     })
//
//                 // });
//
//
//                 temp_count = 0
//                 for (var i = 0; i < offer.length; i++) {
//                     if (offer[i]['status']['is_deleted'] == false) {
//                         for (var j = 0; j < offer[i]['offer'].length; j++) {
//                             for (var k = 0; k < count(arrObj(body.offers)); k++) {
//                                 if ((offer[i]['offer'][j]['_id'] == body.offers[k]) && (offer[i]['offer'][j]['status']['is_deleted'] == false) || (offer[i]['offer'][j]['_id'] == body.offers) && (offer[i]['offer'][j]['status']['is_deleted'] == false)) {
//                                     temp_count++;
//                                 }
//                             }
//                         }
//                     }
//                 }
//                 if (offer.length === count(arrObj(body.offers)) && (temp_count == offer.length)) {
//                     Package.update(req.params.id, body, function (err, pkg) {
//                         if (err) {
//                             var errors = err.errmsg;
//                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                         }
//                         else {
//                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                         }
//                     });
//                 }
//                 else {
//                     var errors = {
//                         error: "Offer does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//
//             }
//         })
// }
// else if ((body.brands == null || body.brands == undefined) && (body.offers == null || body.offers == undefined) && (body.categories != null || body.categories != undefined)) {
//     Category.getRecord(
//         "_id",
//         arrObj(body.categories)
//         , (err, category) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 temp_count = 0
//                 for (var i = 0; i < category.length; i++) {
//                     if (category[i]['status']['is_deleted'] == false) {
//                         temp_count++;
//                     }
//                 }
//                 if (category.length === count(arrObj(body.categories)) && (temp_count == category.length)) {
//                     Package.update(req.params.id, body, function (err, pkg) {
//                         if (err) {
//                             var errors = err.errmsg;
//                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                         }
//                         else {
//                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                         }
//                     });
//                 }
//                 else {
//                     var errors = {
//                         error: "category does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//             }
//         });
//
// }
// else if ((body.brands != null || body.brands != undefined) && (body.offers != null || body.offers != undefined) && (body.categories == null || body.categories == undefined)) {
//     var temp_count = 0;
//     Brand.getRecord('_id',
//         arrObj(body.brands)
//         , (err, brand) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 for (var i = 0; i < brand.length; i++) {
//                     if (brand[i]['status']['is_deleted'] == false) {
//                         temp_count++;
//                     }
//                 }
//                 if (brand.length === count(arrObj(body.brands)) && (temp_count == brand.length)) {
//                     Brand.getRecord(
//                         "offer._id",
//                         arrObj(body.offers)
//                         , (err, offer) => {
//                             if (err) {
//                                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                             }
//                             else {
//                                 temp_count = 0
//                                 for (var i = 0; i < offer.length; i++) {
//                                     if (offer[i]['status']['is_deleted'] == false) {
//                                         for (var j = 0; j < offer[i]['offer'].length; j++) {
//                                             for (var k = 0; k < count(arrObj(body.offers)); k++) {
//                                                 if ((offer[i]['offer'][j]['_id'] == body.offers[k]) && (offer[i]['offer'][j]['status']['is_deleted'] == false) || (offer[i]['offer'][j]['_id'] == body.offers) && (offer[i]['offer'][j]['status']['is_deleted'] == false)) {
//                                                     temp_count++;
//                                                 }
//                                             }
//                                         }
//                                     }
//                                 }
//                                 if (offer.length === count(arrObj(body.offers)) && (temp_count == offer.length)) {
//                                     Package.update(req.params.id, body, function (err, pkg) {
//                                         if (err) {
//                                             var errors = err.errmsg;
//                                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                                         }
//                                         else {
//                                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                                         }
//                                     });
//                                 }
//                                 else {
//                                     var errors = {
//                                         error: "Offer does not exist"
//                                     };
//                                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                 }
//                             }
//                         });
//                 }
//                 else {
//                     var errors = {
//                         error: "Brand does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//             }
//         });
// }
// else if ((body.brands != null || body.brands != undefined) && (body.offers == null || body.offers == undefined) && (body.categories != null || body.categories != undefined)) {
//     var temp_count = 0;
//     Brand.getRecord('_id',
//         arrObj(body.brands)
//         , (err, brand) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 for (var i = 0; i < brand.length; i++) {
//                     if (brand[i]['status']['is_deleted'] == false) {
//                         temp_count++;
//                     }
//                 }
//                 if (brand.length === count(arrObj(body.brands)) && (temp_count == brand.length)) {
//
//                     Category.getRecord(
//                         "_id",
//                         arrObj(body.categories)
//                         , (err, category) => {
//                             if (err) {
//                                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                             }
//                             else {
//                                 temp_count = 0
//                                 for (i = 0; i < category.length; i++) {
//                                     if (category[i]['status']['is_deleted'] == false) {
//                                         temp_count++;
//                                     }
//                                 }
//                                 if (category.length === count(arrObj(body.categories)) && (temp_count == category.length)) {
//                                     Package.update(req.params.id, body, function (err, pkg) {
//                                         if (err) {
//                                             var errors = err.errmsg;
//                                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                                         }
//                                         else {
//                                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                                         }
//                                     });
//                                 }
//                                 else {
//                                     var errors = {
//                                         error: "category does not exist"
//                                     };
//                                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                 }
//
//
//                             }
//                         });
//                 }
//                 else {
//                     var errors = {
//                         error: "Brand does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//             }
//         });
// }
// else if ((body.brands == null || body.brands == undefined) && (body.offers != null || body.offers != undefined) && (body.categories != null || body.categories != undefined)) {
//     var temp_count = 0;
//     Brand.getRecord(
//         "offer._id",
//         arrObj(body.offers)
//         , (err, offer) => {
//             if (err) {
//                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//             }
//             else {
//                 temp_count = 0
//                 for (var i = 0; i < offer.length; i++) {
//                     if (offer[i]['status']['is_deleted'] == false) {
//                         for (var j = 0; j < offer[i]['offer'].length; j++) {
//                             for (var k = 0; k < count(arrObj(body.offers)); k++) {
//                                 if ((offer[i]['offer'][j]['_id'] == body.offers[k]) && (offer[i]['offer'][j]['status']['is_deleted'] == false) || (offer[i]['offer'][j]['_id'] == body.offers) && (offer[i]['offer'][j]['status']['is_deleted'] == false)) {
//                                     temp_count++;
//                                 }
//                             }
//                         }
//                     }
//                 }
//                 if (offer.length === count(arrObj(body.offers)) && (temp_count == offer.length)) {
//                     Category.getRecord(
//                         "_id",
//                         arrObj(body.categories)
//                         , (err, category) => {
//                             if (err) {
//                                 generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                             }
//                             else {
//                                 temp_count = 0
//                                 for (i = 0; i < category.length; i++) {
//                                     if (category[i]['status']['is_deleted'] == false) {
//                                         temp_count++;
//                                     }
//                                 }
//                                 if (category.length === count(arrObj(body.categories)) && (temp_count == category.length)) {
//                                     Package.update(req.params.id, body, function (err, pkg) {
//                                         if (err) {
//                                             var errors = err.errmsg;
//                                             generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
//                                         }
//                                         else {
//                                             generateResponse(true, "Updated Successfully", pkg, res, ['_id'], []);
//                                         }
//                                     });
//                                 }
//                                 else {
//                                     var errors = {
//                                         error: "category does not exist"
//                                     };
//                                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                                 }
//                             }
//                         });
//                 }
//                 else {
//                     var errors = {
//                         error: "Offer does not exist"
//                     };
//                     generateResponse(false, 'Unable to process your request.', errors, res, [], []);
//                 }
//             }
//         });
// }
// else if ((body.brands == null || body.brands == undefined) && (body.offers == null || body.offers == undefined) && (body.categories == null || body.categories == undefined)) {
//     generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
// }
// else {
//     generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
// }
