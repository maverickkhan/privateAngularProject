import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hash, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import Collections from '../models/collections';
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import { decryptValue, encryptValue } from '../utilites/encryption-module';
import Brand from "../models/brand";
import Brandlocation from "../models/brandLocation";
import Category from "../models/category";

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}

export function create(req, res) {
    try {
        let body = parseBody(req);
        // var icon_path;
        // var subCat_icon_path = [];
        if (body != undefined && req.files != undefined) {
            body.banner = req.files[0]['path']
            Collections.add(body, function (err, data) {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                } else {
                    generateResponse(true, "Added Successfully", data, res, ['_id'], []);
                }
            });
        } else {
            generateResponse(false, 'One or more fields required', [], res, [], []);

        }
    } catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Collections, function (err, collections) {
            if (err) {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
            } else {
                if(collections.length > 0){
                    if (queryString.id) {
                        if(collections[0].brand != undefined || collections[0].brand != [] || collections[0].brand != null){
                            if (collections[0].brand.length > 0) {
                                var count = 0;
                                Brandlocation.getAllLocations({},(err, brand_location) => {
                                    if(err){
                                        console.log(err)
                                    }

                                        collections[0].brand.forEach(function (val) {
                                            // console.log({"_id": mongoose.Types.ObjectId(val.brand_id)})
                                            // console.log(queryString.city_id)
                                            let query = { $and: [ { "_id": mongoose.Types.ObjectId(val.brand_id) }, { "offer.city_id" : mongoose.Types.ObjectId(queryString.city_id) } ] }
                                            // console.log(val);
                                            Brand.get(query, function (err, data) {
                                                if (err) {
                                                    console.log(err)
                                                } else {
                                                    // console.log(data)
                                                    if(data.length > 0) {
                                                        let locations = [];
                                                        collections[0].brand[count].views = data[0].views;
                                                        collections[0].brand[count].name = data[0].name;
                                                        collections[0].brand[count].icon = data[0].icon;
                                                        collections[0].brand[count].specialties = data[0].specialties;
                                                        collections[0].brand[count].description = data[0].description;
                                                        collections[0].brand[count].brand_id = encryptValue(collections[0].brand[count].brand_id)
                                                        // brand_location.forEach(function (location_value) {
                                                        //     console.log(location_value.brand_id + " ===== " + collections[0].brand[count].brand_id)
                                                        //     if(location_value.brand_id === collections[0].brand[count].brand_id){
                                                        //         locations.push(location_value)
                                                        //     }
                                                        // })
                                                        collections[0].brand[count].locations = locations;

                                                    }
                                                    count++;

                                                    if (collections[0].brand.length == count) {
                                                        let col = [];
                                                        // console.log(collections)
                                                        let count = 0;
                                                        collections.forEach(function (val) {
                                                            col[count] = {
                                                                _id : val._id,
                                                                timestamps : val.timestamps,
                                                                status : val.status,
                                                                name : val.name,
                                                                banner : val.banner,
                                                                brand : []

                                                            }
                                                            val.brand.forEach(function (brand, key) {

                                                                if (brand.name[0]){
                                                                    let locations = []
                                                                    // console.log(brand_location); return;
                                                                    brand_location.forEach(function (location_data) {
                                                                        let brand_id = decryptValue(brand.brand_id);
                                                                        // console.log(brand_id + " ==== " + location_data.brand_id )
                                                                        // console.assert(brand_id.equals(location_data.brand_id))
                                                                        if(String(brand_id) === String(location_data.brand_id)){
                                                                            // console.log(decryptValue(brand.brand_id))
                                                                            locations.push(location_data)
                                                                        }
                                                                    })

                                                                    brand.locations = locations;
                                                                    col[count].brand.push(brand)

                                                                }
                                                            })
                                                            count++;
                                                        })
                                                        generateResponse(true, 'Success', col, res, ['_id'], []);
                                                    }


                                                }

                                            })
                                        })


                                })
                            } else {
                            generateResponse(true, 'Success', collections, res, ['_id'], []);
                        }
                        } else {
                            generateResponse(false, 'Brand not found in  collection', [], res, ['_id'], []);
                        }
                    } else {
                        if (collections.length > 0) {
                            generateResponse(true, 'Success', collections, res, ['_id'], []);
                        } else {
                            generateResponse(false, 'Record not found', collections, res, [], []);
                        }
                    }
                } else {
                    generateResponse(false, 'Record not found', collections, res, [], []);
                }
                // if (collections.length > 0) {
                //     generateResponse(true, 'Success', collections, res, ['_id'], []);
                // } else {
                //     generateResponse(false, 'Record not found', collections, res, [], []);
                // }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}

export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Collections.get({
                _id: req.params.id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                } else {
                    if (data.length > 0) {
                        // console.log(req.files.length); return;
                        // var icon_path;
                        // var subCat_icon_path = [];
                        if (body != undefined) {
                            if (req.files.length > 0) {
                                body.banner = req.files[0]['path']
                            }
                            Collections.update(req.params.id, body, (err, update) => {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    generateResponse(true, 'Updated Successfully.', update, res, [], []);
                                }
                            });
                        } else {
                            generateResponse(false, 'One or more fields required.', [], res, [], []);
                        }
                    } else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Collections.get({
                _id: req.params.id
            }, (err, category) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                } else {
                    if (category.length > 0) {
                        Collections.remove(req.params.id, (err, update) => {
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            } else {
                                generateResponse(true, 'Removed Successfully', [], res, [], []);
                            }
                        })
                    } else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function addBrandsToCollection(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id)
            let body = {}
            body.brand = []
            let bodyData = parseBody(req);

            bodyData.forEach(function (val) {
                // let brand_id = decryptValue(val.brand_id);
                // console.log(val.brand_id)
                // console.log(decryptValue(val.brand_id))
                let brand_id = decryptValue(val.brand_id)
                let temp = {
                    'brand_id': mongoose.Types.ObjectId(brand_id)
                }
                body.brand.push(temp);
            })
// console.log(body)
            if (body != undefined) {
                Collections.addBrand(req.params.id, body, function (err, data) {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, "Unable to process your request, Please retry in few minutes.", errors, res, [], []);
                    } else {
                        generateResponse(true, "Added Successfully", data, res, ['_id'], []);
                    }
                });
            } else {
                generateResponse(false, 'One or more fields required', [], res, [], []);

            }
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
