/**
 * Created by Annas on 12/24/2018.
 */


'use strict';
import { parseBody, generateResponse } from '../utilites';
import Brand from '../models/brand';
import Category from '../models/category';
import Customer from '../models/customer';
import BrandLoaction from '../models/brandLocation';
import Package from '../models/package';
import { searchQuery } from '../utilites/query-module';
import mongoose from 'mongoose';
import moment from 'moment';
import _ from 'underscore'
import { decryptValue, encryptValue } from '../utilites/encryption-module';
import { realpathSync } from 'fs';
// import { parseDate } from 'tough-cookie';
const lodash = require('lodash');

// let Brand = module.exports = mongoose.model('brands', brandSchema);
function getQueryParams(queryParams) {
    let findParams = {};
    // console.log(findParams,"hello")
    findParams = {
        'status.is_deleted': false,
    };
    // console.log(queryParams.id)
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'name': { $regex: queryParams.search, $options: 'i' } },
                // { 'phone_number': { $regex: queryParams.search, $options: 'i' } },
                // { 'description': { $regex: queryParams.search, $options: 'i' } },
                // { 'terms_and_condition': { $regex: queryParams.search, $options: 'i' } },
                // { 'location.address': { $regex: queryParams.search, $options: 'i' } },
                // { 'location.longitude': { $regex: queryParams.search, $options: 'i' } },
                // { 'location.latitude': { $regex: queryParams.search, $options: 'i' } },
                // { 'specialties.speciality_name': { $regex: queryParams.search, $options: 'i' } },
                // { 'specialties.speciality_icon': { $regex: queryParams.search, $options: 'i' } },
                // { 'facilities.facility_name': { $regex: queryParams.search, $options: 'i' } },
                // { 'facilities.facility_icon': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if ((queryParams.from != undefined && queryParams.from != "") && (queryParams.to != undefined && queryParams.to != "")) {
        findParams['timestamps.created_at'] = { $gte: new Date(queryParams.from), $lt: new Date(queryParams.to) };
    }
    if (queryParams.latestbrands != undefined && queryParams.latestbrands != "") {
        findParams['timestamps.created_at'] = { $gte: new Date() - 1000 * 3600 * 24 * queryParams.latestbrands, $lt: new Date() };
    }
    if (queryParams.limit != undefined && queryParams.limit != "") {
        findParams['views'] = { $gte: 0 };
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    if (queryParams.city_id != undefined && queryParams.city_id != "") {
        findParams["offer.city_id"] = mongoose.Types.ObjectId(queryParams.city_id);
    }
    if (queryParams.is_featured != undefined && queryParams.is_featured != "") {
        findParams["is_featured"] = queryParams.is_featured
    }
    if (queryParams.is_deliverable != undefined && queryParams.is_deliverable != "") {
        findParams["offer.is_deliverable"] = queryParams.is_deliverable
    }

    return findParams;
}
function minutesToStandard(model) {
    function minutesToStandardTime(minutes) {
        var military_time = Math.floor(minutes / 60) + ':' + minutes % 60
        var mTime = moment(military_time, "hh:m")
        var standardTime = moment(mTime).format('LT');
        // console.log('here')
        // // console.log(moment(mTime).endOf('hour').fromNow());
        // // console.log(moment(mTime).startOf('hour').fromNow());
        // console.log(minutesToStandardTime(standardTimetoMinutes('9:30 PM')))
        return standardTime;
    }
    // console.log(model[0]['location'][0]['timings']);
    lodash.forEach(model, (val) => {
        lodash.forEach(val.location, (val1) => {
            lodash.forEach(val1.timings, (val2) => {
                val2.open = minutesToStandardTime(val2.open)
                val2.close = minutesToStandardTime(val2.close)

            })
        });
    });

    return model;
}
export function get(req, res) {
    try {
        var queryString = req.query;
         searchQuery(Brand, function (err, brand) {
             // console.log(brand)
            if (err) {
                console.log(err)
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            } else {
                if (brand.length > 0) {
                    if (queryString != null) {
                        if (queryString.id != null && brand.length == 1) {
                            queryString.id = decryptValue(queryString.id)
                            let brand_location = () => {
                                return new Promise((resolve, reject) => {
                                    BrandLoaction.get({
                                        brand_id: queryString.id, city_id : mongoose.Types.ObjectId(queryString.city_id)
                                    }, (err, brandLoaction) => {
                                        if (err) {
                                            reject(err)
                                        }
                                        else {
                                            if (brandLoaction.length > 0) {
                                                resolve(brandLoaction)
                                            }
                                            else{
                                                resolve([])
                                            }
                                        }
                                    })

                                })
                            }
                            brand_location().then((from_resolve) => {
                                // var location = { location: from_resolve[0] }
                                // Object.assign(brand[0], location)

                                brand[0]['location'] = from_resolve
                                Brand.updateBrandViews(queryString.id, (err, update) => {
                                    if (err) {
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                                        console.log(err)
                                    }
                                    else {
                                        if(req.query.customer_id){
                                            Customer.get({_id : decryptValue(req.query.customer_id)}, (err, customer) => { //customer_id
                                                // console.log(customer[0].subscription)
                                                let sub_ids = []
                                                customer[0].subscription.forEach(sub_id =>{
                                                    sub_ids.push(mongoose.Types.ObjectId(sub_id.package_id))
                                                })
                                                Package.getPackageByPackageIds(sub_ids, (err, package_data) => {
                                                    //offer id nikal kar brand ki offer se match karni hai
                                                    let package_offer_ids = []
                                                    package_data.forEach(packdata =>{
                                                        packdata.features.offers.forEach(offer_ids =>{
                                                            package_offer_ids.push(offer_ids)
                                                        })

                                                    })
                                                    // console.log(package_offer_ids);
                                                    let offer_ids = []
                                                    brand[0].offer.forEach(data =>{
                                                        offer_ids.push(data._id)
                                                    })
                                                    // console.log(offer_ids)
                                                    let final_offer_data =[]
                                                    offer_ids.forEach(oid => {
                                                        package_offer_ids.forEach(poi => {
                                                            if(oid.equals(poi)){
                                                                let oData = {
                                                                    offer_id : oid,
                                                                    lock : false
                                                                }
                                                                final_offer_data.push(oData)
                                                            }


                                                        })

                                                    })
                                                    // console.log(final_offer_data)
                                                    // let offer_lock = {lock: final_offer_data}
                                                    brand[0]['lock'] = final_offer_data
                                                    minutesToStandard(brand);
                                                    generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
                                                })
                                            })
                                        } else {
                                            minutesToStandard(brand);
                                            generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
                                        }


                                    }
                                });
                            }).catch((from_reject) => generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], from_reject, [], []))


                        }
                        else {
                            minutesToStandard(brand);
                            generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);

                        }
                    }
                    else {
                        minutesToStandard(brand);
                        generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);

                    }
                }
                else {
                    generateResponse(false, 'Record not found.', brand, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {"sort_order" : 1}, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function getBrandbyCustomer(req, res) {
    try {
        var queryString = req.query;
        Customer.get({
            _id: queryString.customer_id
        }, (err, customer) => {
            if (err) {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
            else {
                if (customer.length > 0) {
                    var pkg_id = [];
                    var city_id;
                    lodash.forEach(customer, (val) => {
                        city_id = val.city
                        lodash.forEach(val.subscription, (val1) => {
                            if (val1.subscription_status == true) {
                                pkg_id.push(val1.package_id);
                            }
                        });
                    });
                    Package.get({
                        '_id': { $in: pkg_id }
                    }, (err, pkg) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        }
                        else {
                            if (pkg.length > 0) {
                                var offer_id;
                                lodash.forEach(pkg, (val) => {
                                    lodash.forEach(val.features, (val1) => {
                                        offer_id = val1;
                                    });
                                });
                                Brand.get(
                                    {
                                        'offer._id': { $in: offer_id }
                                    }
                                    , (err, brand) => {
                                        if (err) {
                                            var errors = err.errmsg;
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                        }
                                        else {
                                            if (brand.length > 0) {
                                                var offer_ids = [];
                                                lodash.forEach(brand, (val) => {
                                                    lodash.forEach(val.offer, (val1) => {
                                                        lodash.forEach(offer_id, (val2) => {
                                                            if ((JSON.stringify(val1._id) == JSON.stringify(val2)) && (JSON.stringify(val1.city_id) == JSON.stringify(city_id))) {
                                                                offer_ids.push(val1._id);
                                                            }
                                                        });
                                                    });
                                                });
                                                Brand.getBrandwithoutoffers(
                                                    {
                                                        'offer._id': { $in: offer_ids }
                                                    }
                                                    , (err, brand) => {
                                                        if (err) {
                                                            var errors = err.errmsg;
                                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                        }
                                                        else {
                                                            if (brand.length > 0) {
                                                                generateResponse(true, 'Success', brand, res, [], []);

                                                            }
                                                            else {
                                                                generateResponse(false, 'Record not found', [], res, [], []);

                                                            }
                                                        }


                                                    })
                                            }
                                            else {
                                                generateResponse(false, 'Record not found', [], res, [], []);

                                            }
                                        }


                                    })

                            }
                            else {
                                generateResponse(false, 'Record not found', [], res, [], []);

                            }
                        }
                    })
                }
                else {
                    generateResponse(false, 'Record not found', [], res, [], []);

                }
            }
        })
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function getOfferbyCustomer(req, res) {
    try {
        var queryString = req.query;
        Customer.get({
            _id: queryString.customer_id
        }, (err, customer) => {
            if (err) {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
            else {
                if (customer.length > 0) {
                    var pkg_id = [];
                    var city_id;
                    lodash.forEach(customer, (val) => {
                        city_id = val.city
                        lodash.forEach(val.subscription, (val1) => {
                            if (val1.subscription_status == true) {
                                pkg_id.push(val1.package_id);
                            }
                        });
                    });

                    Package.get({
                        '_id': { $in: pkg_id }
                    }, (err, pkg) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        }
                        else {
                            if (pkg.length > 0) {
                                var pkg_offer_id;
                                lodash.forEach(pkg, (val) => {
                                    lodash.forEach(val.features, (val1) => {
                                        pkg_offer_id = val1;
                                    });
                                });
                                Brand.get(
                                    {
                                        '_id': queryString.brand_id
                                    }
                                    , (err, brand) => {
                                        if (err) {
                                            var errors = err.errmsg;
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                        }
                                        else {
                                            if (brand.length > 0) {
                                                var brand_offer_id = [];
                                                var final_offer_id = [];
                                                lodash.forEach(brand, (val) => {
                                                    lodash.forEach(val.offer, (val1) => {
                                                        if (JSON.stringify(val1.city_id) == JSON.stringify(city_id)) {
                                                            brand_offer_id.push(val1._id);
                                                        }
                                                    });
                                                });
                                                lodash.forEach(pkg_offer_id, (val) => {
                                                    lodash.forEach(brand_offer_id, (val1) => {
                                                        if (JSON.stringify(val) == JSON.stringify(val1)) {
                                                            final_offer_id.push(val1);
                                                        }
                                                    })
                                                })
                                                Brand.getoffer(
                                                    final_offer_id
                                                    , (err, offers) => {
                                                        if (err) {
                                                            var errors = err.errmsg;
                                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                        }
                                                        else {
                                                            if (offers.length > 0) {
                                                                var data = brand[0];
                                                                var selectedoffers = []
                                                                lodash.forEach(offers, (val) => {
                                                                    selectedoffers.push(val.offer)
                                                                })
                                                                let final_offers =
                                                                {
                                                                    _id: data._id,
                                                                    name: data.name,
                                                                    offer: selectedoffers,

                                                                    // categories: data.categories,
                                                                    // timestamps:
                                                                    // {
                                                                    //     updated_at: data.timestamps.updated_at,
                                                                    //     created_at: data.timestamps.created_at
                                                                    // },
                                                                    // status: { is_deleted: data.status.is_deleted, is_activated: data.status.is_activated },
                                                                    // menuImages: data.menuImages,
                                                                    // tags: data.tags,
                                                                    // views: data.views,
                                                                    // phone_number: data.phone_number,
                                                                    // description: data.description,
                                                                    // webUrl: data.webUrl,
                                                                    // socialMediaLinks: data.socialMediaLinks,
                                                                    // specialties: data.specialties,
                                                                    // facilities: data.facilities
                                                                }
                                                                generateResponse(true, 'Success', final_offers, res, [], []);
                                                            }
                                                            else {
                                                                generateResponse(false, 'Record not found', [], res, [], []);

                                                            }
                                                        }
                                                    })
                                                // console.log(pkg_offer_id, 'Pkg offer_id')
                                                // console.log(brand_offer_id, 'brand offer_id')
                                                // console.log(final_offer_id, 'final list')

                                                // return;

                                            }
                                            else {
                                                generateResponse(false, 'Record not found', [], res, [], []);

                                            }
                                        }


                                    })
                            }
                            else {
                                generateResponse(false, 'Record not found', [], res, [], []);

                            }
                        }
                    })
                }
            }
        })

    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function getPopularBrands(req, res) {
    try {

        var queryString = req.query;
        // console.log(queryString);
        searchQuery(Brand, function (err, brand) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
            } else {
                if (brand.length > 0) {
                    minutesToStandard(brand); generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
                }
                else {
                    generateResponse(false, 'Record not found', brand, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, { views: 'descending' }, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}
export function getLatestBrands(req, res) {
    try {

        var queryString = req.query;
        // console.log(queryString);
        // console.log(new Date(2018-12-13) -5);

        searchQuery(Brand, function (err, brand) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
            } else {
                if (brand.length > 0) {
                    let brand_data=[];
                    brand.forEach(function(brands , key){
                        // console.log(brands)
                        // let brandlocation;
                        BrandLoaction.getBrandLocationsByBrandId(brands._id, (err, location_data) => {
                            if(err){
                                generateResponse(false, 'Error', err, res, [], []);
                            } else {
                                if(location_data.length > 0){
                                    brand[key].locations = location_data;
                                    if(key === brand.length - 1){
                                        minutesToStandard(brand);
                                        generateResponse(true, 'Success', brand, res, ['_id'], ['offer', 'terms_and_condition']);
                                    }
                                }
                            }
                        })
                    })

                }
                else {
                    generateResponse(false, 'Record not found', brand, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, { 'timestamps.created_at': -1 }, getQueryParams(queryString), '');
    }
    catch (err) {
        generateResponse(false, "Unable to process your request, Please retry in few minutes.", [], res, [], []);
    }
}
export function create(req, res) {
    try {
        let body = parseBody(req);
        var menu_Images_path = [];
        var banner;
        var icon;
        if (body != undefined && req.files != undefined) {
            for (var i = 0; i < req.files.length; i++) {

                if (req.files[i]['fieldname'] === 'menuImages') {
                    menu_Images_path.push(req.files[i]['path']);
                }
                if (req.files[i]['fieldname'] === 'banner') {
                    banner = req.files[i]['path']
                }
                if (req.files[i]['fieldname'] === 'icon') {
                    icon = req.files[i]['path']
                }
            }

            body.menuImages = menu_Images_path
            body.banner = banner
            body.icon = icon
            // console.log(banner)
            // var arrObj_array = new Array();
            var arrObj = function arr_Obj(input) {
                var count = _.keys(input).length
                var arrObj = new Array();
                if ((count == 0) && (input != undefined || input != null)) {
                    var obj = JSON.stringify(input, function (key, value) {
                        // value = decryptValue(value)
                        arrObj.push(value);
                    })
                    // console.log(arrObj)

                    return arrObj;
                }
                else {
                    if ((count > 0) && (input != undefined || input != null)) {
                        for (var i = 0; i < input.length; i++) {
                            // input[i] = decryptValue(input[i])
                            arrObj[i] = mongoose.Types.ObjectId(input[i]);
                        }
                        // console.log(arrObj)

                        return arrObj;
                    }
                }
            }
            var count = function count(input) {
                var count = _.keys(input).length
                return count;
            }
            var temp_count = 0;

            // console.log(JSON.stringify(body.categories.parent),body.categories.parent,"=====")
            // console.log( arrObj(body.categories.parent))
            // return;
            // console.log(JSON.stringify(body.categories.parent),body.categories.parent,"=====")
            // console.log(arrObj(body.categories.parent))
            // return;
            // console.log(JSON.parse(body.categories.parent))
            // return

            // From Post Man //
            // body.categories['parent'] = arrObj(body.categories.parent)

            // From Mobile Request //
            body.categories = JSON.parse(body.categories)
            // console.log(categories.parent)
            body.socialMediaLinks = JSON.parse(body.socialMediaLinks)
            body.tags = JSON.parse(body.tags)
            // body.categories['parent']= categories.parent
            // body.categories.child = categories.child

            // if(!Array.isArray(body.categories.parent)){
            //     parent = [JSON.parse(body.categories.parent)]
            // }
            // console.log(arrObj(body.categories.parent))
            // return;
            // body.categories.parent = body.categories.parent.map(s => mongoose.Types.ObjectId(s)),
            Category.getRecord('_id',
                body.categories.parent,
                (err, category) => {
                    if (err) {
                        console.log(err)
                        generateResponse(false, 'aaUnable to process your request.', errors, res, [], []);
                    }


                    else {
                        // console.log(category);
                        // return;
                        // for (i = 0; i <= category.length; i++) {
                        //     if (category[i]['status']['is_deleted'] === false) {
                        //         temp_count++;
                        //     }
                        // }
                        // console.log(temp_count,category.length)
                        // console.log(body.categories.parent,'heree111')


                        // console.log(count(arrObj(body.categories.parent)))
                        // return;
                        if (category.length > 0) {
                            temp_count = 0;
                            // lodash.forEach(body, (val2) => {
                            //     // console.log(val2,"========")

                            // })
                            // lodash.forEach(category, (val) => {
                            //     lodash.forEach(val.subCategory, (val1) => {
                            //     //   console.log(val1)
                            //     })
                            // });
                            // return
                            if (body.categories.child !== undefined) {
                                for (var i = 0; i < body.categories.length; i++) {
                                    for (var j = 0; j < category[i]['subCategory'].length; j++) {
                                        for (var k = 0; k < body.categories.child.length; k++) {
                                            if ((category[i]['subCategory'][j]['_id'] == child[k] && (category[i]['subCategory'][j]['status']['is_deleted'] == false))) {
                                                temp_count++;
                                            }
                                        }
                                    }
                                }
                                // console.log(temp_count, body.categories.child.length)
                                // console.log(body.categories.parent);
                                // console.log(body);


                                // return;

                                // if (temp_count === body.categories.child.length) {
                                    // for (var i = 0; i < body.categories.parent.length; i++) {
                                    //     body.categories.parent[i] = decryptValue(body.categories.parent[i])
                                    // }
                                    Brand.add(body, function (err, brand) {
                                        if (err) {
                                            console.log(err)
                                            var errors = err.errmsg;
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                        }
                                        else {
                                            generateResponse(true, "Added Successfully", brand, res, ['_id'], ['offer', 'terms_and_condition']);
                                        }
                                    });
                                // }
                                // else {
                                //     var errors = {
                                //         error: "SubCategory does not exist"
                                //     };
                                //     generateResponse(false, 'Record not found. Unable to process your request.', errors, res, [], []);
                                // }

                            }
                            else {
                                // for (var i = 0; i < body.categories.parent.length; i++) {
                                //     body.categories.parent[i] = decryptValue(body.categories.parent[i])
                                // }
                                // console.log(body)
                                Brand.add(body, function (err, brand) {
                                    if (err) {
                                        // console.log(err)
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes1', err, res, [], []);
                                    }
                                    else {
                                        generateResponse(true, "Added Successfully", brand, res, ['_id'], ['offer', 'terms_and_condition']);
                                    }
                                });
                            }
                        }
                        else {
                            var errors = {
                                error: "Category does not exist"
                            };
                            generateResponse(false, 'Record not found. Unable to process your request.', errors, res, [], []);
                        }

                    }
                }

            )
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err)
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            var menu_Images_path = [];
            var banner;
            var icon;
            if (body != undefined && req.files != undefined) {
                // body.categories = JSON.parse(body.categories)
                // body.socialMediaLinks = JSON.parse(body.socialMediaLinks)
                // body.tags = JSON.parse(body.tags)
                for (var i = 0; i < req.files.length; i++) {
                    if (req.files[i]['fieldname'] === 'menuImages') {
                        menu_Images_path.push(req.files[i]['path']);
                    }
                    if (req.files[i]['fieldname'] === 'banner') {
                        banner = req.files[i]['path']
                    }
                    if (req.files[i]['fieldname'] === 'icon') {
                        icon = req.files[i]['path']
                    }
                }
                body.menuImages = menu_Images_path;
                body.banner = banner
                body.icon = icon

                var arrObj = function arr_Obj(input) {
                    var count = _.keys(input).length
                    var arrObj = new Array();
                    if ((count == 0) && (input != undefined || input != null)) {
                        var obj = JSON.stringify(input, function (key, value) {
                            arrObj.push(value);
                        })
                        return arrObj;
                    }
                    else {
                        if ((count > 0) && (input != undefined || input != null)) {
                            for (var i = 0; i < input.length; i++) {
                                arrObj[i] = mongoose.Types.ObjectId(input[i]);
                            }
                            return arrObj;
                        }
                    }
                }
                var count = function count(input) {
                    var count = _.keys(input).length
                    return count;
                }
                var temp_count = 0;

                Brand.get({
                    _id: req.params.id
                }, (err, brand) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    }
                    else {
                        if (brand.length > 0) {
                            body.categories = JSON.parse(body.categories)
                            // console.log(categories.parent)
                            body.socialMediaLinks = JSON.parse(body.socialMediaLinks)
                            body.tags = JSON.parse(body.tags)
                            Category.getRecord('_id',
                                body.categories.parent,
                                (err, category) => {
                                    if (err) {
                                        generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    }
                                    else {
                                        for (i = 0; i < category.length; i++) {
                                            if (category[i]['status']['is_deleted'] == false) {
                                                temp_count++;
                                            }
                                        }
                                        // if (category.length === count(body.categories.parent) && (temp_count == category.length)) {
                                        if (category.length > 0) {
                                            temp_count = 0;
                                            if (body.categories.child != undefined) {

                                                for (var i = 0; i < category.length; i++) {
                                                    for (var j = 0; j < category[i]['subCategory'].length; j++) {
                                                        for (var k = 0; k < body.categories.child.length; k++) {
                                                            if ((category[i]['subCategory'][j]['_id'] == body.categories.child[k]) && (category[i]['subCategory'][j]['status']['is_deleted'] == false)) {
                                                                temp_count++;
                                                            }
                                                        }
                                                    }
                                                }
                                                if (temp_count === body.categories.child.length) {
                                                    Brand.update(req.params.id, body, (err, update) => {
                                                        // console.log(update);
                                                        if (err) {
                                                            var errors = err.errmsg;
                                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                        }
                                                        else {
                                                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                                                        }
                                                    })

                                                }
                                                else {
                                                    var errors = {
                                                        error: "SubCategory does not exist"
                                                    };
                                                    generateResponse(false, 'Record not found. Unable to process your request.', errors, res, [], []);
                                                }

                                            }
                                            else {
                                                Brand.update(req.params.id, body, (err, update) => {
                                                    // console.log(update);
                                                    if (err) {
                                                        var errors = err.errmsg;
                                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                                    }
                                                    else {
                                                        generateResponse(true, 'Updated Successfully', update, res, [], []);
                                                    }
                                                })
                                            }




                                        }
                                        else {
                                            var errors = {
                                                error: "Category does not exist"
                                            };
                                            generateResponse(false, 'Record not found. Unable to process your request.', errors, res, [], []);
                                        }

                                    }
                                })
                        }
                        else {
                            generateResponse(false, 'Record not found', [], res, [], []);
                        }
                    }
                });
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            Brand.get({
                _id: req.params.id
            }, (err, brand) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (brand.length > 0) {
                        Brand.remove(req.params.id, (err, update) => {
                            // console.log(update);
                            if (err) {
                                var errors = err.errmsg;
                                generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                            }
                            else {
                                Brand.removeOfferByBrand(req.params.id, (err, deleteOffer) => {
                                    if (err) {
                                        console.log(err);
                                    }
                                    else {
                                        generateResponse(true, 'Removed Successfully', [], res, [], []);
                                    }

                                });
                            }
                        })
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function getOfferAvailCount(req, res) {

    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id)
            let body = {}
            body.brand_id = decryptValue(req.query.brand_id);
            // let body = parseBody(req);
            if (body) {
                // body.brand_id = decryptValue(body.brand_id)
                Brand.getOfferAvailCount(req.params.id, body.brand_id,
                    (err, Offercount) => {
                        if (err) {
                            var errors = {};
                            if (err.name == "ValidationError") {
                                for (var i in err.errors) {
                                    errors[i] = err.errors[i].message;
                                }
                            } else {
                                errors[i] = err.errmsg;
                            }
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], [], []);

                        }
                        else{
                            generateResponse(true, 'Avail Offers Count', Offercount, res, [], []);

                        }
                    })
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

            }
        }
        else {

            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {

    }


}
export function  brandAtPackage(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            // console.log(encryptValue("5c89fab7c1a5c72e2ce0f647"))
            // req.params.id = decryptValue(req.params.id);
            Brand.getPackageScreenBrand({"offer.city_id": mongoose.Types.ObjectId(req.query.city_id)}, function (err, data) {
                if (data.length > 0){
                    generateResponse(true, 'Success', data, res, ["_id"], []);
                } else{
                    generateResponse(false, 'Record not found', [], res, [], []);
                }

            })

        } else{
            generateResponse(false, 'Record not found', [], res, [], []);
        }
    }catch (err) {
        generateResponse(false, 'Unable to process your request.', err, res, [], []);
    }
}
export function getTags(req, res) {
    try {
        Brand.getBrandsTags(req.query.category_id, (err, data) =>{
            if (err){
                generateResponse(false, 'Unable to process your request.', err, res, [], []);
            } else {
                if(data.length > 0){
                    const unique = data.map(e => e['tags']).map((e, i, final) => final.indexOf(e) === i && i).filter(e => data[e]).map(e => data[e]);
                    generateResponse(true, 'Success', unique, res, ["_id"], []);
                } else {
                    generateResponse(false, 'Record not found.', [], res, [], []);
                }

            }
        })
    } catch (err) {
        generateResponse(false, 'Unable to process your request.', err, res, [], []);
    }
}
export function getallbrandoffer(req, res) {
    Brand.getAllOffers((err, result) => {
        let data = [];
    const createCsvWriter = require('csv-writer').createObjectCsvWriter;
    const csvWriter = createCsvWriter({
        path: 'out.csv',
        header: [
            {id: 'name', title: 'Brand Name'},
            {id: 'title', title: 'Offer Title'},
            {id: 'sub_title', title: 'Sub Title'},
            {id: 'offer_description', title: 'Offer Description'},
        ]
    });
    let offer = [];
    let count = 0;
    result.forEach(function (offer_data) {
        let tt =  {
            name: offer_data.name,
            title: offer_data.offer.title,
            sub_title: offer_data.offer.sub_title,
            offer_description: offer_data.offer.offer_description
        }
        offer.push(tt)
        count++;

    })
        // data.push(offer);
    // console.log(offer)

    // const data = [
    //     {
    //         name: 'John',
    //         surname: 'Snow',
    //         age: 26,
    //         gender: 'M'
    //     }, {
    //         name: 'Clair',
    //         surname: 'White',
    //         age: 33,
    //         gender: 'F',
    //     }, {
    //         name: 'Fancy',
    //         surname: 'Brown',
    //         age: 78,
    //         gender: 'F'
    //     }
    // ];

    csvWriter
        .writeRecords(offer)
        .then(()=> console.log('The CSV file was written successfully'));
    })
}
export function getBrandByMonthYear(req, res) {
    try {
        if (req.query.year !== undefined && req.query.month !== undefined && req.query.year !== "" && req.query.month !== ""){
            Brand.getBrandByMonthYear(req.query.year, req.query.month, (err, data) => {
                generateResponse(true, 'success', data, res, [], []);
            })
        } else {
            generateResponse(false, 'Unable to process your request.', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request.', err, res, [], []);
    }
}

export function getBrandForSearch(req, res) {
    try {
        if (req.query.city_id !== undefined && req.query.city_id !== ""){
            Brand.getBrandlimitedData(req.query.city_id,(err, result) => {
                if(result.length > 0){
                    generateResponse(true, 'Success.', result, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found.', [], res, [], []);
                }
            })
        } else {
            generateResponse(false, 'One or more field required.', [], res, [], []);
        }

    } catch (err) {
        generateResponse(false, 'Unable to process your request.', err, res, [], []);
    }
}

export function getFeaturedBrands(req, res) {
    try {
        if (req.query.city_id !== undefined && req.query.city_id !== ""){
            Brand.FeaturedBrands(req.query.city_id,(err, result) => {
                if(result.length > 0){
                    generateResponse(true, 'Success.', result, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found.', [], res, [], []);
                }
            })
        } else {
            generateResponse(false, 'One or more field required.', [], res, [], []);
        }

    } catch (err) {
        generateResponse(false, 'Unable to process your request.', err, res, [], []);
    }
}
