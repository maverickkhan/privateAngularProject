'use strict';
import { parseBody, generateResponse } from '../utilites';
import { searchQuery } from "../utilites/query-module";
import Activationcode from '../models/activationcode';
import ActivationcodeExtend from '../models/activationcodeextend';
import { decryptValue } from '../utilites/encryption-module';
import Customer from '../models/customer';
import Package from "../models/package";
import Category from "../models/category";
import mongoose from "mongoose";

import { get_set } from "../utilites/helper";
function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'package_is': { $regex: queryParams.search, $options: 'i' } },
                { 'is_used': { $regex: queryParams.search, $options: 'i' } },
                { 'activation_code.type': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
function getQueryParamsExtend(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                { 'activation_code': { $regex: queryParams.search, $options: 'i' } },
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
//For Verifying Activation Code
export function verifycode(req, res) {
    try {
        var body = parseBody(req)
        if (body) {
            let AC = body.ActivationCode
            var temp = AC.split("-")
            Activationcode.get({
                $and: [
                    { "activation_code.prefix": temp[0] }
                    , { "activation_code.type": temp[1] }
                    , { "activation_code.serial": temp[2] }
                    , { "activation_code.code": temp[3] }
                    // ,{"is_used":false}
                ]
            }, (err, Activation_code) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                } else {
                    if (Activation_code.length > 0) {
                        if (Activation_code[0]['is_used'] == false && Activation_code[0]['verified'] == false) {
                            Activationcode.update(
                                Activation_code[0]['_id']
                                , { "verified": true }
                                , (err, update) => {
                                    if (err) {
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request.', errors, res, [], []);
                                    } else {
                                        generateResponse(true, 'Actication Code Verified Successfully.', [{ Activation_Code: AC }], res, [], []);

                                    }
                                })
                        }
                        else {
                            generateResponse(false, 'Actication Code Is Used Or Verified', [{ Activation_Code: AC }], res, [], []);
                        }
                    } else {
                        generateResponse(false, 'Actication Code Not Found', [{ Activation_Code: AC }], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        console.log(err)
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function get(req, res) {
    try {
        var queryString = req.query;
        searchQuery(Activationcode, function (err, activationcode) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
            } else {
                // console.log(activationcode);
                if (activationcode.length > 0) {
                    generateResponse(true, 'Success', activationcode, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', activationcode, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParams(queryString), '');
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function create(req, res) {
    // let rand_start = Math.floor(Math.random() * 1000);
    // let rand_end = Math.floor(Math.random() * 100);
    //
    // return;
    try {
        let body = parseBody(req);
        if (body) {
            Package.get({
                _id: body.package_id
            }, (err, pkg) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes1', err, res, [], []);
                } else {
                    if (pkg.length > 0) {
                        Activationcode.getMaxPrefix({},(err, max_prefix)=>{
                            for(let i = 1; i <= parseInt(body.code_count); i++){
                                let start_number = Math.floor(Math.random() * 900 + 100);
                                let end_number = Math.floor(Math.random() * 90 + 10);
                                let prefix = max_prefix.prefix + i;
                                let code_string = start_number + prefix.toString() + end_number;
                                let code = code_string
                                // console.log(code)
                                let data = {
                                    prefix : prefix,
                                    type : body.type,
                                    is_used : false,
                                    verified : true,
                                    validity : body.validity,
                                    code :  code,
                                    package_id : mongoose.Types.ObjectId(body.package_id)
                                }
                                Activationcode.add(data, (err, activationcode) => {
                                    if (err){
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes2', err, res, [], []);
                                    } else {
                                        console.log(activationcode)
                                    }
                                })
                                // console.log(start_number + prefix.toString() + end_number)
                            }

                        })
                        generateResponse(true, 'Added Successfully', [], res, [], []);
                        //Get Max Serial number
                        // Activationcode.getMax({
                        //     "activation_code.type": body.type
                        //     // "package_id" : body.package_id
                        // }, (err, code) => {
                        //     let start_from = 1;
                        //     if (code != null) {
                        //         if (code.activation_code) {
                        //             start_from = parseInt(code.activation_code.serial) + 1;
                        //         }
                        //     }
                        //     var data = [];
                        //     for (var i = 0; body.code_count > i; i++) {
                        //         let new_serial = (start_from + i) + "";
                        //         while (new_serial.length < 6) new_serial = "0" + new_serial;
                        //         data[i] = {
                        //             package_id: body.package_id,
                        //             validity: body.validity,
                        //             activation_code: {
                        //                 prefix: "BB",
                        //                 type: body.type,
                        //                 serial: new_serial,
                        //                 code: Math.floor(Math.random() * 9000) + 1000
                        //             }
                        //         }
                        //     }
                        //     Activationcode.add(data, function (err, code) {
                        //         if (err) {
                        //             var errors = err.errmsg;
                        //             generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        //         } else {
                        //             generateResponse(true, 'Added Successfully', code, res, [], []);
                        //         }
                        //     })
                        // })
                    } else {
                        var errors = {
                            error: " package does not exist"
                        };
                        generateResponse(false, 'Unable to process your request', errors, res, [], []);

                    }
                }
            })

        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes3', [], res, [], []);

        }

    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes4', err, res, [], []);
    }
}

export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Activationcode.get(
                { _id: req.params.id },
                (err, code) => {
                    if (err) {
                        var errors = err.errmsg;
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                    } else {
                        if (code.length > 0) {
                            Activationcode.remove(req.params.id, (err, update) => {
                                // console.log(update);
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    generateResponse(true, 'Removed Successfully', [], res, [], []);
                                }
                            })
                        } else {
                            generateResponse(false, "Record not found", [], res, [], []);
                        }
                    }
                })


        } else {
            generateResponse(false, 'Record not found.', [], res, [], []);

        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }

}

export function updateExpiry(req, res) {
    try {
        if (req.query.activation_code_id != undefined || req.query.activation_code_id != "") {
            // req.query.activation_code_id = decryptValue(req.query.activation_code_id);
            let body = parseBody(req);
            Activationcode.get({
                _id: body.activation_code_id
            }, (err, data) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Error on activation get.', errors, res, [], []);
                }
                else {
                    if (data.length > 0) {
                        if (body != undefined) {
                            Customer.updateExpiry(body, (err, update) => {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Error on customer update expiry.', errors, res, [], []);
                                }
                                else {
                                    ActivationcodeExtend.addExtendDate(body, (err, add) => {
                                        if (err) {
                                            var errors = err.errmsg;
                                            generateResponse(false, 'Error on activation code log add.', errors, res, [], []);
                                        } else {
                                            generateResponse(true, 'Updated Successfully.', add, res, [], []);
                                        }
                                    })
                                }
                            });
                        }
                        else {
                            generateResponse(false, 'Unable to process your request. Please retry in few minutes.', [], res, [], []);
                        }
                    }
                    else {
                        generateResponse(false, 'Record not found.', [], res, [], []);
                    }
                }
            });
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function findActivationCode(req, res) {
    try {
        // console.log(req.query);
        // let data = parseBody(req)
        let code = req.query.code.split("-");
        // console.log(code)
        let data = {
            "activation_code.prefix" : code[0],
            "activation_code.type" : code[1],
            "activation_code.serial" : code[2],
            "activation_code.code" : code[3],
        }
        let result_data = [];
        Activationcode.get(data, (err, result) => {
            // console.log(result[0]._id)
            Customer.get({"subscription.activation_code_id" : result[0]._id}, (err, customer) => {
              if(customer.length > 0){
                    customer[0].subscription.forEach(function (subdata) {
                        if(mongoose.Types.ObjectId(subdata.activation_code_id).equals(mongoose.Types.ObjectId(result[0]._id))){
                            result_data.push({
                                "customer_id" : customer[0]._id,
                                "fullname" : customer[0].first_name + customer[0].last_name,
                                "subscription" : subdata
                            });
                        }
                    })
                  generateResponse(true, 'Updated Successfully.', result_data, res, [], []);
              } else {
                  generateResponse(false, 'Activation code naver userd by any customer.', [], res, [], []);
              }
            })
        })
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getExpiryExtendCode(req, res) {
    try {
        var queryString = req.query;
        searchQuery(ActivationcodeExtend, function (err, activationcodeextend) {
            if (err) {
                var errors = err.errmsg;
                generateResponse(false, 'Unable to process your request.', errors, res, [], []);
            } else {
                if (activationcodeextend.length > 0) {
                    generateResponse(true, 'Success', activationcodeextend, res, ['_id'], []);
                } else {
                    generateResponse(false, 'Record not found', activationcodeextend, res, [], []);
                }
            }
        }, queryString.limit, queryString.page, {}, getQueryParamsExtend(queryString), '');
    } catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}


