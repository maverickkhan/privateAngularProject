/**
 * Created by Annas on 12/24/2018.
 */

'use strict';
import { parseBody, generateResponse } from '../utilites';
import Country from '../models/country';
import { searchQuery } from '../utilites/query-module';
import { decryptValue } from '../utilites/encryption-module';
import {decodeToken} from "../middlewares";
import {validateUser} from "../middlewares";
import Brand from "../models/brand";
import mongoose from "mongoose";
var lodash = require('lodash');

function getQueryParams(queryParams) {
    let findParams = {};
    findParams = {
        'status.is_deleted': false,
    };
    if (queryParams.search) {
        findParams['$or'] =
            [
                // { 'name': { $regex: queryParams.search, $options: 'i' } },
                // { 'cities.city_name': { $regex: queryParams.search, $options: 'i' } },
                { 'cities': { "$elemMatch": { city_name: { $regex: queryParams.search, $options: 'i' } }  } },
                // { 'cities.areas.area_name': { $regex: queryParams.search, $options: 'i' } }
            ];
    }
    if (queryParams.status) {
        findParams['status.is_activated'] = queryParams.status
    }
    if (queryParams.id != undefined && queryParams.id != "") {
        findParams._id = decryptValue(queryParams.id) || "";
    }
    return findParams;
}
export function get(req, res) {
    try {
        let id = decryptValue(req.query.id);
        Country.getAggregateCity(id,req.query.search, (err, city) => {
            generateResponse(true, 'Success', city, res, ['_id'], []);
        })
    }
    catch (err) {
        generateResponse(false, ' Unable to process your request, Please retry in few minutes.', [], res, [], []);
    }
}
export function create(req, res) {
    try {
        // var value = validateUser(req, res, function(req,res){
        //     if(res.status.success == false){
        //         var errors = req.message;
        //         generateResponse(false, 'Error: Access denied', errors, res, [], []);
        //     } else {
                if (req.params.id != undefined || req.params.id != "") {
                    req.params.id = decryptValue(req.params.id);
                    let body = parseBody(req);
                    if (body) {
                        body.cities = {
                            city_name: body.city_name
                        }
                        Country.update(req.params.id,
                            { $push: body }
                            , (err, update) => {
                                if (err) {
                                    var errors = err.errmsg;
                                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                } else {
                                    generateResponse(true, 'Updated Successfully', update, res, [], []);
                                }
                            })
                    }
                    else {
                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                    }


                }
                else {
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

                }
            // }

        // });



    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function update(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            if (body) {
                let body1 = {
                    'cities.$.city_name': body.city_name
                }
                Country.updateCity(req.params.id,
                    body.city_id,
                    body1
                    , (err, update) => {
                        if (err) {
                            var errors = err.errmsg;
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                        } else {
                            generateResponse(true, 'Updated Successfully', update, res, [], []);
                        }
                    })
            }
            else {
                generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
            }


        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

        }

    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
export function remove(req, res) {
    try {
        if (req.params.id != undefined || req.params.id != "") {
            req.params.id = decryptValue(req.params.id);
            let body = parseBody(req);
            Country.get({
                _id: req.params.id
            }, (err, country) => {
                if (err) {
                    var errors = err.errmsg;
                    generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                }
                else {
                    if (country.length > 0) {
                        var temp_count = 0
                        lodash.forEach(country, (val) => {
                            if (val.status.is_deleted == false) {
                                lodash.forEach(val.cities, (val1) => {
                                    if (val1.status.is_deleted == false && val1._id == body.city_id) {
                                        temp_count++;
                                    }
                                });
                            }
                        });
                        if (country.length > 0 && (temp_count == country.length)) {
                            Country.removeCity(req.params.id,
                                body.city_id,
                                (err, update) => {
                                    // console.log(update);
                                    if (err) {
                                        var errors = err.errmsg;
                                        generateResponse(false, 'Unable to process your request, Please retry in few minutes', errors, res, [], []);
                                    }
                                    else {
                                        generateResponse(true, 'Removed Successfully.', [], res, [], ['offer', 'terms_and_condition']);
                                    }
                                })
                        }
                        else {
                            generateResponse(false, 'Record not found.', [], res, [], []);

                        }
                    }
                    else {
                        generateResponse(false, 'Record not found', [], res, [], []);
                    }
                }
            })
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function getCityById(req, res) {
    try {
        if(req.query.city_id){
            Country.getCityById(req.query.city_id, (err, data) => {
                if(data.length > 0){
                    generateResponse(true, 'Successfully', data, res, [], []);
                } else {
                    generateResponse(false, 'Record not found.', [], res, [], []);
                }
            })
        } else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    } catch (err) {
        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);

    }
}
