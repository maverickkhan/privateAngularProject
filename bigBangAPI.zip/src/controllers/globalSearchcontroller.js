/**
 * Created by Annas on 12/24/2018.
 */
'use strict';
import { Request, Response } from 'express';
import { parseBody, generateResponse } from '../utilites';
import { hashSync, genSalt, compare } from "bcrypt";
/* import {UserModel, UserRoleModel, CityModel, CountryModel} from '..//models'; */
import { sign, verify } from "jsonwebtoken";
import config from "../conf";
import { searchQuery } from '../utilites/query-module';
import { decryptValue, encryptValue } from '../utilites/encryption-module';
import Brand from '../models/brand';
import Brandlocation from '../models/brandLocation'
import Trandingbrand from '../models/trendingBrand'
import { getPopularBrands } from './brandcontroller';
export function globalSearch(req, res) {
    try {

        // console.log(req.query)
        let body = req.query;
        // Brand.globalSearch({}, {}, {}, false, {},
        //     (err, globalSearch) => {
        //         if (err) {
        //             console.log(err)
        //             generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        //         }
        //         else {
        //             generateResponse(true, 'Success', globalSearch, res, [], []);
        //         }
        //     })
        // return;
        if (body != null || body != undefined) {
            if (body.sortby === 'relevance' && (body.keyword != undefined || body.keyword != null)) {
                Brand.globalSearch(body.keyword, {}, {}, true, { score: { $meta: "textScore" } },
                    (err, globalSearch) => {
                        if (err) {
                            console.log(err);
                            generateResponse(false, 'aUnable to process your request, Please retry in few minutes1', err, res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                Brand.globalSearch(body.keyword, {}, {}, false, {},
                                    (err, globSearch1) => {
                                        if (err) {
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes2.', [], res, [], []);
                                        }
                                        else {
                                            if (globSearch1.length > 0) {
                                                generateResponse(true, 'Success', globSearch1, res, ['_id'], []);
                                            }
                                            else {
                                                generateResponse(false, 'Record not found.', [], res, [], []);
                                            }
                                        }
                                    })
                            }
                        }
                    });
            }
            else if (body.sortby === 'trending' && (body.keyword != undefined || body.keyword != null)) {
                Brand.globalSearch(body.keyword, {}, {}, true, { 'views': -1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes3', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                Brand.globalSearch(body.keyword, {}, {}, false, { 'views': -1 },
                                    (err, globSearch1) => {
                                        if (err) {
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes.4', [], res, [], []);
                                        }
                                        else {
                                            if (globSearch1.length > 0) {
                                                generateResponse(true, 'Success', globSearch1, res, ['_id'], []);
                                            }
                                            else {
                                                generateResponse(false, 'Record not found.', [], res, [], []);
                                            }
                                        }
                                    })
                            }
                        }
                    });
            }
            else if (body.sortby === 'alphabetic' && (body.keyword != undefined || body.keyword != null)) {
                Brand.globalSearch(body.keyword, {}, {}, false, { 'name': 1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                Brand.globalSearch(body.keyword, {}, {}, false, { 'name': 1 },
                                    (err, globSearch1) => {
                                        if (err) {
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
                                        }
                                        else {
                                            if (globSearch1.length > 0) {
                                                generateResponse(true, 'Success', globSearch1, res, ['_id'], []);
                                            }
                                            else {
                                                generateResponse(false, 'Record not found.', [], res, [], []);
                                            }
                                        }
                                    })
                            }
                        }
                    });

            }
            else if (body.sortby === 'nearby' && ((body.lng != undefined || body.lng != null) && (body.lat != undefined || body.lat != null))) {
                Brandlocation.globalSearchNew(body.keyword, body.lng, body.lat, true, {}, body.city_id,
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes6.', err, res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                let search = []
                                let count = 0;
                                globalSearch.forEach(function (glob) {
                                    search[count] = {
                                        _id : glob._id,
                                        // timestamps: glob.timestamps,
                                        status: glob.status,
                                        brand_id: glob.brand_id,
                                        // area_id: glob.area_id,
                                        // address: glob.address,
                                        geometry: glob.geometry,
                                        // timings: glob.timing,
                                        dist: glob.dist,
                                        brand : []
                                    }
                                    let brandcount = 0;
                                    glob.brand.forEach(function (brand) {
                                        search[count].brand[brandcount] = {
                                            _id: brand._id,
                                            // categories: brand.categories,
                                            // timestamps: brand.timestamps,
                                            status: brand.status,
                                            // menuImages: brand.menuImages,
                                            tags: brand.tags,
                                            views: brand.views,
                                            name: brand.name,
                                            // phone_number: brand.phone_number,
                                            description: brand.description,
                                            webUrl: brand.webUrl,
                                            icon: brand.icon,
                                            banner: brand.banner,
                                            // is_show_at_package_screen: brand.is_show_at_package_screen,
                                            // socialMediaLinks: brand.socialMediaLinks,
                                            // specialties: brand.specialties,
                                            // facilities: brand.facilities,
                                            offer: []
                                        }
                                    })
                                    count++
                                })
                                // console.log(search)
                                generateResponse(true, 'Success', globalSearch, res, ['_id','brand_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else if (body.sortby === 'trending' && (body.keyword == undefined || body.keyword == null)) {
                Brand.globalSearch(body.keyword, {}, {}, true, { 'views': -1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else if (body.sortby === 'alphabetic' && (body.keyword == undefined || body.keyword == null)) {
                Brand.globalSearch(body.keyword, {}, {}, true, { 'name': 1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else if ((body.sortby == null || body.sortby == undefined) && (body.keyword == undefined || body.keyword == null)) {
                Brand.globalSearch(body.keyword, {}, {}, true, { 'views': -1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else {
                generateResponse(false, 'Record not found.', [], res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err)

        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}

export function advanceSearch(req, res) {
    try {
        let body;
        if(req.query){
             body = req.query;
        } else{
            body = parseBody(req);
        }


        if (body != null || body != undefined) {
            if (body.sortby === 'relevance') {
                Brand.advanceSearch({}, {}, true, {},body.tags,body.city_id,
                    (err, globalSearch) => {
                        if (err) {
                            console.log(err);
                            generateResponse(false, 'aUnable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(true, 'Success', [], res, ['_id'], []);

                            }
                        }
                    });
            }
            else if (body.sortby === 'trending') {
                Trandingbrand.advanceSearch(body.tags,
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                globalSearch.forEach(temp => {
                                    temp.result._id = encryptValue(temp.result._id)
                                });

                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                Brand.advanceSearch({}, {}, false, { 'views': -1 },
                                    (err, globSearch1) => {
                                        if (err) {
                                            generateResponse(false, 'Unable to process your request, Please retry in few minutes.', [], res, [], []);
                                        }
                                        else {
                                            if (globSearch1.length > 0) {
                                                generateResponse(true, 'Success', globSearch1, res, ['_id'], []);
                                            }
                                            else {
                                                generateResponse(false, 'Record not found.', [], res, [], []);
                                            }
                                        }
                                    })
                            }
                        }
                    });
            }
            else if (body.sortby === 'alphabetic') {
                Brand.advanceSearch({}, {}, false, { 'name': 1 }, body.tags, body.city_id,
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {

                             generateResponse(false, 'Record not found.', [], res, [], []);

                            }
                        }
                    });

            }
            else if (body.sortby === 'nearby' && ((body.lng != undefined || body.lng != null) && (body.lat != undefined || body.lat != null))) {
                if(!body.tags){
                    body.tags = []
                }
                Brandlocation.advanceSearch(body.lng, body.lat, body.tags,body.city_id,
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes.', err, res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['brand_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else if (body.sortby === 'trending') {
                Brand.advanceSearch({}, {}, true, { 'views': -1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else if (body.sortby === 'alphabetic') {
                Brand.advanceSearch({}, {}, true, { 'name': 1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else if ((body.sortby == null || body.sortby == undefined)) {
                Brand.advanceSearch({}, {}, true, { 'views': -1 },
                    (err, globalSearch) => {
                        if (err) {
                            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
                        }
                        else {
                            if (globalSearch.length > 0) {
                                generateResponse(true, 'Success', globalSearch, res, ['_id'], []);
                            }
                            else {
                                generateResponse(false, 'Record not found.', [], res, [], []);
                            }
                        }
                    });
            }
            else {
                generateResponse(false, 'Record not found.', [], res, [], []);
            }
        }
        else {
            generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
        }
    }
    catch (err) {
        console.log(err)

        generateResponse(false, 'Unable to process your request, Please retry in few minutes', [], res, [], []);
    }
}
