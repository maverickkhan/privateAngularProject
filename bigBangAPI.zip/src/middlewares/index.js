'use strict';
import mkdirp from 'mkdirp';
import { verify } from "jsonwebtoken";
import config from "../conf";
import multer from 'multer';
import mongoose from 'mongoose';
import Log from '../models/log';
import {generateResponse} from "../utilites";
// const roles = require("user-groups-roles");
const Role = require("../models/role");
const model = require("../models/authv");
export function log(req, res, next) {
    console.log(req.originalUrl);
    /* console.log(req.body); */
    /*  console.log(res); */
    /* let logObj = {
        url : req['headers'].origin+req.originalUrl,
        method : req['method'],
        request_body : req['body'],
        request_query : req['query']
    }
    console.log(logObj);
    Log.addsystemLog(logObj, (res) => {
        console.log(res);
    }); */
    // let whitelist = Object.keys(config.whitelist).map(k => config.whitelist[k]);
    // let origin = req.ip;
    // console.log(origin);
    // let originIsWhitelisted = whitelist.indexOf(origin) !== -1 || typeof origin === "undefined";
    // if(originIsWhitelisted){
    next();
    // } else {
    //     res.status(400).json({message: 'Unauthorized Access'});
    // }
}
export function multerMiddleware(req, res, next) {
    const storage = multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, './uploads/');
        },
        filename: function (req, file, cb) {
            cb(null, Date.now() + '-' + file.originalname);
        }
    });
    const fileFilter = (req, file, cb) => {
        // reject a file
        if (file.mimetype === 'text/csv' || file.mimetype === 'application/json' || file.mimetype === 'image/jpeg' || file.mimetype === 'image/jpg' || file.mimetype === "image/png" || file.mimetype === "image/PNG") {
            cb(null, true);
        } else {
            cb(null, false);
        }
    };
    //   let upload = multer({
    //     storage: storage,
    //     // limits: {
    //     //   fileSize: 1024 * 1024 * 5
    //     // },
    //     fileFilter: fileFilter
    //   });
    let upload = multer({
        storage: storage,
        fileFilter: fileFilter
    }).any();
    upload(req, res, (err) => {
        if (err) {
            console.log(err);
            res.status(400).json({ success: false, error: ["File Cannot be Uploaded"] });
        }
        next();
    });
    // const file_path = config.app['file_path'];
    // let storage = multer.diskStorage({
    //     destination: (request, file, cb) => {
    //         let emp_number = request.body['employee_number'];
    //         console.log(emp_number);
    //         mkdirp(file_path + 'users/' + emp_number, function (err) {
    //             cb(null, file_path + 'users/' + emp_number);
    //         });
    //     },
    //     filename: (request, file, cb) => {
    //         let file_extension = file.originalname.split('.')[file.originalname.split('.').length - 1];
    //         let file_name = `${request.body['employee_number']}${Date.now()}.${file_extension}`;
    //         cb(null, file_name);
    //     }
    // });
    // let upload = multer({storage: storage}).single('file_attachment');
    // upload(req, res, (err) => {
    //     if (err) {
    //         console.log(err);
    //         res.status(400).json({success: false, error: ["File Cannot be Uploaded"]});
    //     }
    //     next();
    // });
}
export function loggedIn(req, res, next) {
    decodeToken(req).then(data => {

        req.user = data.payload;
        next();
    }).catch(ex => {
        // let error = {type: ERROR_TYPE.FORCE_UPDATE, message: 'Update your application.'};
        // let error = {type: ERROR_TYPE.DEACTIVATE_USER, message: 'User is deactivated.'};
        // let error = {type: ERROR_TYPE.CUSTOM, message: 'Oops something went wrong..'};
        res.status(400).json({ success: false, error: ["Unauthenticated request"] });
        /* console.error(ex); */
    });
}
// decodeToken(req).then(data => {
//     /*  console.log(data); */
//     req.payload = data.payload;
//     next();
// }).catch(ex => {
//     // let error = {type: ERROR_TYPE.FORCE_UPDATE, message: 'Update your application.'};
//     // let error = {type: ERROR_TYPE.DEACTIVATE_USER, message: 'User is deactivated.'};
//     // let error = {type: ERROR_TYPE.CUSTOM, message: 'Oops something went wrong..'};
//     res.status(400).json({ success: false, error: ["Unauthenticated request"] });
//     /* console.error(ex); */
// });
// }
export function decodeToken(req) {
    return new Promise((resolve, reject) => {
        let { token } = req.headers;
        verify(token, `${config.app['jwtsecret']}`, (err, decoded) => {
            if (err === null) {
                resolve(decoded);
            } else {
                reject(err);
            }
        });
    });
}
export function accessControl(req, res, next) {
    decodeToken(req).then(data => {
        req.payload = data.payload;
        // let path = req.route.path.substring(1);
        let method = req.method;
        var urlData = req.originalUrl;
        var url = urlData.split("/");
        var path = url[2] ;
        // console.log(path ," ",method)
        // return;
        // console.log(req.payload.role_id); return;

        Role.getSpecificRoleByName(mongoose.Types.ObjectId(req.payload.role_id),path ,(err, role) => {
            // /* console.log(role[0].permissions); */
            // console.log(role[0]['permissions']); return;
            if(role){
                let accessGranted = role[0].permissions;
// console.log(accessGranted); return;
                if (method === 'GET') {

                    if (accessGranted['r']) {
                        next();
                    }
                    else {
                        res.status(400).json({ success: false, error: ["Read Access Undefined"] });
                    }

                }
                else if (method === 'POST') {
                    if (accessGranted['c']) {
                        next();
                    }
                    else {
                        res.status(400).json({ success: false, error: ["Create Access Undefined"] });
                    }
                }
                else if (method === 'PUT') {
                    if (accessGranted['u']) {
                        next();
                    }
                    else {
                        res.status(400).json({ success: false, error: ["Update Access Undefined"] });
                    }
                }
                else if (method === 'DELETE') {
                    if (accessGranted['d']) {
                        next();
                    }
                    else {
                        res.status(400).json({ success: false, error: ["Delete Access Undefined"] });
                    }
                }
                else{
                    res.status(400).json({ success: false, error: ["Access Undefined"] });
                }
            } else {
                res.status(400).json({ success: false, error: ["Access Undefined"] });
            }



        });
    }).catch(ex => {
        res.status(400).json({ success: false, error: ["Access Undefined"] });
    });

}
// export function decodeToken(req) {
//     return new Promise((resolve, reject) => {
//         let {token} = req.headers;
//         verify(token, `${config.app['jwtsecret']}`, (err, decoded) => {
//             if (err === null) {
//                 resolve(decoded);
//             } else {
//                 reject(err);
//             }
//         });
//     });
// }
// export function loggedIn(req, res, next) {
//     decodeToken(req).then(data => {
//         req.user = data;
//         new Member({id: req.user.id}).find().then(m => {
//             if(!m.active){
//                 let flag = isRouteAccessible(req.originalUrl, ERROR_TYPE.DEACTIVATE_USER);
//                 if(flag){
//                     next();
//                 } else {
//                     let error = {type: ERROR_TYPE.DEACTIVATE_USER, message: 'You have been deactivated from the service.'};
//                     res.status(403).json({success: false, error: error});
//                 }
//             } else {
//                 next();
//             }
//         }).catch(ex => {
//             res.status(400).json({success: false, error: ["Unauthenticated request"]});
//             console.error(ex);
//         });
//     }).catch(ex => {
//         // let error = {type: ERROR_TYPE.FORCE_UPDATE, message: 'Update your application.'};
//         // let error = {type: ERROR_TYPE.DEACTIVATE_USER, message: 'User is deactivated.'};
//         // let error = {type: ERROR_TYPE.CUSTOM, message: 'Oops something went wrong..'};
//         res.status(400).json({success: false, error: ["Unauthenticated request"]});
//         console.error(ex);
//     });
// }
// export function admin(req, res, next) {
//     decodeToken(req).then(data => {
//         if (data.isAdmin == true) {
//             next();
//         } else {
//             res.status(400).json({success: false, error: ["Unauthorized request"]});
//         }
//     }).catch(ex => {
//         res.status(400).json({success: false, error: ["Unauthenticated request"]});
//         console.error(ex);
//     });
// }
// function isRouteAccessible(path, errorType){
//     let paths = {
//         'deactivate_user' : {
//             allowed_path: [
//                 '/api/settings',
//                 '/api/settings/calc_route',
//                 '/api/settings/update',
//                 '/api/reports'
//             ]
//         }
//     };
//     return paths[errorType].allowed_path.includes(path);
// }


// export function validateUser(req, res,next) {
//     try {
//         var tok = decodeToken(req);

//         tok.then(function (result) {
//             var user = result.payload.email;
//             var role = model.getroles(user);
//             var urlData = req.originalUrl;
//             var path = urlData.split("/");
//             var url = "/" + path[2] + "/" + path[3];
//             //URL and form method roles
//             var value = roles.getRoleRoutePrivilegeValue(role, url, req.method);
//             if(!value){
//                 // generateResponse(false, 'Access denied', [], res, [], []);
//                 res.status(400).json({ success: false, error: ["Access denied"] });
//             }else {
//                 next();
//             }

//         });
//     } catch (e) {
//         res.status(400).json({ success: false, error: ["Unable to process your request, Please retry in few minutes"] });
//     }

//     // console.log(value);
// }
