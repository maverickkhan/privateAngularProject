'use strict';
import { Router } from "express";
import { log, loggedIn} from "../middlewares/index";
import {get, create, remove} from '../controllers/customerSubscriptioncontroller';
export default class CustomerSubscriptionAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.get('/get', log, loggedIn, get);
        router.put('/create/:id', log, loggedIn, create);
        // router.delete('/remove/:id', log, loggedIn, remove);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/customerSubscription';
    }
}