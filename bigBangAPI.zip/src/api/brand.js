'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, update, get, remove, getPopularBrands, getLatestBrands,getBrandbyCustomer, getOfferbyCustomer,getOfferAvailCount,brandAtPackage, getTags, getallbrandoffer, getBrandByMonthYear, getBrandForSearch, getFeaturedBrands} from '../controllers/brandcontroller';

export default class BrandAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        // var cpUpload = upload.fields([{ name: 'image', maxCount: 1 },{ name: 'speciality_icon', maxCount: 1 },{ name: 'facility_icon', maxCount: 1 } ])
        router.post('/create', multerMiddleware, log, loggedIn, create);  //cpUpload,
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.get('/popular', log, loggedIn, getPopularBrands);
        router.get('/latest', log, loggedIn, getLatestBrands);
        // router.get('/nearby', log, loggedIn, getNearBy);
        router.get('/getBrandbyCustomer', log, loggedIn, getBrandbyCustomer);
        router.get('/getOfferbyCustomer', log, loggedIn, getOfferbyCustomer);
        router.get('/getOfferAvailCount/:id' ,log, loggedIn, getOfferAvailCount)
        router.get('/brandAtPackage', log, loggedIn, brandAtPackage);
        router.get('/getTags', log, loggedIn, getTags);
        router.get('/getallbrandoffer', log, getallbrandoffer);
        router.get('/getBrandByMonthYear', log,loggedIn, getBrandByMonthYear);
        router.get('/getBrandForSearch', log, getBrandForSearch);
        router.get('/getFeaturedBrands', log, getFeaturedBrands);


    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/brand';
    }
}
