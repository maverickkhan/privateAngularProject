'use strict';
import { Router } from "express";
import { log, loggedIn } from "../middlewares/index";
import { create, get, remove, verifycode, updateExpiry, findActivationCode, getExpiryExtendCode} from '../controllers/activationCodecontroller';
export default class ActivationCodeAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', log, loggedIn, create);
        // router.put('/update/:id', log, loggedIn, update);
        router.get('/get', log, loggedIn, get);
        router.post('/verifycode', log, loggedIn, verifycode);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.post('/updateExpiry', log, loggedIn, updateExpiry);
        router.get('/findActivationCode', log, loggedIn, findActivationCode);
        router.get('/getExpiryExtendCode', log, loggedIn, getExpiryExtendCode);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/activationcode';
    }
}
