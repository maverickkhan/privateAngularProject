'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, update, get, remove, getOne } from '../controllers/subcategorycontroller';
export default class SubCategoryAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create/:id', multerMiddleware, log, loggedIn, create);
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/get', log, loggedIn, get);
        router.get('/getone', log, loggedIn, getOne);
        router.delete('/remove/:id', log, loggedIn, remove);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/subcategory';
    }
}
