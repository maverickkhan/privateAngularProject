'use strict';
import { Router } from "express";
import { log, loggedIn } from "../middlewares/index";
import { login, register, get, update, remove, gett } from '../controllers/authcontroller';
export default class AuthAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/login', log, login);
        router.post('/register', log, register);
        router.get('/get', log, loggedIn, get);
        router.put('/update/:id', log, loggedIn, update);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.get('/gett', log, loggedIn, gett);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/auth';
    }
}
