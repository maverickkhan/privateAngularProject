'use strict';
import { Router } from "express";
import {accessControl, validateUser, log, loggedIn} from "../middlewares/index";
import { create, update, get, remove } from '../controllers/countrycontroller';
export default class CountryAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', log, loggedIn, create);
        router.put('/update/:id', log, loggedIn,update);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/country';
    }
}
