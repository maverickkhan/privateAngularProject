'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, get, getType } from '../controllers/feedbackcontroller';
export default class FeedbackAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', multerMiddleware, log, loggedIn, create);
        router.get('/get', log, loggedIn, get);
        router.get('/getType', log, loggedIn, getType);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/feedback';
    }
}
