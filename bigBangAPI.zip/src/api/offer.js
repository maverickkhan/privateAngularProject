'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create,update,get, getHyperOffer, remove,getPopularOffers,getLatestOffers,getRelatedOffers, getOfferByBrand, getIsDeliverableOffer, getOfferPackages } from '../controllers/offercontroller';

export default class OfferAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        // router.post('/create',upload.any(),log,loggedIn,create);
        router.put('/create/:id', multerMiddleware, log, loggedIn, create);
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/get', log, get);
        router.get('/popular', log, loggedIn, getPopularOffers);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.get('/relatedOffers', log, loggedIn, getRelatedOffers);
        router.get('/latest', log, loggedIn, getLatestOffers);
        router.get('/getOfferByBrand', log, loggedIn, getOfferByBrand);
        router.get('/getIsDeliverableOffer', log, loggedIn, getIsDeliverableOffer);
        router.get('/getOfferPackages', log, loggedIn, getOfferPackages);
        router.get('/getHyperOffer', log, loggedIn, getHyperOffer);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/offer';
    }
}
