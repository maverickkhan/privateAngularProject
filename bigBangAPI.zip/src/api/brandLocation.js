'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, update, get, remove, getNearBy } from '../controllers/brandLocationcontroller';

export default class BrandLocationAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', multerMiddleware, log, loggedIn, create);
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/nearby', log, loggedIn, getNearBy);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/brand-location';
    }
}
