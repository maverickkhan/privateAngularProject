'use strict';
import { Router } from "express";
import { log, loggedIn } from "../middlewares/index";
import { create, update, get, remove, getPackageByCity } from '../controllers/packagecontroller';
export default class PackageAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', log, loggedIn, create);
        router.put('/update/:id', log, loggedIn, update);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.get('/getPackageByCity', log, loggedIn, getPackageByCity);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/package';
    }
}
