'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, get, update, remove, addBrandsToCollection } from '../controllers/collectionscontroller';
export default class CollectionsAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', multerMiddleware, log, loggedIn, create);
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.put('/addBrandsToCollection/:id', multerMiddleware, log, loggedIn, addBrandsToCollection);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/collections';
    }
}
