'use strict';
import { Router } from "express";
import { log, loggedIn} from "../middlewares/index";
import { addRole, updateRole,addUserGroupToRoute,getAllUserGroup } from '../controllers/rolecontroller';
export default class RoleAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/addRole', log, loggedIn,addRole);
        router.post('/updateRole', log, loggedIn, updateRole);
        router.post('/addUserGroupToRoute', log, loggedIn, addUserGroupToRoute);
        router.get('/getAllUserGroup', log, loggedIn, getAllUserGroup);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/role';
    }
}