'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, update, get, remove, removeSection, createSection } from '../controllers/mobilehomescreen';
export default class MobilehomescreenAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', multerMiddleware, log, loggedIn, create);
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/get', log, loggedIn, get);
        router.put('/remove/:id', log, loggedIn, remove);
        router.put('/removeSection/:id', log, loggedIn, removeSection);
        router.put('/createSection/:id', log, loggedIn, createSection);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/mobilehomescreen';
    }
}
