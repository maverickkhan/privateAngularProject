'use strict';
import { Router } from "express";
import { log, loggedIn } from "../middlewares/index";
import { create, update, get, remove } from '../controllers/areacontroller';
export default class AreaAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.put('/create/:id', log, loggedIn, create);
        router.put('/update/:id', log, loggedIn, update);
        router.get('/get', log, loggedIn, get);
        router.delete('/remove/:id', log, loggedIn, remove);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/area';
    }
}