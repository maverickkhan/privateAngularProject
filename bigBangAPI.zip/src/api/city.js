'use strict';
import { Router } from "express";
import { log, loggedIn,accessControl } from "../middlewares/index";
import { create, update, get, remove, getCityById } from '../controllers/citycontroller';
export default class CityAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.put('/create/:id', log, loggedIn , create);
        router.put('/update/:id', log, loggedIn , update);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.get('/getCityById', log, getCityById);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/city';
    }
}
