'use strict';
import { Router } from "express";
import { log, loggedIn } from "../middlewares/index";
import { globalSearch, advanceSearch } from '../controllers/globalSearchcontroller';

export default class GlobalSearchAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.get('/search',log, loggedIn, globalSearch);
        router.get('/advanceSearch',log, loggedIn, advanceSearch);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/globalSearch';
    }
}
