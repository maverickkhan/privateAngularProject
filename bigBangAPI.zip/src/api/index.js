// 'use strict';
// import {Router, NextFunction, Request, Response} from 'express';
// import { generateResponse } from '../utilites/';
// const router = Router();
// router.get('/', (req, res) => {
//     generateResponse(true, "APIs Working fine", null, res);
// });
// module.exports = router;
'use strict';
import { Router, NextFunction, Request, Response } from "express";
import AuthAPI from "./auth";
import PackageAPI from "./package";
import CustomerAPI from "./customer";
import CustomerSubscriptionAPI from "./customerSubscription";
import BannerAPI from "./banner";
import customerPackageRequestAPI from "./customerPackageRequest";
import BrandAPI from "./brand";
import CountryAPI from "./country";
import OfferAPI from "./offer";
import CategoryAPI from "./category";
import SubCategoryAPI from "./subcategory";
import GlobalSearchAPI from "./globalSearch";
import BrandLocationAPI from "./brandLocation";
import BrandSpecialtiesAPI from "./brandspecialties";
import BrandFacilitiesAPI from "./brandfacilities";
import CityAPI from "./city";
import AreaAPI from "./area";
import ActivationCodeAPI from "./activationcode";
import PromoCodeAPI from "./promocode";
import RoleAPI from "./role";
import NotificationAPI from "./notification";
import CrontaskAPI from "./crontask";
import BannerCategoryAPI from "./bannerCategory";
import Mobilehomescreen from "./mobilehomescreen"
import CollectionsAPI from "./collections";
import TrendingBrandAPI from "./trendingBrand";
import FeedbackAPI from "./feedback";
import OrderAPI from "./order";
import PopupAPI from './popup';
import MigrateAPI from "./migrate";
import StatisticsAPI from "./statistics";



export default class Api {
    constructor(app) {
        this.app = app;
        this.router = Router();
        this.routeGroups = [];
    }
    loadRouteGroups() {
        this.routeGroups.push(new AuthAPI());
        this.routeGroups.push(new PackageAPI());
        this.routeGroups.push(new CustomerAPI());
        this.routeGroups.push(new CustomerSubscriptionAPI());
        this.routeGroups.push(new customerPackageRequestAPI());
        this.routeGroups.push(new BannerAPI());
        this.routeGroups.push(new BrandAPI());
        this.routeGroups.push(new BrandLocationAPI());
        this.routeGroups.push(new CountryAPI());
        this.routeGroups.push(new OfferAPI());
        this.routeGroups.push(new CategoryAPI());
        this.routeGroups.push(new SubCategoryAPI());
        this.routeGroups.push(new GlobalSearchAPI());
        this.routeGroups.push(new CityAPI());
        this.routeGroups.push(new AreaAPI());
        this.routeGroups.push(new BrandSpecialtiesAPI());
        this.routeGroups.push(new BrandFacilitiesAPI());
        this.routeGroups.push(new ActivationCodeAPI());
        this.routeGroups.push(new PromoCodeAPI());
        this.routeGroups.push(new RoleAPI());
        this.routeGroups.push(new NotificationAPI());
        this.routeGroups.push(new CrontaskAPI());
        this.routeGroups.push(new BannerCategoryAPI());
        this.routeGroups.push(new Mobilehomescreen());
        this.routeGroups.push(new CollectionsAPI());
        this.routeGroups.push(new TrendingBrandAPI());
        this.routeGroups.push(new FeedbackAPI());
        this.routeGroups.push(new OrderAPI());
        this.routeGroups.push(new PopupAPI());
        this.routeGroups.push(new MigrateAPI())
        this.routeGroups.push(new StatisticsAPI())


    }
    setContentType(req, resp, next) {
        resp.set('Content-Type', 'text/json');
        next();
    }
    registerGroup() {
        this.loadRouteGroups();
        this.routeGroups.forEach(rg => {
            let setContentType = rg.setContentType ? rg.setContentType : this.setContentType;
            this.app.use('/api' + rg.getRouteGroup(), setContentType, rg.getRouter())
        });
    }
}
