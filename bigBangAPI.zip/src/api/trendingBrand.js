'use strict';
import { Router } from "express";
import { log, loggedIn } from "../middlewares/index";
import { create, update, get, remove,get_E_D} from '../controllers/trendingBrandcontroller';

export default class TrendingBrandAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        // var cpUpload = upload.fields([{ name: 'image', maxCount: 1 },{ name: 'speciality_icon', maxCount: 1 },{ name: 'facility_icon', maxCount: 1 } ])
        router.post('/create', log, loggedIn, create);  //cpUpload,
        router.put('/update/:id', log, loggedIn, update);
        router.get('/get', log, get);
        router.get('/get_E_D', log, get_E_D);
        router.delete('/remove/:id', log, loggedIn, remove);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/trendingBrand';
    }
}
