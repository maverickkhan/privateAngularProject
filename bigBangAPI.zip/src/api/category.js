'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create, update, get, remove, getBrandByCategory, getBrandBySubCategory, getBrandCategoryPagination } from '../controllers/categorycontroller';
export default class CategoryAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.post('/create', multerMiddleware, log, loggedIn, create);
        router.put('/update/:id', multerMiddleware, log, loggedIn, update);
        router.get('/get', log, get);
        router.delete('/remove/:id', log, loggedIn, remove);
        router.get('/getBrandByCategory/:id', log, getBrandByCategory);
        router.get('/getBrandBySubCategory/:id', log, loggedIn, getBrandBySubCategory);
        router.get('/getBrandCategoryPagination/:id', log, getBrandCategoryPagination);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/category';
    }
}
