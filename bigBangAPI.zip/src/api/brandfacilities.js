'use strict';
import { Router } from "express";
import { log, loggedIn, multerMiddleware } from "../middlewares/index";
import { create,get, remove } from '../controllers/brandFacilitiescontroller';

export default class OfferAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        router.put('/create/:id', multerMiddleware, log, loggedIn, create);
        // router.get('/get', log, loggedIn, get);
        router.delete('/remove/:id', log, loggedIn, remove);

    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/brandfacilities';
    }
}