'use strict';
import { Router } from "express";
import { log, loggedIn,accessControl } from "../middlewares/index";
import { getStatistics, getOffersStatistics, getOffersStatisticsall, getAvailOfferBrand } from '../controllers/statisticscontroller';
export default class StatisticsAPI {
    constructor() {
        this.router = Router();
        this.registerRoutes();
    }
    registerRoutes() {
        let router = this.router;
        // router.put('/create/:id', log, loggedIn , create);
        // router.put('/update/:id', log, loggedIn , update);
        router.get('/get', log, loggedIn, getStatistics);
        router.get('/getOffersStatistics', log, loggedIn, getOffersStatistics);
        router.get('/getOffersStatisticsall', log, loggedIn, getOffersStatisticsall);
        router.get('/getAvailOfferBrand', log, loggedIn, getAvailOfferBrand);
        // router.delete('/remove/:id', log, loggedIn, remove);
        // router.get('/getCityById', log, getCityById);
    }
    getRouter() {
        return this.router;
    }
    getRouteGroup() {
        return '/statistics';
    }
}
