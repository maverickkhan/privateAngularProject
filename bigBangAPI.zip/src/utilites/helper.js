export function RandomValue(num) {
    var string = "0123456789";
    var str = '';
    var i = 0;
    while (i < num) {
        str += string.charAt(Math.floor(Math.random() * string.length));
        i++;
    }
    return str;
}

export class get_set {

    //   EnterRoom(id, name, room) {
    //     const user = { id, name, room };
    //     this.globalArray.push(user);
    //     return user;
    //   }

    
    constructor() {

        this.verified = [];
        this.used = [];
        this.notfound = [];
    }

     get_verified() {
        return this.verified

    }
    set_verified(val) {
        this.verified.push(val)
        // return 'verified: ' + this.verified+'used: ' + this.used+'notfound: ' + this.notfound


    }

    // get_used() {
    //     return this.used

    // }
    // set_used(val) {
    //     this.used.push(val)

    //     // return 'verified: ' + this.verified+'used: ' + this.used+'notfound: ' + this.notfound


    // }
    // get_notfound() {
    //     return this.notfound

    // }
    // set_notfound(val) {
    //     this.notfound.push(val)

    //     // return 'verified: ' + this.verified+'used: ' + this.used+'notfound: ' + this.notfound


    // }
}
