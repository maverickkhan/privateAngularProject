import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import {addBrandsToCollection} from "../controllers/collectionscontroller";
import Brand from '../models/brand'
let ObjectId = mongoose.Schema.Types.ObjectId;

let brandSchema = mongoose.Schema({
    brand_id : {
        type: ObjectId,
        required: true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
});

let collectionsSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    banner: {
        type: String,
        required: true
    },
    brand : [brandSchema],
    timestamps: TIME_STAMPES,
    status: FLAGS
    // _id : false if i want to keep id disable
});
let Collections = module.exports = mongoose.model('collections', collectionsSchema);

module.exports.add = function (collections, callback) {
    Collections.create(collections, callback);
};

module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Collections.find(filter).lean().exec(callback);
};

module.exports.update = function (id, collections, callback) {
    collections.$set = {
        "timestamps.updated_at": new Date(),
    }
    Collections.updateOne({ _id: id }, collections, callback);
};

module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Collections.updateOne({ _id: id }, remove, callback);
};

module.exports.addBrand = function (id, collections, callback) {
    collections.$set = {
        "timestamps.updated_at": new Date(),
    }
    Collections.updateOne({ _id: id }, {$push : collections}, callback);
};

