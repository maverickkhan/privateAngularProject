import mongoose from 'mongoose';
require('mongoose-type-url');
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
const Schema = mongoose.Schema;

let ObjectId = mongoose.Schema.Types.ObjectId;
// create geolocation Schema
let GeoSchema = mongoose.Schema({
    type: {
        type: String,
        default: 'Point',
        required: true
    },
    coordinates: {
        type: [Number],
        index: '2dsphere',
        required: true
    },
    _id: false //if i want to keep id disable

});
let dayAndTimingSchema = mongoose.Schema({
    open: {
        type: String,
        required: true
    },
    close: {
        type: String,
        required: true
    },
    _id: false
})
let timingSchema = mongoose.Schema({
    mon: dayAndTimingSchema,
    tue: dayAndTimingSchema,
    wed: dayAndTimingSchema,
    thu: dayAndTimingSchema,
    fri: dayAndTimingSchema,
    sat: dayAndTimingSchema,
    sun: dayAndTimingSchema,
    _id: false

})
let brandLocationSchema = mongoose.Schema({
    brand_id: {
        type: ObjectId,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    code: {
        type: String,
        required: true
    },
    country_id: {
        type: ObjectId,
        required: true
    },
    city_id: {
        type: ObjectId,
        required: true
    },
    area_id: {
        type: ObjectId,
        required: false
    },
    timings: timingSchema,
    geometry: GeoSchema,


    timestamps: TIME_STAMPES,
    status: FLAGS
})

let BrandLocation = module.exports = mongoose.model('brandLocations', brandLocationSchema);
module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    BrandLocation.find(filter).lean().exec(callback);
    // BrandLocation.find(findFilter, callback);
};

module.exports.globalSearch1 = function (text, lng, lat, flag, sort = {},city_id, callback) {
    // console.log('i am here')
    if (flag == true) {
        if ((text != undefined || text != null) && (sort != null || sort != undefined)) {
            BrandLocation.find({ $text: { $search: text } }, { score: { $meta: "textScore" } }, callback).sort(sort);
        }

        else if ((text == undefined || text == null) && (lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort != null || sort != undefined)) {
            BrandLocation.aggregate([{
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(lat), parseFloat(lng)] },
                    spherical: true,
                    maxDistance: 10000,
                    minDistance: 0,
                    distanceField: "dist"
                }

            },
                 // { $match : { "brand.offer.city_id" : mongoose.Types.ObjectId("5d14a97468a3b1235099c75e") } }
                // ,{ $unwind: "$location" }
                // ,{ $limit: parseInt(limit) }
            ], callback);
        }
        else if ((text == undefined || text == null) && (sort != null || sort != undefined)) {

            BrandLocation.find({}, callback).sort(sort)
        }
    }
    else {
        if (flag == false) {
            if (text != undefined || text != null && (sort != null || sort != undefined)) {
                BrandLocation.find({
                    "$or": [
                        { name: { $regex: text, $options: 'i' } }
                        , { description: { $regex: text, $options: 'i' } }
                        , { tags: { $regex: text, $options: 'i' } }
                        , { "offer.title": { $regex: text, $options: 'i' } }
                        , { "offer.offer_description": { $regex: text, $options: 'i' } }
                        , { "offer.tags": { $regex: text, $options: 'i' } }

                    ]
                }, callback).sort(sort);
            }
        }

    }

};

module.exports.getRelatedOffers = function (find, filter, findtag, tags, key, keyvalue, callback) {


    if (!filter) {
        filter = {};
    }
    // filter["status.is_deleted"] = false;
    // find = "categories.parent";
    // filter = 'cat_ids';

    // findtag = "offer.tags";
    // tag = "tags";

    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    var findTags = {};
    findTags[findtag] = {
        $regex: tags, $options: 'i'
    };
    var exculde = {};
    exculde[key] = {
        $ne: keyvalue
    };
    var statusFilter = {};
    statusFilter["status.is_deleted"] = false;
    statusFilter["offer.status.is_deleted"] = false;

    // console.log(statusFilter)
    BrandLocation.aggregate([
        { $unwind: "$offer" },
        {
            "$match": {
                "$and": [
                    findFilter, findTags, exculde, statusFilter
                    // { "offer._id": { $ne: ObjectId("5c4ef64355349c15c48b44a7") } }
                ]
            },
        }
    ], callback)
    // db.getCollection('brands').aggregate( [
    //     { $unwind : "$offer" },
    //      { "$match": {
    //             "$and": [
    //             {"categories.parent":{"$in":[
    //             ObjectId("5c4973609ed6b22638d5271a"),
    //             ObjectId("5c4973279ed6b22638d52714")]}},
    //             { "offer.tags": { $regex:"pulao", $options: 'i' } }
    //             ]
    //         }}
    //     ] ,callback)

    // BrandLocation.find({
    //     $and: [findFilter,findTags]
    // }, callback)
    // // BrandLocation.find({
    // //     $and: [
    // //         { "categories.parent": { "$in": cat_id } }
    // //         , { "offer.tags": { $regex: offer_tags, $options: 'i' } }
    // //     ]
    // // }, callback)
}

module.exports.getNearByLocation = function (lng, lat, maxDistance, minDistance, limit, callback) {
    // console.log(limit);
    // return;
    BrandLocation.aggregate([{
        $geoNear: {
            near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
            spherical: true,
            maxDistance: parseFloat(maxDistance),
            minDistance: parseFloat(minDistance),
            distanceField: "dist"
        }
    },
    // { $unwind: "$location" },
    { $limit: parseInt(limit) }], callback);



    //DataBase Query

    //  db.getCollection('brands').aggregate([{
    //     $geoNear: {
    //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
    //          spherical: true,
    //          maxDistance: 300,
    //          minDistance:5,
    //          distanceField: "dist"
    //       }
    //   },{ $unwind: "$location" },{ $limit : 10 }])


    // db.getCollection('brands').aggregate([{
    //     $geoNear: {
    //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
    //          spherical: true,
    //          maxDistance: 200,
    //          distanceField: "dist.calculated",
    //          includeLocs : "coordinates"
    //       }},
    //       { "$addFields": {
    //       "location": {
    //         "$filter": {
    //           "input": "$location",
    //           "as": "location",
    //           "cond": { "$eq": [ "$$location.geometry.coordinates", "$coordinates" ] }
    //         }
    //       }
    //     }},{ $unwind: "$location" }
    //   ])

    //DataBase Query

    // db.getCollection('brands').aggregate([{
    //     $geoNear: {
    //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
    //          spherical: true,
    //          maxDistance: 7 * 1609.34,
    //          distanceMultiplier: 0.000621371,
    //          distanceField: "dist.calculated",
    //          includeLocs : "coordinates"
    //       }},
    // { "$unwind": "$location" },
    // { "$match": {
    //   "location.geometry": {
    //     "$geoWithin": {
    //       "$centerSphere":[[24.860240, 67.064127], 7 / 3963.2]
    //         }
    //       }
    //     }}


    // db.getCollection('brands').aggregate([{
    //     $geoNear: {
    //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
    //          spherical: true,
    //          maxDistance: 200,
    // //          distanceMultiplier: 0.000621371,
    //          distanceField: "dist.calculated",
    //          includeLocs : "coordinates"
    //       }},
    //   { "$unwind": "$location"  },
    //   { "$match": {
    //     "location.geometry": {
    //       "$geoWithin": {
    //         "$centerSphere": [
    //           [24.860240, 67.064127], 7 / 3963.2
    //         ]
    //       }
    //     }
    //   }
    //   }
    //   ])
};
module.exports.getPopularOffer = function (limit, callback) {
    //     if (!filter) {
    //         filter = {};
    //     }
    //     filter["status.is_deleted"] = false;
    BrandLocation.aggregate([{ $unwind: "$offer" }, { $sort: { 'offer.views': -1 } }], callback).limit(parseInt(limit));
};
module.exports.add = function (brandLocation, callback) {
    BrandLocation.create(brandLocation, callback);
};
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    BrandLocation.find(filter).lean().exec(callback);
};
module.exports.add = function (brandLocation, callback) {
    BrandLocation.create(brandLocation, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    BrandLocation.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, brandLocation, callback) {
    brandLocation.$set = {
        "timestamps.updated_at": new Date(),
    }
    BrandLocation.updateOne({ _id: id }, brandLocation, callback);
};
module.exports.updateBrandViews = function (id, callback) {
    // brandLocation.$set = {
    //     "timestamps.updated_at": new Date(),
    // }
    BrandLocation.updateOne({ _id: id }, { $inc: { views: 1 } }, callback);
};
module.exports.updateOfferViews = function (id, callback) {
    // BrandLocation.updateOne({ 'offer._id': '5c384ff61b8b971fc409cc46' }, { $inc: { "offer.$.views": 1 } }, callback);
    BrandLocation.updateOne({ 'offer._id': id }, { $inc: { "offer.$.views": 1 } }, callback);

};
// module.exports.remove_offer = function (id, callback) {
//     var findOne = { "offer._id": id };
//     var query = { $pull: { 'offer': { _id: id } } };
//     var a = { safe: true, upsert: true }
//     BrandLocation.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
// };

module.exports.remove_location = function (id, callback) {
    var findOne = { "location._id": id };
    var query = { $pull: { 'location': { _id: id } } };
    var a = { safe: true, upsert: true }
    BrandLocation.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
};

module.exports.verifyExistance = function (data, callback) {
    BrandLocation.aggregate([
        // { $unwind: "$favouriteOffer" },
        {
            $match: {
                "$and": [{
                    $and: data
                }]
            }
        }], callback)
}
module.exports.updateOffer = function (id, offer_id, offer, callback) {

    BrandLocation.updateOne(
        { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
        { $set: offer }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.removeOffer = function (id, offer_id, callback) {
    BrandLocation.updateOne(
        { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
        {
            $set: {
                "offer.$.status.is_deleted": true,
                "offer.$.status.is_activated": false,
                "offer.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.getDistanceOfNearByLocation = function (lng, lat, brand_id, callback) {

    BrandLocation.aggregate([{
        $geoNear: {
            near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
            spherical: true,
            // maxDistance: parseFloat(maxDistance),
            // minDistance: parseFloat(minDistance),
            distanceMultiplier: 0.001,
            distanceField: "dist"
        }
    },
    {
        $match: {
            $and: [
                { "brand_id": mongoose.Types.ObjectId(brand_id)}
            ]
        }
    },
    { $limit: 1 }], callback);

};

module.exports.advanceSearch = function (lng, lat, tags, city_id, callback) {
    tags = typeof tags == 'string' ? [tags] : tags;
    BrandLocation.aggregate([{
        $geoNear: {
            near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
            spherical: true,
            maxDistance: 1000000,
            minDistance: 0,
            distanceField: "dist"
        }
    },
        {
            $lookup:{
                from: "brands",
                localField : "brand_id",
                foreignField : "_id",
                as : "result"
            }

        },
        {$unwind : "$result"},
        { $match : {
            "$or": [
                { "result.tags" : { "$in" : tags } }

            ],
                "$and" : [
                    { "result.offer.city_id" : mongoose.Types.ObjectId(city_id) }
                ]
        }}
        // {
        //     $match : { $and : [
        //             {
        //                 "result.tags" : { "$in" : tags },
        //                 "result.offer.city_id" : mongoose.Types.ObjectId("5c878f03e20f4b3308ad6f6a")
        //             }
        //         ]
        //
        //     }
        // }
    ], callback)
};

module.exports.globalSearch = function (text, lng, lat, flag, sort = {},city_id, callback) {
    // Brand.dropIndex("tags_text_name_text_description_text_offer.tags_text_offer.title_text_offer.offer_description_text")
    // console.log('here')
    // Brand.index({"tags":"text","name":"text","description":"text","offer.tags":"text","offer.title":"text","offer.offer_description":"text"},callback)
    // return;
    // console.log(lng ,lat,(sort == undefined));
    // console.log((lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort == null || sort == undefined));
    // return;
    // console.log(text)
    if (flag == true) {
        // if ((text != undefined || text != null || text != "") && (sort != null || sort != undefined)) {
        //     console.log('if')
        //     BrandLocation.find({ $text: { $search: text } }, { score: { $meta: "textScore" } }, callback).sort(sort);
        // }
        if ((text == undefined || text == null) && (lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort != null || sort != undefined)) {
            // console.log('else if')
            BrandLocation.aggregate([{
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(lat),parseFloat(lng)] },
                    spherical: true,
                    maxDistance: 1000,
                    minDistance: 0,
                    distanceField: "dist"
                }
            },
            {
                $lookup : {
                    from: "brands",
                    localField : "brand_id",
                    foreignField : "_id",
                    as : "brand"
                }
            }
                ,{
                   $match : {city_id : mongoose.Types.ObjectId(city_id)}
                }
                // ,{ $unwind: "$brand" }
                // ,{ $unwind: "$brand.offer" }
                // ,{$match : {"brand.offer.city_id": mongoose.Types.ObjectId(city_id) }}
                // ,{ $unwind: "$location" }
                // ,{ $limit: parseInt(limit) }
            ], callback);
        }
        else if ((text == undefined || text == null) && (sort != null || sort != undefined)) {
            BrandLocation.find({}, callback).sort(sort)
        }
    }
    else {
        if (flag == false) {
            if (text != undefined || text != null && (sort != null || sort != undefined)) {
                Brand.find({
                    "$or": [
                        { name: { $regex: text, $options: 'i' } }
                        , { description: { $regex: text, $options: 'i' } }
                        , { tags: { $regex: text, $options: 'i' } }
                        , { "offer.title": { $regex: text, $options: 'i' } }
                        , { "offer.offer_description": { $regex: text, $options: 'i' } }
                        , { "offer.tags": { $regex: text, $options: 'i' } }
                    ]
                }, callback).sort(sort);
            }
        }
    }
 };

module.exports.globalSearchNew = function (text, lng, lat, flag, sort = {},city_id, callback) {
    // Brand.dropIndex("tags_text_name_text_description_text_offer.tags_text_offer.title_text_offer.offer_description_text")
    // console.log('here')
    // Brand.index({"tags":"text","name":"text","description":"text","offer.tags":"text","offer.title":"text","offer.offer_description":"text"},callback)
    // return;
    // console.log(lng ,lat,(sort == undefined));
    // console.log((lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort == null || sort == undefined));
    // return;

    if (flag == true) {
        // if ((text != undefined || text != null || text != "") && (sort != null || sort != undefined)) {
        //     console.log('if')
        //     BrandLocation.find({ $text: { $search: text } }, { score: { $meta: "textScore" } }, callback).sort(sort);
        // }
        if ((text == undefined || text == "") && (lng != undefined || lng != null) && (lat != undefined || lat != null)) {
            BrandLocation.aggregate([{
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(lat),parseFloat(lng)] },
                    spherical: true,
                    maxDistance: 10000,
                    minDistance: 0,
                    distanceField: "dist"
                }
            },
                {
                    $lookup : {
                        from: "brands",
                        localField : "brand_id",
                        foreignField : "_id",
                        as : "brand"
                    }
                }
                , {
                    $match: {
                        $and: [
                            {city_id: mongoose.Types.ObjectId(city_id), "brand": {$ne: []}}
                        ]
                    }
                },
                { $project : {"_id":1, "status":1, "brand_id": 1,"dist" : 1, "brand._id" : 1, "brand.status":1, "brand.tags":1, "brand.views": 1, "brand.name":1, "brand.banner":1, "brand.icon":1, "brand.description":1, "brand.webUrl":1, "brand.offer":[], "geometry":1}}

                // ,{ $unwind: "$brand" }
                // ,{ $unwind: "$brand.offer" }
                // ,{$match : {"brand.offer.city_id": mongoose.Types.ObjectId(city_id) }}
                // ,{ $unwind: "$location" }
                // ,{ $limit: parseInt(limit) }
            ], callback);
        }
        else if ((text == undefined || text == null) && (sort != null || sort != undefined)) {
            BrandLocation.find({}, callback).sort(sort)
        }
    }
    else {
        if (flag == false) {
            if (text != undefined || text != null && (sort != null || sort != undefined)) {
                Brand.find({
                    "$or": [
                        { name: { $regex: text, $options: 'i' } }
                        , { description: { $regex: text, $options: 'i' } }
                        , { tags: { $regex: text, $options: 'i' } }
                        , { "offer.title": { $regex: text, $options: 'i' } }
                        , { "offer.offer_description": { $regex: text, $options: 'i' } }
                        , { "offer.tags": { $regex: text, $options: 'i' } }
                    ]
                }, callback).sort(sort);
            }
        }
    }
};

module.exports.getLocationCode = function (location_id, code, callback) {
    BrandLocation.find({_id : mongoose.Types.ObjectId(location_id), code : code}).lean().exec(callback);
}

module.exports.addLocationCsv = function (brandLocation, callback) {
    BrandLocation.create(brandLocation, callback);
};

module.exports.getBrandLocationsByBrandId = function (brand_id, callback) {
    BrandLocation.find({brand_id : mongoose.Types.ObjectId(brand_id)}, callback);
};

module.exports.getAllLocations = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    BrandLocation.find(filter).lean().exec(callback);
};

module.exports.getMapedLocation = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    BrandLocation.find(filter, {_id:1}).lean().exec(callback)
}
