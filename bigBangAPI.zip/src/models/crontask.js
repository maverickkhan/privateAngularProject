import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
let ObjectId = mongoose.Schema.Types.ObjectId;
let resultSchema = mongoose.Schema({
    success_count: {
        type: Number,
        default : 0

    },
    failure_count : {
        type: Number,
        default : 0

    },
    failed_reason : [{
        code : {
            type: String

        },
        // message : {
        //     type: String
        //
        // },
        count : {
            type: Number
        }

    }]
})
let detailSchema = mongoose.Schema({
    identifier : {
        type: String,
        default : null

    },

    status : {
        type: Boolean,
        default : false

    },
    comment : {
        type: String,
        default : null

    },
    data_processed : {
        type: Boolean,
        default : false

    },

});
let crontaskSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    notification_id : {
        type: ObjectId
    },
    targetAPI: {
        type: String
    },
    meta: {
        type: String,
        required: true
    },
    is_reoccurring: {
        type: Boolean,
        required: true,
        default:false
    },
    start_after_minutes:{
        type: String,
        default:false
    },
    start_date: {
        type: Date,
        required: false
    },
    end_date: {
        type: Date,
        default:null
    },
    is_executed: {
        type: Boolean,
        default:false
    },
    details: [detailSchema],
    result:resultSchema,

    timestamps: TIME_STAMPES,
    status: FLAGS,
});
let Crontask = module.exports = mongoose.model('crontask', crontaskSchema);

module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // crontask(filter,callback);
    Crontask.find(filter).lean().exec(callback);
};

module.exports.add = function (crontask, callback) {
    Crontask.create(crontask, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Crontask.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, crontask, callback) {
    var data = {};
    data = { result : {
            success_count: crontask['result'].success_count,
            failure_count: crontask['result'].failure_count,
            failed_reason: crontask['result'].failed_reason
    },
        is_executed: crontask['is_executed'],
        end_date: new Date(),

        "timestamps.updated_at": new Date(),
    }
    Crontask.updateOne({ _id: id }, data, callback);
};

module.exports.getMaxCron = function (callback) {
    Crontask.find({}).sort({"timestamps.created_at" : -1}).limit(1).lean().exec(callback);
}

module.exports.updateCron = function (id, crontask, callback) {
    Crontask.updateOne({ _id: id }, {$push : crontask}, callback);
};

module.exports.addCron = function (crontask, callback) {
    Crontask.create(crontask, callback);
};
