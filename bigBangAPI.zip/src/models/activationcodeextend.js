import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;

let activationCodeExtendSchema = mongoose.Schema({
    activation_code : {
        type : String,
        required : true
    },
    previousEndDate : {
        type: Date,
        required : true
    },
    currentEndDate : {
        type: Date,
        required : true
    },
    comments : {
        type : String,
        required : true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
})

let ActivationCodeExtend = module.exports = mongoose.model('activationdateextends', activationCodeExtendSchema);

module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Activationcode.find(findFilter, callback);
};
// module.exports.get = function (filter, callback) {
//     if (!filter) {
//         filter = {};
//     }
//     filter["status.is_deleted"] = false;
//     Activationcode.find(filter).lean().exec(callback);
// };
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    ActivationCodeExtend.find(filter).lean().exec(callback);
};

module.exports.getMax = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    ActivationCodeExtend.findOne(filter).sort({ "activation_code.serial": -1 }).exec(callback);
};

module.exports.add = function (code, callback) {
    ActivationCodeExtend.create(code, callback);
};

module.exports.remove = function (id, code, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    ActivationCodeExtend.updateOne({ _id: id }, code, callback);
};

module.exports.update = function (id, activation, callback) {
    activation.$set = {
        "timestamps.updated_at": new Date(),
    }
    ActivationCodeExtend.updateOne({ "_id": id }, activation, callback);
};

module.exports.addExtendDate = function (code, callback) {
    ActivationCodeExtend.create(code, callback);
};
