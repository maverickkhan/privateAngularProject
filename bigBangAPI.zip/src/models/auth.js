import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;
let authSchema = mongoose.Schema({
    first_name: {
        type: String,
        required: true,
        // validate: /[a-z]/
        // validate: [/[a-z]/,'invalid name']

        // match: /[a-z]+/,
        // validate:[is]

    },
    last_name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        validate: [isEmail, 'invalid email']
    },
    password: {
        type: String,
        required: true,
    },
    role_id: {
      type : ObjectId,
      required: false,
    },
    timestamps: TIME_STAMPES,
    status: FLAGS,
    token: {
        type: String,
        default : ''
    }
});
let Auth = module.exports = mongoose.model('auth', authSchema);
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // Auth(filter,callback);
    Auth.find(filter).lean().exec(callback);
};
module.exports.add = function (auth, callback) {
    Auth.create(auth, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Auth.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, auth, callback) {
    auth.$set = {
        "timestamps.updated_at": new Date(),
    }
    Auth.updateOne({ _id: id }, auth, callback);
};

module.exports.tokenupdate = function (id, auth, callback) {
    auth.$set = {
        "timestamps.updated_at": new Date(),
    }
    Auth.updateOne({ _id: id }, auth, callback);
};

module.exports.getUserByToken = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // Auth(filter,callback);
    Auth.find(filter).lean().exec(callback);
};
