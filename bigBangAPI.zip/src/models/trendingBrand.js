import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
let ObjectId = mongoose.Schema.Types.ObjectId;
let trendingBrandSchema = mongoose.Schema({
    brand_id: {
        type: ObjectId,
        required: true,
        unique: true
    },
    sorting_order: {
        type: Number,
        required: true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
});
let TrendingBrand = module.exports = mongoose.model('trendingBrands', trendingBrandSchema);
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    TrendingBrand.find(filter).lean().exec(callback);
};
module.exports.add = function (trendingBrand, callback) {
    TrendingBrand.create(trendingBrand, callback);
};
module.exports.update = function (id, update, callback) {
    update.$set = {
        'timestamps.updated_at': new Date()
    };
    TrendingBrand.updateOne({ _id: id }, update, callback);
};
module.exports.remove = function (id, callback) {
 
    TrendingBrand.findOneAndDelete({ _id: id }, callback);
};
module.exports.advanceSearch = function (tags, callback) {
    tags = typeof tags == 'string' ? [tags] : tags;
    TrendingBrand.aggregate([
        {
            $lookup:{
                from: "brands",
                localField : "brand_id",
                foreignField : "_id",
                as : "result"
            }

        },
        {$unwind : "$result"},
        {
            $match : {
                "result.tags" : { "$in" : tags }
            }
        },
        { $project : {result : 1}}
    ], callback)
}
