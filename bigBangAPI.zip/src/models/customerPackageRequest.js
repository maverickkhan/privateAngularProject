import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
let ObjectId = mongoose.Schema.Types.ObjectId;

let customerPackageRequestSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true,
    },
    email : {
      type : String,
      required: true,
    },
    alternate_phone : {
      type : String
    },
    note : {
        type : String
    },
    package_Id: {
        type: ObjectId,
        // required: true,
    },
    timestamps: TIME_STAMPES,
    status: FLAGS,
});

let CustomerPkgReq = module.exports = mongoose.model('customerPackageRequest', customerPackageRequestSchema);
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // customerPackageRequest.find(filter,callback);
    CustomerPkgReq.find(filter).lean().exec(callback);
};
module.exports.add = function (customerPackageRequest, callback) {
    CustomerPkgReq.create(customerPackageRequest, callback);
};
module.exports.addPackage = function (customerPackageRequest, callback) {
    CustomerPkgReq.create(customerPackageRequest, callback);
};
module.exports.update = function (id, customerPackageRequest, callback) {
    CustomerPkgReq.$set = {
        "timestamps.updated_at": new Date(),
    }
    CustomerPkgReq.updateOne({ _id: id }, customerPackageRequest, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    CustomerPkgReq.updateOne({ _id: id }, remove, callback);
};

