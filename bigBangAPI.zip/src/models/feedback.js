import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
let ObjectId = mongoose.Schema.Types.ObjectId;

let feedbackSchema = mongoose.Schema({
    type: {
        type: String,
        required: true
    },
    feedback : {
      type: String,
      required: true
    },
    customer_name : {
        type: String,
        required: true
    },
    customer_phone: {
        type: String,
        required: true
    },
    customer_email : {
        type: String,
        required: true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
})

let Feedback = module.exports = mongoose.model('feedbacks', feedbackSchema);

module.exports.add = function (feedback, callback) {
    Feedback.create(feedback, callback);
};

module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    Feedback.find(filter).lean().exec(callback);
};
