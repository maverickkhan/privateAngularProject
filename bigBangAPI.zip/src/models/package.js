import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
let ObjectId = mongoose.Schema.Types.ObjectId;
let is_expirableSchema = mongoose.Schema({
    _id: false,
    start_at: {
        type: Date,
        default: Date.now
    },
    end_at: {
        type: Date,
        default: Date.now
    },
    is_expire: {
        type: Boolean,
        default: false
    }

});
let PackageSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    city_id: {
        type: ObjectId,
        required: true
    },
    country_id: {
        type: ObjectId,
        required: true
    },
    features: {
        // brands: [{
        //     type: ObjectId,
        //     required: true
        // }],
        offers: [{
            type: ObjectId,
            // required: true
        }],
        // categories: [{
        //     type: ObjectId,
        //     required: true
        // }]
    },
    is_expirable: is_expirableSchema,
    timestamps: TIME_STAMPES,
    status: FLAGS,
    price : {
        type: Number,
        default: 0
    }
});
let Package = module.exports = mongoose.model('package', PackageSchema);
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Package.find(filter).lean().exec(callback);
};
module.exports.add = function (pkg, callback) {
    Package.create(pkg, callback);
};
module.exports.update = function (id, pkg, callback) {
    let update = {
        'name': pkg.name,
        'features': {
            // 'brands': pkg['brands'],
            'offers': pkg['offers'],
            // 'categories': pkg['categories']
        },
        'is_expirable': {
            'start_at': pkg['start_at'],
            'end_at': pkg['end_at'],
            'is_expire': pkg['is_expire']
        },
        'timestamps.updated_at': new Date()
    };
    Package.updateOne({ _id: id }, update, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Package.updateOne({ _id: id }, remove, callback);
};
module.exports.updatePkgOffer = function (id, pkg, callback) {
    pkg.$set = {
        "timestamps.updated_at": new Date(),
    }
    Package.updateOne({ _id: id }, pkg, callback);
};

module.exports.getPackageByCity = function (city_id, callback) {
    Package.find({ "city_id": mongoose.Types.ObjectId(city_id) }, callback);
}
module.exports.removeOfferIdFromAllPackages = function (offer_id, callback) {
    Package.updateMany(
        {},
        { $pull: { 'features.offers': mongoose.Types.ObjectId(offer_id) } },
        { multi: true },
        callback)

}
module.exports.getOfferPackages = function(offer_id, callback){
    // console.log(offer_id)
    Package.get({"features.offers" : mongoose.Types.ObjectId(offer_id)},callback)
}

module.exports.getOfferPack = function(offer_id, callback){
    // console.log(offer_id)
    Package.get({"features.offers" : {$in : offer_id}},callback)
}

module.exports.getPackageByPackageIds = function(package_id, callback){
    // console.log(package_id)
    Package.get({"_id" : {$in : package_id}},callback)
}

module.exports.getPackageByOldID = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Package.find(filter).lean().exec(callback);
};

module.exports.updatePackageCsv = function (id, package_data, callback) {
    package_data.$set = {
        "timestamps.updated_at": new Date(),
    }
    Package.updateOne({ _id: id }, package_data, callback);
};
