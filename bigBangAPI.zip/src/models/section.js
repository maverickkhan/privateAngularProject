import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
let ObjectId = mongoose.Schema.Types.ObjectId;

let section_bgSchema = mongoose.Schema({
    is_bg_image : {
        type : Boolean,
        required : true
    },
    background : {
        type : String,
        required : true
    }
})
let sectionSchema = mongoose.Schema({
    screen_id : {
        type : ObjectId,
        required : true
    },
    title: {
        type: String,
        required: true
    },
    web_service: {
        type: String,
        required: true
    },
    list_item_limit: {
        type : Number,
        default: 0
    },
    section_bg: section_bgSchema,
    section_type: { // List / collection / carousel / slider / single /
        type: String,
        required: true
    },
    sort_order: {
        type : Number,
        default: 0
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
    // _id : false if i want to keep id disable
})

let Mobilehomesection = module.exports = mongoose.model('sections', sectionSchema);

module.exports.addsection = function (mobilehomesection, callback) {
    // Mobilehomesection.create(mobilehomesection, callback);
    Mobilehomesection.insertMany(mobilehomesection,callback);
};
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Mobilehomesection.find(filter).sort({"sort_order" : 1}).lean().exec(callback);
};

module.exports.update = function (id,screen_id, mobilehomesection, callback) {
    mobilehomesection.$set = {
        "timestamps.updated_at": new Date(),
    }
    Mobilehomesection.updateOne({ _id: id, screen_id: screen_id }, mobilehomesection, callback);
};

module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Mobilehomesection.updateMany({ screen_id: id }, remove, callback);
};

module.exports.removeSingle = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Mobilehomesection.updateOne({ _id: id }, remove, callback);
};
