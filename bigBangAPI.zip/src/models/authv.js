import mongoose from 'mongoose';
import {generateResponse} from "../utilites";
let ObjectId = mongoose.Schema.Types.ObjectId;
import Usergroup from '../models/auth';
// var usersRoles = {
//     adminUrooj   : "admin",
//     editorUrooj  : "editor",
//     authorUrooj  : "author",
//     subUrooj     : "subscriber",
//     "sub@sub.com" : "sub",
//     "testemail2@hello.com" : "admin"
// }

module.exports.getroles = function(user){
    // return usersRoles[user];
    Usergroup.get({
        email: user
    }, (err, usergroup) => {
        if (err) {
            var errors = err.errmsg;
            generateResponse(false, ' Unable to process your request, Please retry in few minutes', errors, res, [], []);
        }
        else{
            let key =  usergroup[0].email;
            var usersRoles = {};
            usersRoles[key] = usergroup[0].usergroup
            return usersRoles[key];
        }
    })





}