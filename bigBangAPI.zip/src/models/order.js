import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;
// mongoose.mongo.ObjectId.// mongoose.Types.ObjectId
// :[]
let offerSchema = mongoose.Schema({
    offer_id: {
        type: ObjectId,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    },
    amount: {
        type: Number,
        required: true
    },
})
let orderSchema = mongoose.Schema({
    order_number: {
        type: String,
        required: true
    },
    customer_id: {
        type: ObjectId,
        required: true
    },
    customer_name : {
      type: String,
      required : true
    },
    grand_total: {
        type: Number,
        required: true
    },
    order_status: {
        type: String,
        required: true
    },
    offer: [offerSchema],
    timestamps: TIME_STAMPES,
    status: FLAGS
});
let Order = module.exports = mongoose.model('orders', orderSchema);
module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Country.find(findFilter, callback);
};
module.exports.getAggregateCity = function (id, search, callback){
    Country.aggregate([
        { $unwind: "$cities" }
        ,{ $match :
                { $and: [
                        { "cities.city_name" : { $regex: search, $options: "i" } },
                        {"_id" : mongoose.Types.ObjectId(id)},
                        {"cities.status.is_deleted" : false},
                        {"cities.status.is_activated" : true}
                    ] }
        },
        { $group : {_id : "$_id", city: { $push: "$cities" }}
        }
    ], callback)
}
module.exports.getAggregateArea = function(id,city_id,search,callback){
    // console.log(mongoose.Types.ObjectId(id))
    Country.aggregate([
        { $unwind: "$cities" },
        { $unwind: "$cities.areas" }

        ,{ $match :
                { $and: [
                        { "cities.areas.area_name" : { $regex: search, $options: "i" } },
                        {"_id" : mongoose.Types.ObjectId(id)},
                        {"cities._id" : mongoose.Types.ObjectId(city_id)},
                        {"cities.areas.status.is_deleted" : false},
                        {"cities.areas.status.is_activated" : true}
                    ] }
        },
        { $group : {_id : "$cities._id", areas: { $push: "$cities.areas" }}
        }
    ], callback)
}
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Country.find(filter).lean().exec(callback);
};
module.exports.add = function (order, callback) {
    Order.create(order, callback);
};
module.exports.getMaxOrderNumber = function(callback){
    Order.find().sort({order_number:-1}).limit(1).exec(callback);
};

module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Country.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, country, callback) {
    country.$set = {
        "timestamps.updated_at": new Date(),
    }
    Country.updateOne({ _id: id }, country, callback);
};
module.exports.verifyExistance = function (data, callback) {
    Country.aggregate([
        // { $unwind: "$favouriteOffer" },
        {
            $match: {
                "$and": [{
                    $and: data
                }]
            }
        }], callback)
}
module.exports.updateCity = function (id, city_id, city, callback) {
    // console.log( { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
    // {$set:offer})
    // return;
    Country.updateOne(
        { _id: mongoose.Types.ObjectId(id), "cities._id": mongoose.Types.ObjectId(city_id) },
        { $set: city }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.removeCity = function (id, city_id, callback) {
    Country.updateOne(
        { _id: mongoose.Types.ObjectId(id), "cities._id": mongoose.Types.ObjectId(city_id) },
        {
            $set: {
                "cities.$.status.is_deleted": true,
                "cities.$.status.is_activated": false,
                "cities.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.createArea = function (path,country, callback) {
    country.$set = {
        "cities.$.timestamps.updated_at": new Date(),
    }
    Country.updateOne(path, country, callback);
};
module.exports.updateArea = function (id,area_id, area, callback) {
    // console.log(area); return;
    Country.updateOne(
        { _id: mongoose.Types.ObjectId(id),"cities.areas._id": mongoose.Types.ObjectId(area_id) },
        { $set: area }
        , callback)

};

// db.getCollection('countrys').updateOne({ "cities.areas._id": ObjectId("5c90a139ce8d770a98e38c8b") },
// { $pull: { 'cities.$.areas': { _id: ObjectId("5c90a139ce8d770a98e38c8b") } } }
// );//EVERYTHING GOT REMOVED});
module.exports.remove_area = function (id, callback) {
        var findOne = { "cities.areas._id": id };
        var query ={ $pull: { 'cities.$.areas': { _id: id } } }
        var a = { safe: true, upsert: true }
        Country.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
    };
