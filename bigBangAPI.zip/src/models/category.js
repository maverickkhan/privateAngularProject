import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
import Brands from "../models/brand"
let ObjectId = mongoose.Schema.Types.ObjectId;

let subCategorySchema = mongoose.Schema({
    sub_name: {
        type: String,
        required: true
    },
    sub_icon: {
        type: String,
        required: true
    },
    sub_bgcolor: {
        type: String,
        required: true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
    // _id : false if i want to keep id disable
})
let categorySchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    icon: {
        type: String,
        required: true
    },
    bgcolor: {
        type: String,
        required: true
    },
    subCategory: [subCategorySchema],
    timestamps: TIME_STAMPES,
    status: FLAGS,
    sort_order : {
        type : Number,
        default : 0
    }
    // _id : false if i want to keep id disable
});
let Category = module.exports = mongoose.model('categorys', categorySchema);
 // Brands = module.exports = mongoose.model('brands', brandSchema);
// module.exports.getCategoryRecord = function (filter,callback) {
//     if (!filter) {
//         filter = {};
//      }
//     filter["status.is_deleted"] = false;
//     Category.find({"_id": {$in: filter}}, callback);
// };
module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Category.find(findFilter, callback);
};
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Category.find(filter).lean().exec(callback);
};
module.exports.getAggregateSubcategory = function (id, search, callback){
    let data = [
        { "subCategory.sub_name" : { $regex: search, $options: "i" } },
        {"_id" : mongoose.Types.ObjectId(id)},

    {"subCategory.status.is_deleted" : false},
    {"subCategory.status.is_activated" : true} ]
    Category.aggregate([
        { $unwind: "$subCategory" }
        ,{ $match :
                { $and: data }
        },
        { $group : {_id : "$_id", subCategory: { $push: "$subCategory" }}
        }
    ], callback)
}

module.exports.getAggregateSubcategoryOne = function (id,sub_id, callback){
    let data = [
        {"subCategory._id" : mongoose.Types.ObjectId(sub_id)},
        {"_id" : mongoose.Types.ObjectId(id)},
        {"subCategory.status.is_deleted" : false},
        {"subCategory.status.is_activated" : true} ]
    Category.aggregate([
        { $unwind: "$subCategory" }
        ,{ $match :
                { $and: data }
        },
        { $group : {_id : "$_id", subCategory: { $push: "$subCategory" }}
        }
    ], callback)
}
module.exports.add = function (category, callback) {
    Category.create(category, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Category.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, category, callback) {
    category.$set = {
        "timestamps.updated_at": new Date(),
    }
    Category.updateOne({ _id: id }, category, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Category.updateOne({ _id: id }, remove, callback);
};
module.exports.updateSubCat = function (id, sub_cat_id, sub_cat, callback) {
    Category.updateOne(
        { _id: mongoose.Types.ObjectId(id), "subCategory._id": mongoose.Types.ObjectId(sub_cat_id) },
        { $set: sub_cat }
        , callback)
};
module.exports.verifyExistance = function (data, callback) {
    Category.aggregate([
    {
        $match: {
            "$and": [{
                $and:data
                    }]
        }
    }],callback)
}
module.exports.removeSubCat = function (id, offer_id, callback) {
    Category.updateOne(
        { _id: mongoose.Types.ObjectId(id), "subCategory._id": mongoose.Types.ObjectId(offer_id) },
        {
            $set: {
                "subCategory.$.status.is_deleted": true,
                "subCategory.$.status.is_activated": false,
                "subCategory.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
};

module.exports.getBrandByCategory = function (category_id,city_id, callback) {
    Category.aggregate([
        {
            $match : {
                $and: [
                    { "_id" : mongoose.Types.ObjectId(category_id) }, // Category ID
                    { "status.is_deleted" : false } ]
            }
        },
        {
            $lookup:{
                from: "brands",
                localField : "_id",
                foreignField : "categories.parent",
                as : "result"
            }
        },
        {
            $match : {
                $and: [
                    { "result.status.is_deleted" : false },
                    { "result.offer.city_id" : mongoose.Types.ObjectId(city_id) } // City ID
                 ]
            }
        }
        ,
        {
            $unwind : "$result"
        }
        ,
        {
            $sort : { "result.sort_order" : 1 }
        },
        //check here
        { $project : {_id : "_id", name : 1, "result._id" : 1, "result.name" : 1, "result.icon" : 1, "result.banner": 1, "result.tags" : 1, "result.status" : 1, "result.description" : 1, "result.views" : 1, "result.webUrl" : 1}},
        {
            $group : {
                "_id": mongoose.Types.ObjectId(category_id),
                "name": { $first : "$name" },
                // "bgcolor" : { $first : "$bgcolor" } ,
                // "icon" : { $first : "$icon"  },
                // "old_id" : { $first : "$old_id" } ,
                // "sort_order" : { $first : "$sort_order"  },
                // "timestamps" : { $first : "$timestamps" },
                // "status" : { $first : "$status" },
                // "subCategory" : { $first : "$subCategory" },
                "result" : {$push :  "$result"}}
        }
    ],callback)

}

module.exports.getBrandBySubCategory = function (subcategory_id, callback) {
    Category.aggregate([
        {$unwind : "$subCategory"},
        {

            $match : {
                $and: [
                    { "subCategory._id" : mongoose.Types.ObjectId(subcategory_id) }, // Sub Category ID
                    { "status.is_deleted" : false },
                    { "subCategory.status.is_deleted" : false } ]
            }
        },
        {
            $lookup:{
                from: "brands",
                localField : "subCategory._id",
                foreignField : "categories.child",
                as : "result"
            }
        },
        {
            $match : {
                $and: [
                    { "result.status.is_deleted" : false } ]
            }
        }
    ],callback)

}

module.exports.getCategoryByOldId = function (id, callback) {
    Category.find({old_id: id}, callback);
};

module.exports.getBrandByCategoryPagination = function (page, limit, city_id, category_id, callback) {
    if(page == 1){
        page = 0
    }
    Category.aggregate([
        {
            $lookup:{
                from: "brands",
                localField : "_id",
                foreignField : "categories.parent",
                as : "result"
            }
        },
        {
            $match : {
                $and: [
                    { "result.status.is_deleted" : false },
                    { "result.offer.city_id" : mongoose.Types.ObjectId(city_id) }, // City ID
                    { "_id" : mongoose.Types.ObjectId(category_id) }, // Category ID
                    { "status.is_deleted" : false }
                ]
            }
        }
        ,
        {
            $unwind : "$result"
        }
        ,
        {
            $sort : { "result.sort_order" : 1 }
        }

        ,
        {
            $skip : (parseInt(limit) * parseInt(page))
        }
        ,
        {
            $limit : parseInt(limit)
        }
        ,{
            $group : {
                "_id": "$_id" ,
                "name": { $first : "$name" },
                "bgcolor" : { $first : "$bgcolor" } ,
                "icon" : { $first : "$icon"  },
                "old_id" : { $first : "$old_id" } ,
                "sort_order" : { $first : "$sort_order"  },
                "timestamps" : { $first : "$timestamps" },
                "status" : { $first : "$status" },
                "subCategory" : { $first : "$subCategory" },
                "result" : {$push :  "$result"}}
        }
    ], callback)
}
