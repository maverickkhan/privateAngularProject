import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;

let promoCodeSchema = mongoose.Schema({
    package_id: {
        type: ObjectId,
        required: true
    },
    code: {
        type: String,
        required: true
    },
    validity: {
        type: String,
        required: true
    },
    reg_active : {
        type : Boolean,
        default : false
    },
    start_date: {
        type: Date,
        default: Date.now
    },
    end_date: {
        type: Date,
        default: Date.now
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
});

let Promocode = module.exports = mongoose.model('promocodes', promoCodeSchema);

module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Promocode.find(findFilter, callback);
};
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Promocode.find(filter).lean().exec(callback);
};

module.exports.add = function (code, callback) {
    Promocode.create(code, callback);
};

module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Promocode.updateOne({ _id: id }, remove, callback);
};

module.exports.getRegPromo = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Promocode.find(filter).limit(1).lean().exec(callback);
};

// module.exports.update = function (id, activation, callback) {
//     activation.$set = {
//         "timestamps.updated_at": new Date(),
//     }
//     Promocode.updateOne({ "activation_code._id": id }, activation, callback);
// };
