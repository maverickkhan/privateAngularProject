import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
import { stringify } from 'querystring';
let ObjectId = mongoose.Schema.Types.ObjectId;
let orderSchema = mongoose.Schema({
    brand_id: {
        type: ObjectId,
    },
    offer_id: {
        type: ObjectId,
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
})

let offerAvailSchema = mongoose.Schema({
    offer_id: {
        type: ObjectId
    },
    total_amount: {
        type: String,
        required: true
    },
    save_Amount: {
        type: String
    },
    avail_on: {
        type: Date,
        default: Date.now
    },
    _id: false,

})
let favouriteOfferSchema = mongoose.Schema({
    offer: {
        type: ObjectId,
        // required: true
    },
    _id: false,
    timestamps: TIME_STAMPES,
    status: FLAGS,
})
let favouriteBrandSchema = mongoose.Schema({
    brand: {
        type: ObjectId,
        // required: true
    },
    _id: false,
    timestamps: TIME_STAMPES,
    status: FLAGS,
})
let subscriptionSchema = mongoose.Schema({
    package_id: {
        type: ObjectId
    },
    start_at: {
        type: Date,
        default: Date.now
    },
    end_at: {
        type: Date,
        default: Date.now
    },
    subscription_status: {
        type: Boolean,
        default: true
    },
    activation_code_id: {
        type: ObjectId
    },
    promo_code_id: {
        type: ObjectId
    },
    // _id: false,
    timestamps: TIME_STAMPES,
    status: FLAGS,
})
let deviceSchema = mongoose.Schema({
    device_id: [{
        type: String,
        // required: true
    }],
    device_name: {
        type: String,
        // required: true
    },
    _id: false,
    timestamps: TIME_STAMPES,
    status: FLAGS
})
let customerSchema = mongoose.Schema({
    first_name: {
        type: String,
        required: true
    },
    device: deviceSchema,
    subscription: [subscriptionSchema],
    // orders: {
    //     brands: [{
    //         type: ObjectId,
    //     }],
    //     offers: [{
    //         type: ObjectId,
    //     }],
    // },
    last_name: {
        type: String,
        required: false
    },
    email: {
        type: String,
        required: false,
        // unique: true
        // validate: [isEmail, 'invalid email']
    },
    password: {
        type: String,
        required: false,
    },
    gender: {
        type: String,
        required: false
    },
    date_of_birth: {
        type: Date,
        // required: true
    },
    passwordResetToken: {
        type: String,
        default: null
    },
    passwordResetExpires: {
        type: Date,
        default: null
    },
    phone: {
        type: String,
        required: false,
    },
    favouriteOffer: [favouriteOfferSchema],
    favouriteBrand: [favouriteBrandSchema],
    city: {
        type: ObjectId,
        required: false,
    },
    refer_id: {
        type: String,
        unique: true
        // required: true
    },
    role_id: {
        type: ObjectId,
        required: true
    },
    refered: {
        customer_id: [{
            type: ObjectId,
            // required: true
        }]
    },

    offer_Avail: [offerAvailSchema],
    notification_ids: [
        {
            type: ObjectId
            // required: true
        }
    ],
    // package_Id: {
    //     type: ObjectId,
    //     // required: true,
    // },
    timestamps: TIME_STAMPES,
    status: FLAGS,
    activation_code : {
        type : String,
        default : ""
    },
    old_id : {
        type : String,
        default : ""
    },
    points : {
        type : Number,
        default : 0
    },
    fb_id : {
        type : Number,
        unique: true,
        default : 0
    },
    email_verified : {
        type : Boolean
    }
});

var validateEmail = function (email) {
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(email)
};
let Customer =  module.exports = mongoose.model('customer', customerSchema);
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // Customer.find(filter,callback);
    Customer.find(filter).lean().exec(callback);
};
module.exports.add = function (customer, callback) {
    Customer.create(customer, callback);
};
// module.exports.save = function (customer, callback) {
//     Customer.save(customer, callback);
// };
//model
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.getdata = function (gdate, ldate, callback) {
    let obj = {};
    if (gdate != null || ldate != null) {
        obj = { $or: [{ 'offer_Avail.avail_on': { $gte: new Date(gdate), $lte: new Date(ldate) } }] };
    }
    Customer.find(obj).lean().exec(callback);
};

module.exports.update = function (id, customer, callback) {
    customer.$set = {
        "timestamps.updated_at": new Date(),
    }
    Customer.updateOne({ _id: id }, customer, callback);
};

module.exports.updateWithPoints = function (id, customer, points, callback) {
    customer.$set = {
        "timestamps.updated_at": new Date(),
    }
    customer.$set = {
        "points": points,
    }
    Customer.updateOne({ _id: id }, customer, callback);
};

module.exports.updateByDeviceId = function (device_id, notification_id, callback) {
    let noti = mongoose.Types.ObjectId(notification_id);
    let customer = {}
    customer.$set = {
        "timestamps.updated_at": new Date()

    }
    customer.$push = {
        "notification_ids": [noti]
    }
    Customer.updateOne({ "device.device_id": device_id }, customer, callback);
};
module.exports.updateByGetPackage = function (id, customer,customer_package, callback) {
    customer.$set = {
        "timestamps.updated_at": new Date()

    }
    customer.$push = {
        "subscription": customer_package
    }
    // console.log(customer)
    Customer.update({ _id : id }, customer, callback);
};

module.exports.updateByGetPackagetest = function (id, customer,customer_package, callback) {
    customer.$set = {
        "timestamps.updated_at": new Date()

    }
    customer.$push = {
        "subscription": customer_package
    }
    // console.log(customer)
    Customer.updateOne({ "_id" : id }, customer, callback);
};

module.exports.updateExpiry = function (data, callback) {
    Customer.updateOne(
        { _id: mongoose.Types.ObjectId(data.customer_id), "subscription.activation_code_id": mongoose.Types.ObjectId(data.activation_code_id) },
        {
            $set: {
                "subscription.$.subscription_status": true,
                "subscription.$.end_at": data.currentEndDate,
                "subscription.$.status.is_deleted": false,
                "subscription.$.status.is_activated": true,
                "subscription.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.countAvailOffers = function (customer_id, offer_id, callback) {
    Customer.aggregate([
        {
            $match: { "_id": mongoose.Types.ObjectId(customer_id) }
        },
        { $unwind: "$offer_Avail" }
        , {
            $match: {
                $and: [
                    { "offer_Avail.avail_on": { $gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
                    { "offer_Avail.offer_id": mongoose.Types.ObjectId(offer_id) }
                ]
            }

        }
        , { $count: "total_count" }
    ], callback)
};
module.exports.removeFavouriteOffer = function (id, offer_id, callback) {
    Customer.updateOne(
        { _id: mongoose.Types.ObjectId(id), "favouriteOffer.offer": mongoose.Types.ObjectId(offer_id) },
        {
            $set: {
                "favouriteOffer.$.status.is_deleted": true,
                "favouriteOffer.$.status.is_activated": false,
                "favouriteOffer.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.updateFavouriteOffer = function (id, offer_id, callback) {
    Customer.updateOne(
        { _id: mongoose.Types.ObjectId(id), "favouriteOffer.offer": mongoose.Types.ObjectId(offer_id) },
        {
            $set: {
                "favouriteOffer.$.status.is_deleted": false,
                "favouriteOffer.$.status.is_activated": true,
                "favouriteOffer.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.getFavouriteoffer_1 = function (data, callback) {
    Customer.aggregate([
        // { $unwind: "$favouriteOffer" },
        {
            $match: {
                "$and": [{
                    $and: data
                }]
            }
        }], callback)
}
module.exports.getFavouriteoffer = function (id,city_id, callback) {
    Customer.aggregate([
        { $unwind: "$favouriteOffer" },
        {
            $lookup: {
                from: "brands",
                localField: "favouriteOffer.offer",
                foreignField: "offer._id",
                as: "result"
            }

        }
        , {
            $match: {
                "$and": [{
                    "_id": mongoose.Types.ObjectId(id),
                    'status.is_deleted': false,
                    'favouriteOffer.status.is_deleted': false,
                    "result.offer.city_id" : mongoose.Types.ObjectId(city_id)
                }]
            }

        }
        , {
            $project: { "favouriteOffer": 1, "result.offer": 1, "result._id": 1, "result.name" : 1 }
        }
        , { $unwind: "$result" }
    ], callback)
}
module.exports.getFavouriteBrand = function (id,city_id, callback) {
    Customer.aggregate([
        { $unwind: "$favouriteBrand" },
        {
            $lookup: {
                from: "brands",
                localField: "favouriteBrand.brand",
                foreignField: "_id",
                as: "result"
            }

        }
        , {
            $match: {
                "$and": [{
                    "_id": mongoose.Types.ObjectId(id),
                    'status.is_deleted': false,
                    'favouriteBrand.status.is_deleted': false,
                    "result.offer.city_id" : mongoose.Types.ObjectId(city_id)
                }]
            }

        }
        , {
            $project: { "result": 1 }
        }
        , { $unwind: "$result" }
    ],callback)
}
module.exports.updateFavouriteBrand = function (id, brand_id, callback) {
    Customer.updateOne(
        { _id: mongoose.Types.ObjectId(id), "favouriteBrand.brand": mongoose.Types.ObjectId(brand_id) },
        {
            $set: {
                "favouriteBrand.$.status.is_deleted": false,
                "favouriteBrand.$.status.is_activated": true,
                "favouriteBrand.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.removeFavouriteBrand = function (id, brand_id, callback) {
    Customer.updateOne(
        { _id: mongoose.Types.ObjectId(id), "favouriteBrand.brand": mongoose.Types.ObjectId(brand_id) },
        {
            $set: {
                "favouriteBrand.$.status.is_deleted": true,
                "favouriteBrand.$.status.is_activated": false,
                "favouriteBrand.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.offerAvailDetails = function (customer_id,city_id, callback) {
    // console.log(customer_id, city_id)
    Customer.aggregate([
        {
            $match: {
                $and: [
                    { "_id": mongoose.Types.ObjectId(customer_id) }, // customer ID
                    { "status.is_deleted": false }]
            }
        }
        , { $unwind: "$offer_Avail" }
        , {
            $lookup: {
                from: "brands",
                localField: "offer_Avail.offer_id",
                foreignField: "offer._id",
                as: "result"
            }
        }
        ,{
            $match: {
                $and: [
                    { "result.offer.city_id": mongoose.Types.ObjectId(city_id) }, // City ID
                    { "result.offer.status.is_deleted": false }]
            }
        }
        , { $project: { "offer_Avail": 1, "result.offer": 1, "result._id": 1, "result.name": 1 } }
        , { $unwind: "$result" }
    ], callback)
};

module.exports.getReferFriendCount = function (customer_id, callback) {
    Customer.aggregate([
        {
            $match: { _id: mongoose.Types.ObjectId(customer_id) }
        },
        {
            $project:
                {
                    _id: 0,
                    refCount: { $size: "$refered.customer_id" }
                }
        }
    ], callback)
}

module.exports.updateAddDeviceIdFb_id = function (device_id, customer_id, fb_id, callback) {
    let customer = {}
    customer.$set = {
        "timestamps.updated_at": new Date()

    }
    customer.$set = {
        "fb_id" : fb_id
    }
    customer.$set = {
        "email_verified" : true
    }
    customer.$push = {
        "device.device_id": [device_id]
    }
    Customer.updateOne({ "_id": customer_id }, customer, callback);
};

module.exports.updateAddDeviceId = function (device_id, customer_id, callback) {
    let customer = {}
    customer.$set = {
        "timestamps.updated_at": new Date()

    }
    customer.$set = {
        "email_verified" : false
    }
    customer.$push = {
        "device.device_id": [device_id]
    }
    Customer.updateOne({ "_id": customer_id }, customer, callback);
};

module.exports.addCustomer = function (customer, callback) {
    Customer.create(customer, callback);
};

module.exports.getCustomerByOldId = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // Customer.find(filter,callback);
    Customer.find(filter).lean().exec(callback);
};

module.exports.addSubscription = function (customer_id, subdata, callback) {
    Customer.updateMany(
        {_id : mongoose.Types.ObjectId(customer_id)},
        subdata,
        callback
    )
}

module.exports.customerCount = function (callback) {
    Customer.find({}).countDocuments().lean().exec(callback);
}
module.exports.availOffersCount = function (callback) {
    Customer.aggregate([
        { $unwind: "$offer_Avail" }
        , { $count: "total_avail_offers" }
    ], callback)
};

module.exports.offeravail = function (callback) {
    Customer.aggregate([
        { $unwind: "$offer_Avail" }
        , {
            $lookup: {
                from: "brands",
                localField: "offer_Avail.offer_id",
                foreignField: "offer._id",
                as: "result"
            }
        }
        ,{
            $match: {
                $and: [
                    { "result.offer.status.is_deleted": false }]
            }
        },
        {$limit : 5}
        , { $project: { "first_name" : 1,"phone" : 1,"email" : 1, "offer_Avail": 1, "result.offer": 1, "result._id": 1, "result.name": 1 } }
        , { $unwind: "$result" }
        , { $unwind: "$result.offer" },
        {$sort :{"offer_Avail.avail_on" : -1}}
    ], callback)
}

module.exports.offeravailall = function (callback) {
    Customer.aggregate([
        { $unwind: "$offer_Avail" }
        , {
            $lookup: {
                from: "brands",
                localField: "offer_Avail.offer_id",
                foreignField: "offer._id",
                as: "result"
            }
        }
        ,{
            $match: {
                $and: [
                    { "result.offer.status.is_deleted": false }]
            }
        }
        , { $project: { "first_name" : 1,"phone" : 1,"email" : 1, "offer_Avail": 1, "result.offer": 1, "result._id": 1, "result.name": 1 } }
        , { $unwind: "$result" }
        , { $unwind: "$result.offer" },
        {$sort :{"offer_Avail.avail_on" : -1}}
    ], callback)
}

module.exports.getCustomerByPhone = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // Customer.find(filter,callback);
    Customer.find(filter).lean().exec(callback);
};

module.exports.getPoints = function (callback) {
    Customer.aggregate([
        {"$match" : {"points" : {$gt : 0}}},
        { "$sort": {"points" : -1} },
        { "$group": {
                "_id": "$name",
                "items": { "$push": "$$ROOT" }
            }},
        { "$unwind": { "path": "$items", "includeArrayIndex": "items.rank" } },
        { "$project": {
                "_id": 0,
                "customer_id": "$items._id",
                "first_name": "$items.first_name",
                "points": "$items.points",
                "rank": { "$add": [ "$items.rank", 1 ] }
            }},
        { "$sort": { "rank" : 1} },
        {"$limit" : 20}
    ]).allowDiskUse(true).exec(callback)
};

module.exports.getPointsAll = function (callback) {
    Customer.aggregate([
        {"$match" : {"points" : {$gt : 0}}},
        { "$sort": {"points" : -1} },
        { "$group": {
                "_id": "$name",
                "items": { "$push": "$$ROOT" }
            }},
        { "$unwind": { "path": "$items", "includeArrayIndex": "items.rank" } },
        { "$project": {
                "_id": 0,
                "customer_id": "$items._id",
                "first_name": "$items.first_name",
                "points": "$items.points",
                "rank": { "$add": [ "$items.rank", 1 ] }
            }},
        { "$sort": { "rank" : 1} }
    ]).allowDiskUse(true).exec(callback)
};

module.exports.getAvailOfferBrand = function (start_date = {}, end_date = {},brand_id = {}, callback) {
    Customer.aggregate([
        {
            $match: {
                $and: [
                    { "status.is_deleted": false }]
            }
        }
        , { $unwind: "$offer_Avail" }
        , {
            $lookup: {
                from: "brands",
                localField: "offer_Avail.offer_id",
                foreignField: "offer._id",
                as: "brand"
            }
        }
//         { $match : { "$$offer_Avail.offer_id" : "$result.offer._id"}}
        , { $unwind: "$brand" }
        , { $unwind: "$brand.offer" }
        , { $match :
                { $and : [
                        { $expr:{$gt:["$offer_Avail.offer_id", "$offer._id"]}},
                        start_date,
                        end_date,
                        brand_id
                    ]}
        }
        , { $project: { "first_name" : 1, "email" : 1, "phone" : 1, "offer_Avail": 1, "brand.offer": 1, "brand._id": 1, "brand.name": 1 } }

    ], callback)
}

module.exports.getTodayReferRegister = function (callback) {
    Customer.aggregate([
        {
            $lookup:{
                from: "customers",
                localField : "refered.customer_id",
                foreignField : "_id",
                as : "result"
            }
        },
        { $unwind : "$result"},
        { $match :
                {"result.timestamps.created_at" : {$gt : new Date("2020-03-06 00:00:00.000Z")}}

        }
    ], callback);
}
















