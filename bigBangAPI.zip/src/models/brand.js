import mongoose from 'mongoose';
require('mongoose-type-url');
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import moment from 'moment';
const Schema = mongoose.Schema;
import { isEmail } from 'validator';
import { realpathSync } from 'fs';
import { now } from "moment";

let ObjectId = mongoose.Schema.Types.ObjectId;

// Online Store Schema
let onlineStoreSchema = mongoose.Schema({
    couponcode: {
        type: String,
        required: false
    },
    weburl: {
        type: String,
        required: false
    },
    _id: false //if i want to keep id disable

});

// create geolocation Schema
let GeoSchema = mongoose.Schema({
    type: {
        type: String,
        default: 'Point',
        required: true
    },
    coordinates: {
        type: [Number],
        index: '2dsphere',
        required: true
    },
    _id: false //if i want to keep id disable

});
let socialMediaLinkSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    link: {
        type: mongoose.SchemaTypes.Url,
        required: true
    },
    _id: false
});
let dayAndTimingSchema = mongoose.Schema({
    open: {
        type: String,
        required: true
    },
    close: {
        type: String,
        required: true
    },
    _id: false
})
let timingSchema = mongoose.Schema({
    mon: dayAndTimingSchema,
    tue: dayAndTimingSchema,
    wed: dayAndTimingSchema,
    thu: dayAndTimingSchema,
    fri: dayAndTimingSchema,
    sat: dayAndTimingSchema,
    sun: dayAndTimingSchema,
    _id: false

})
// let locationSchema = mongoose.Schema({
//     address: {
//         type: String,
//         required: true
//     },
//     area_id: {
//         type: ObjectId,
//         required: true
//     },
//     timings: timingSchema,
//     geometry: GeoSchema,

//     timestamps: TIME_STAMPES,
//     status: FLAGS
// })
let hyperSchema = mongoose.Schema({
    _id: false,
    is_hyper: {
        type: Boolean,
        default: false
    },
    start_datetime: {
        type: Date,
        default: null
    },
    expair_datetime: {
        type: Date,
        default: null,
    },
    amount: {
        type: Number,
        default: 0
    },
    save_amount: {
        type: Number,
        default: 0,
    },
    number_of_unit: {
        type: Number,
        default: 0
    }
})

let bagaSchema = mongoose.Schema({
    _id: false,
    is_baga: {
        type: Boolean,
        default: false
    },
    amount: {
        type: Number,
        default: 0
    },
    save_amount: {
        type: Number,
        default: 0,
    }
})
let flat_discountSchema = mongoose.Schema({
    _id: false,
    is_flat_discount: {
        type: Boolean,
        default: false
    },
    actual_amount: {
        type: Number,
        default: 0
    },
    discounted_amount: {
        type: Number,
        default: 0
    },
    discounted_percent: {
        type: Number,
        default: 0
    }
})
let offerSchema = mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    sub_title: {
        type: String,
        required: true
    },
    offer_description: {
        type: String,
        required: true
    },
    image: {
        type: String,
        required: true
    },
    is_deliverable: {
        type: Boolean,
        default: false
    },
    in_store : {
      type : Boolean,
      default : true
    },
    city_id: {
        type: ObjectId,
        required: true
    },
    country_id: {
        type: ObjectId,
        required: true
    },
    address_id: [{
        type: ObjectId,
        required: true
    }],
    per_day_number_of_avails: {
        type: Number,
        default: 1
    },
    per_app_number_of_avails: {
        type: Number,
        default: 3
    },
    views: {
        type: Number,
        default: Math.floor(Math.random() * 10) + 80
    },
    terms_and_condition: {
        type: String,
        required: true
    },
    days: [{
        type: String,
        default: null,
        required: true
    }],

    tags: [{
        type: String,
        required: true
    }],
    timestamps: TIME_STAMPES,
    status: FLAGS,
    // _id : false if i want to keep id disable
    hyper: hyperSchema,
    baga: bagaSchema,
    flat_discount: flat_discountSchema,
    online_store: onlineStoreSchema,
    is_premium: {
        type: Boolean,
        default: true
    },
    is_other: {
        type: Boolean,
        default: false
    },
    offer_start_date: {
        type: Date,
        required: Date.now()
    },
    offer_end_date: {
        type: Date,
        required: Date.now()
    },
    old_id : {
        type : String,
        default : ""
    },
    sort_order : {
        type : Number,
        default: 0
    },

})
let brandSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    banner: {
        type: String,
        required: false
    },
    icon: {
        type: String,
        required: false
    },
    menuImages: [{
        type: String,
        required: false
    }],
    is_show_at_package_screen: {
        type: Boolean,
        default: false
    },
    // location: [locationSchema],
    offer: [offerSchema],
    socialMediaLinks: [socialMediaLinkSchema],
    categories: {
        parent: [{
            type: ObjectId,
            required: false
        }],
        child: [{
            type: ObjectId,
            required: false
        }]
    },
    tags: [{
        type: String,
        required: false
    }],
    webUrl: {
        type: mongoose.SchemaTypes.Url,
        required: false
    },

    phone_number: {
        type: String,
        required: false
    },
    description: {
        type: String,
        required: false
    },

    specialties: [{
        speciality_name: {
            type: String,
            // required: true
        },
        speciality_icon: {
            type: String,
            // required: true
        },
    }],
    facilities: [{
        facility_name: {
            type: String,
            // required: true
        },
        facility_icon: {
            type: String,
            // required: true
        },
    }],
    views: {
        type: Number,
        default: Math.floor(Math.random() * 10) + 80
    },
    timestamps: TIME_STAMPES,
    status: FLAGS,
    is_featured : {
        type : Boolean,
        default : false
    },
    sort_order : {
        type : Number,
        default: 0
    },
    old_id : {
        type : Number,
        default : 0
    },
    delivery_code:{
        type : String
    }
});
// brandSchema.index({"tags":"text","name":"text","description":"text","offer.tags":"text","offer.title":"text","offer.offer_description":"text"});
let Brand = module.exports = mongoose.model('brands', brandSchema);
module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    // filter["status.is_deleted"]  = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Brand.find(findFilter, callback);
};

module.exports.getRecord1 = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    // filter["status.is_deleted"]  = false;
    // var findFilter = {};
    // findFilter[find] = {
    //     $in: filter
    // };
    Brand.find(filter, callback);
};

//For creating indexes
// db.getCollection('brands').createIndex({"name":"text","description":"text","tags":"text","offer.title":"text","offer.tags":"text","offer.offer_description":"text"})

//Search by relevance(sort by)
// db.getCollection('brands').find({$text: {$search: "buy one get one free"}}, {score: {$meta: "textScore"}}).sort({score:{$meta:"textScore"}})

//Search by trending for brands(sort by)
// db.getCollection('brands').find({$text: {$search: "buy one get one free"}}, {score: {$meta: "textScore"}}).sort({'views': -1})

//Search by alphabetic order for brands(sort by)
// db.getCollection('brands').find({$text: {$search: "buy one get one free"}}, {score: {$meta: "textScore"}}).sort({'name': 1})

//Search by nearby order for brands(sort by)
//work in progress
//
module.exports.globalSearch = function (text, lng, lat, flag, sort = {}, callback) {
    // Brand.dropIndex("tags_text_name_text_description_text_offer.tags_text_offer.title_text_offer.offer_description_text")
    // console.log('here')
    // Brand.index({"tags":"text","name":"text","description":"text","offer.tags":"text","offer.title":"text","offer.offer_description":"text"},callback)
    // return;
    // console.log(lng ,lat,(sort == undefined));

    // console.log((lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort == null || sort == undefined));
    // return;
    // console.log(text)
    if (flag == true) {
        if ((text != undefined || text != null) && (sort != null || sort != undefined)) {
            // console.log('aaya')
            Brand.find({ $text: { $search: text } }, { score: { $meta: "textScore" } }, callback).sort(sort);
        }

        else if ((text == undefined || text == null) && (lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort != null || sort != undefined)) {
            Brand.aggregate([{
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(lat), parseFloat(lng)] },
                    spherical: true,
                    maxDistance: 100000,
                    minDistance: 0,
                    distanceField: "dist"
                }
            }
                // ,{ $unwind: "$location" }
                // ,{ $limit: parseInt(limit) }
            ], callback);
        }
        else if ((text == undefined || text == null) && (sort != null || sort != undefined)) {

            Brand.find({}, callback).sort(sort)
        }
    }
    else {
        if (flag == false) {
            if (text != undefined || text != null && (sort != null || sort != undefined)) {
                Brand.find({
                    "$or": [
                        { name: { $regex: text, $options: 'i' } }
                        , { description: { $regex: text, $options: 'i' } }
                        , { tags: { $regex: text, $options: 'i' } }
                        , { "offer.title": { $regex: text, $options: 'i' } }
                        , { "offer.offer_description": { $regex: text, $options: 'i' } }
                        , { "offer.tags": { $regex: text, $options: 'i' } }

                    ]
                }, callback).sort(sort);
            }
        }

    }

};

module.exports.advanceSearch = function (lng, lat, flag, sort = {}, tags,city_id, callback) {
    // Brand.dropIndex("tags_text_name_text_description_text_offer.tags_text_offer.title_text_offer.offer_description_text")
    // console.log('here')
    // Brand.index({"tags":"text","name":"text","description":"text","offer.tags":"text","offer.title":"text","offer.offer_description":"text"},callback)
    // return;
    // console.log(lng ,lat,(sort == undefined));

    // console.log((lng != undefined || lng != null) && (lat != undefined || lat != null) && (sort == null || sort == undefined));
    // return;
    // if (flag === true) {
    // if ((lng !== undefined || lng != null) && (lat !== undefined || lat != null)) {
    //     Brandlocations.aggregate([{
    //         $geoNear: {
    //             near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
    //             spherical: true,
    //             maxDistance: 1000000,
    //             minDistance: 0,
    //             distanceField: "dist"
    //         }
    //     },
    //         {
    //             $lookup:{
    //                 from: "brands",
    //                 localField : "brand_id",
    //                 foreignField : "_id",
    //                 as : "result"
    //             }
    //
    //         },
    //         {$unwind : "$result"},
    //         {
    //             $match : {
    //                 "result.tags" : { "$in" : tags }
    //             }
    //         }
    //     ], callback)
    //        // Brand.aggregate([{
    //        //     $geoNear: {
    //        //         near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
    //        //         spherical: true,
    //        //         maxDistance: 10000,
    //        //         minDistance: 0,
    //        //         distanceField: "dist"
    //        //     }
    //        // },
    //        //     {
    //        //         $match : [
    //        //             {}
    //        //         ]
    //        //
    //        //
    //        //     }
    //        //     // ,{ $unwind: "$location" }
    //        //     // ,{ $limit: parseInt(limit) }
    //        // ], callback);

    // if ((sort != null || sort !== undefined)) {
    //       Brand.find({ score: { $meta: "textScore" } }, callback).sort(sort);
    //   }
    tags = typeof tags == 'string' ? [tags] : tags;
    // console.log(tags)
    Brand.aggregate([
        {
            $match: { $and: [
                { "tags": { $in: tags } },
                    {"offer.city_id" : mongoose.Types.ObjectId(city_id)}
                ] }
        }
    ], callback)
    // if ((sort.name !== null)) {
    //    Brand.find({"tags" : {$in : tags}  },callback).sort(sort);
    // }

    // else {
    //     if (flag == false) {
    //         if ((sort != null || sort != undefined)) {
    //             Brand.find({
    //                 "$or": [
    //                     { name: { $regex: text, $options: 'i' } }
    //                     , { description: { $regex: text, $options: 'i' } }
    //                     , { tags: { $regex: text, $options: 'i' } }
    //                     , { "offer.title": { $regex: text, $options: 'i' } }
    //                     , { "offer.offer_description": { $regex: text, $options: 'i' } }
    //                     , { "offer.tags": { $regex: text, $options: 'i' } }
    //
    //                 ]
    //             }, callback).sort(sort);
    //         }
    //     }
    //
    // }

};


// db.getCollection('categorys').aggregate(
//     [{ $unwind: "$subCategory" },
//     {
//         "$match": {
//             $or: [{ "subCategory._id": ObjectId("5c416a92fa86f92ed450206e") }, { "subCategory._id": ObjectId("5c416a92fa86f92ed450206d")},{ _id: ObjectId("5c416904daa8c00ac44b9884") }]
//         }
//     }
//     ]
// );

// db.getCollection('categorys').aggregate(
//     [ { $match : { _id : ObjectId("5c416904daa8c00ac44b9884") } } ]
//    );

module.exports.getRelatedOffers = function (find, filter, findtag, tags, key, keyvalue, find1, city, callback) {


    if (!filter) {
        filter = {};
    }
    // filter["status.is_deleted"] = false;
    // find = "categories.parent";
    // filter = 'cat_ids';

    // findtag = "offer.tags";
    // tag = "tags";

    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    var findTags = {};
    findTags[findtag] = {
        $regex: tags, $options: 'i'
    };
    var findcity = {};
    findcity[find1] = city;
    var exculde = {};
    exculde[key] = {
        $ne: keyvalue
    };
    var statusFilter = {};
    statusFilter["status.is_deleted"] = false;
    statusFilter["offer.status.is_deleted"] = false;
    // console.log(statusFilter)
    Brand.aggregate([
        { $unwind: "$offer" },
        {
            "$match": {
                "$and": [
                    findFilter, findTags, findcity, exculde, statusFilter
                ]
            },
        },
        { $project: { offer: 1, _id: 0 } },
        { $group: { _id: "$_id", offer: { $push: "$offer" } } }
    ], callback)
    // db.getCollection('brands').aggregate( [
    //     { $unwind : "$offer" },
    //      { "$match": {
    //             "$and": [
    //             {"categories.parent":{"$in":[
    //             ObjectId("5c4973609ed6b22638d5271a"),
    //             ObjectId("5c4973279ed6b22638d52714")]}},
    //             { "offer.tags": { $regex:"pulao", $options: 'i' } }
    //             ]
    //         }}
    //     ] ,callback)

    // Brand.find({
    //     $and: [findFilter,findTags]
    // }, callback)
    // // Brand.find({
    // //     $and: [
    // //         { "categories.parent": { "$in": cat_id } }
    // //         , { "offer.tags": { $regex: offer_tags, $options: 'i' } }
    // //     ]
    // // }, callback)
}

// module.exports.getNearByLocation = function (lng, lat, maxDistance, minDistance, limit, callback) {
//     // console.log(limit);
//     // return;
//     Brand.aggregate([{
//         $geoNear: {
//             near: { type: 'Point', coordinates: [parseFloat(lng), parseFloat(lat)] },
//             spherical: true,
//             maxDistance: parseFloat(maxDistance),
//             minDistance: parseFloat(minDistance),
//             distanceField: "dist"
//         }
//     }, { $unwind: "$location" },
//     { $limit: parseInt(limit) }], callback);



//     //DataBase Query

//     //  db.getCollection('brands').aggregate([{
//     //     $geoNear: {
//     //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
//     //          spherical: true,
//     //          maxDistance: 300,
//     //          minDistance:5,
//     //          distanceField: "dist"
//     //       }
//     //   },{ $unwind: "$location" },{ $limit : 10 }])


//     // db.getCollection('brands').aggregate([{
//     //     $geoNear: {
//     //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
//     //          spherical: true,
//     //          maxDistance: 200,
//     //          distanceField: "dist.calculated",
//     //          includeLocs : "coordinates"
//     //       }},
//     //       { "$addFields": {
//     //       "location": {
//     //         "$filter": {
//     //           "input": "$location",
//     //           "as": "location",
//     //           "cond": { "$eq": [ "$$location.geometry.coordinates", "$coordinates" ] }
//     //         }
//     //       }
//     //     }},{ $unwind: "$location" }
//     //   ])

//     //DataBase Query

//     // db.getCollection('brands').aggregate([{
//     //     $geoNear: {
//     //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
//     //          spherical: true,
//     //          maxDistance: 7 * 1609.34,
//     //          distanceMultiplier: 0.000621371,
//     //          distanceField: "dist.calculated",
//     //          includeLocs : "coordinates"
//     //       }},
//     // { "$unwind": "$location" },
//     // { "$match": {
//     //   "location.geometry": {
//     //     "$geoWithin": {
//     //       "$centerSphere":[[24.860240, 67.064127], 7 / 3963.2]
//     //         }
//     //       }
//     //     }}


//     // db.getCollection('brands').aggregate([{
//     //     $geoNear: {
//     //         near: { type: 'Point', coordinates: [24.860240, 67.064127]},
//     //          spherical: true,
//     //          maxDistance: 200,
//     // //          distanceMultiplier: 0.000621371,
//     //          distanceField: "dist.calculated",
//     //          includeLocs : "coordinates"
//     //       }},
//     //   { "$unwind": "$location"  },
//     //   { "$match": {
//     //     "location.geometry": {
//     //       "$geoWithin": {
//     //         "$centerSphere": [
//     //           [24.860240, 67.064127], 7 / 3963.2
//     //         ]
//     //       }
//     //     }
//     //   }
//     //   }
//     //   ])
// };
// module.exports.get = function (filter, callback) {
//     if (!filter) {
//         filter = {};
//     }
//     filter["status.is_deleted"] = false;
//     Brand.find(filter).lean().exec(callback);
// };
module.exports.getPopularOffer = function (limit, city_id, callback) {
    //     if (!filter) {
    //         filter = {};
    //     }
    //     filter["status.is_deleted"] = false;
    var statusFilter = {};
    statusFilter["status.is_deleted"] = false;
    statusFilter["offer.status.is_deleted"] = false;

    Brand.aggregate([
        { $unwind: "$offer" },
        {
            $match: {
                $and: [
                    { 'offer.city_id': mongoose.Types.ObjectId(city_id) },
                    statusFilter
                ]
            }
        },
        { $limit: parseInt(limit) },
        { $project: { "offer": 1, _id: 0 } },
        { $group: { _id: "$_id", offer: { $push: "$offer" } } },

    ],
        callback);
};

module.exports.getLatestOffers = function (latestoffers, city_id, callback) {
    var statusFilter = {};
    statusFilter["status.is_deleted"] = false;
    statusFilter["offer.status.is_deleted"] = false;
    let date = new Date();
    date.setDate(date.getDate() - latestoffers);
    statusFilter['offer.timestamps.created_at'] = { $gte: date, $lt: new Date() };
    Brand.aggregate([
        { $unwind: "$offer" },
        {
            $match: {
                $and: [
                    { 'offer.city_id': mongoose.Types.ObjectId(city_id) },
                    statusFilter
                ]
            }
        },
        { $project: { "offer": 1, _id: 0 } },
        { $group: { _id: "$_id", offer: { $push: "$offer" } } },

    ],
        callback);
};
module.exports.add = function (brand, callback) {
    Brand.create(brand, callback);
};
module.exports.add1 = function (brand, callback) {
    // console.log('in')
    Brand.create(brand, callback);
};
module.exports.getBrandwithoutoffers = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    // Brand.find(filter,{offer:0},callback);
    Brand.find(filter, { offer: 0 }).lean().exec(callback);

};
module.exports.getoffer = function (offer_id, callback) {
    Brand.aggregate([
        { $unwind: "$offer" },
        {
            $match: {
                "$and":
                    [
                        { "offer._id": { "$in": offer_id } }
                    ]
            }
        }], callback)
}

module.exports.getSpecificOffer = function (brand_location_id, callback) {
    Brand.aggregate([
        { $unwind: "$offer" },
        { $match: { 'offer.address_id': brand_location_id } }


    ], callback)
}

module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Brand.find(filter).lean().exec(callback);
};
module.exports.add = function (brand, callback) {
    Brand.create(brand, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Brand.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, brand, callback) {
    brand.$set = {
        "timestamps.updated_at": new Date(),
    }
    Brand.updateOne({ _id: id }, brand, callback);
};
module.exports.updateBrandViews = function (id, callback) {
    // brand.$set = {
    //     "timestamps.updated_at": new Date(),
    // }
    Brand.updateOne({ _id: id }, { $inc: { views: 1 } }, callback);
};
module.exports.updateOfferViews = function (id, callback) {
    // Brand.updateOne({ 'offer._id': '5c384ff61b8b971fc409cc46' }, { $inc: { "offer.$.views": 1 } }, callback);
    Brand.updateOne({ 'offer._id': id }, { $inc: { "offer.$.views": 1 } }, callback);

};
// module.exports.remove_offer = function (id, callback) {
//     var findOne = { "offer._id": id };
//     var query = { $pull: { 'offer': { _id: id } } };
//     var a = { safe: true, upsert: true }
//     Brand.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
// };
// module.exports.update_location = function (id, location_id,location_data, callback) {
//     Brand.updateOne(
//         { _id: mongoose.Types.ObjectId(id), "location._id": mongoose.Types.ObjectId(location_id) },
//         {
//             $set: location_data
//             // {
//             //     "favouriteOffer.$.status.is_deleted": true,
//             //     "favouriteOffer.$.status.is_activated": false,
//             //     "favouriteOffer.$.timestamps.updated_at": new Date()
//             // }
//         }
//         , callback)
// };
module.exports.remove_location = function (id, callback) {
    var findOne = { "location._id": id };
    var query = { $pull: { 'location': { _id: id } } };
    var a = { safe: true, upsert: true }
    Brand.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
};

// module.exports.remove_location = function (id, location_id, callback) {
//     Brand.updateOne(
//         { _id: mongoose.Types.ObjectId(id), "location._id": mongoose.Types.ObjectId(location_id) },
//         {
//             $set: {
//                 "location.$.status.is_deleted": true,
//                 "location.$.status.is_activated": false,
//                 "location.$.timestamps.updated_at": new Date()
//             }
//         }
//         , callback)
//     // Customer.updateOne({ _id: id }, remove, callback);
// };

module.exports.verifyExistance = function (data, callback) {
    Brand.aggregate([
        // { $unwind: "$favouriteOffer" },
        {
            $match: {
                "$and": [{
                    $and: data
                }]
            }
        }], callback)
}
module.exports.updateOffer = function (id, offer_id, offer, callback) {
    // console.log( { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
    // {$set:offer})
    // return;
    Brand.updateOne(
        { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
        { $set: offer }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};
module.exports.removeOffer = function (id, offer_id, callback) {
    Brand.updateOne(
        { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
        {
            $set: {
                "offer.$.status.is_deleted": true,
                "offer.$.status.is_activated": false,
                "offer.$.timestamps.updated_at": new Date()
            }
        }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.removeOfferByBrand = function (id, callback) {
    Brand.updateOne(
        { _id: mongoose.Types.ObjectId(id) },
        {
            $set: {
                "offer.$[].status.is_deleted": true,
                "offer.$[].status.is_activated": false,
                "offer.$[].timestamps.updated_at": new Date()
            }
        },
        { multi: true }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.remove_speciality = function (id, callback) {
    var findOne = { "specialties._id": id };
    var query = { $pull: { 'specialties': { _id: id } } }
    var a = { safe: true, upsert: true }
    Brand.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
};
module.exports.remove_facility = function (id, callback) {
    var findOne = { "facilities._id": id };
    var query = { $pull: { 'facilities': { _id: id } } }
    var a = { safe: true, upsert: true }
    Brand.updateOne(findOne, query, callback);//EVERYTHING GOT REMOVED});
};
module.exports.get_offer_by_brand = function (brand_id, city_id, callback) {
    Brand.find(
        {
            _id: mongoose.Types.ObjectId(brand_id),
            'offer.city_id': city_id,
            "offer.status.is_deleted": false,
            "offer.status.is_activated": true
        },
        { 'offer': true }, callback)
}

module.exports.getIsDeliverableOffer = function (is_deliverable, callback) {
    var deliverable = (is_deliverable === 'true');
    Brand.aggregate([
        { "$unwind": "$offer" },
        {
            $match: {
                $and: [
                    { "status.is_deleted": false },
                    { "offer.status.is_deleted": false },
                    { "offer.status.is_deleted": false },
                    { "offer.is_deliverable": deliverable }]
            }
        }
    ], callback)

}
module.exports.getOfferAvailCount = function (customer_id, brand_id, callback) {

    let today = new Date(moment().format('YYYY-MM-DD'))
    let tomorrow = new Date(moment(today, "DD-MM-YYYY").add(1, 'days'))
    Brand.aggregate([
        {
            $lookup: {
                from: "customers",
                localField: "offer._id",
                foreignField: "offer_Avail.offer_id",
                as: "result"
            }
        },
        { $unwind: "$offer" },
        { $unwind: "$result" },
        { $unwind: "$result.offer_Avail" },
        {
            $match: {
                $and: [
                    { "status.is_deleted": false },
                    { "offer.status.is_deleted": false },
                    { "_id": mongoose.Types.ObjectId(brand_id) },//Brand ID
                    { "result._id": mongoose.Types.ObjectId(customer_id) }, // Customer ID
                    { $expr: { $eq: ["$result.offer_Avail.offer_id", "$offer._id"] } },
                    { "result.offer_Avail.avail_on": { $gte: today, $lt: tomorrow } }
                ]
            }
        },
        {
            $group: {
                _id: "$offer._id",
                count: { $sum: 1 }
            }
        }
    ], callback)



}

module.exports.getOrderByBrand = function (data, callback) {
    Brand.aggregate([
        {
            $lookup: {
                from: "orders",
                localField: "offer._id",
                foreignField: "offer.offer_id",
                as: "result"
            }
        },
        { $unwind: "$offer" },
        { $unwind: "$result" },
        { $unwind: "$result.offer" },
        {
            $match: {
                $and: [
                    { "_id": mongoose.Types.ObjectId(data.brand_id) }, //Brand ID
                    { $expr: { $eq: ["$result.offer.offer_id", "$offer._id"] } }
                ]
            }
        },

        {
            $group: {
                _id: "$result._id",
                "order_details" :  { $push:"$result"},
                "offers": { $push: "$result.offer" }
            }
        }
        // { "$limit": parseInt(data.offset) + parseInt(data.limit) },
        // { "$skip": parseInt(data.offset) }
    ], callback)
};

module.exports.getPackageScreenBrand = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    filter["is_show_at_package_screen"] = true;
    Brand.find(filter).lean().exec(callback);
}

module.exports.getCurrentOffer = (brand_id, callback) => {
    Brand.aggregate([
        { $match: { _id: mongoose.Types.ObjectId(brand_id) } },
        { $unwind: "$offer" },
        { $sort: { 'offer._id': -1 } },
        { $limit: 1 },
        { $project: { 'offer._id': 1 } }
    ], callback)
}

module.exports.getBrandsTags = (category_id, callback) => {
    Brand.aggregate([
        { $match : {"categories.parent" : mongoose.Types.ObjectId(category_id)}},
        { $unwind: "$tags" },
        { $project: {"tags" : 1, _id: 0}}
    ], callback)
}

module.exports.getBrandByOldId = function (brand_id, callback) {
    Brand.find({ old_id : brand_id}).lean().exec(callback);
}

module.exports.updateWithCsv = function (id, brand, callback) {
    brand.$set = {
        "timestamps.updated_at": new Date(),
    }
    Brand.updateOne({ _id: id }, brand, callback);
};

module.exports.getBrandByOldOfferId = function (id, callback) {
    Brand.find({"offer.old_id": id}, callback);
};

module.exports.updateCsv = function (id, brand, callback) {
    brand.$set = {
        "timestamps.updated_at": new Date(),
    }
    Brand.updateOne({ _id: id }, brand, callback);
};

module.exports.getOfferByOldId = function (offer_old_id, callback) {
    Brand.aggregate([
        { $unwind : "$offer" },
        { $match : { "offer.old_id" : offer_old_id} }
    ], callback)
};

module.exports.getAllBrand = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Brand.find(filter).lean().exec(callback);
};
module.exports.setViews = function (id,views, callback) {
    Brand.update(mongoose.Types.ObjectId(id),{"$set" : {"views" : views}},callback)
};

module.exports.updateOfferCsv = function (id, offer_id, offer, callback) {
    // console.log( { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
    // {$set:offer})
    // return;
    Brand.updateOne(
        { old_id: id, "offer.old_id": offer_id },
        { $set: offer }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.getBrandLocations = function (callback) {
    Brand.aggregate([
        {
            $lookup: {
                from: "brandlocations",
                localField: "_id",
                foreignField: "brand_id",
                as: "locations"
            }
        }
        ,{
            $project : {_id: 1,"offer._id": 1, "locations._id": 1}
        }
    ], callback)
};

module.exports.updateOfferLocationCsv = function (id, offer_id, locations, callback) {
    // console.log( { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
    // {$set:offer})
    // return;
    Brand.updateOne(
        { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
        { $push: locations }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.updateBrandCommon = function (old_id, data, callback) {
    // console.log( { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
    // {$set:offer})
    // return;
    Brand.updateOne(
        { old_id: old_id },
        { $push: data }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.updateBrandCommonSet = function (old_id, data, callback) {
    // console.log( { _id: mongoose.Types.ObjectId(id), "offer._id": mongoose.Types.ObjectId(offer_id) },
    // {$set:offer})
    // return;
    Brand.updateOne(
        { old_id: old_id },
        { $set: data }
        , callback)
    // Customer.updateOne({ _id: id }, remove, callback);
};

module.exports.getOffersByOldId = function (old_id, callback){
    Brand.aggregate([
        {$unwind : "$offer"},
        { $match : {
            "offer.old_id" : old_id
            }
        },
        {
            $project : { "offer" : 1 }
            }
        ], callback)
}

module.exports.totalOffersCount = function (callback) {
    Brand.aggregate([
        { $unwind: "$offer" },
        { $match : {
                "status.is_deleted" : false,
                "offer.status.is_deleted" : false
            }
        }
        , { $count: "total_offers_count" }
    ], callback)
};

module.exports.brandCount = function (callback) {
    Brand.find({"status.is_deleted" : false}).countDocuments().lean().exec(callback);
}

module.exports.getofferstats = function (offer_id, callback) {
    Brand.aggregate([
        { $unwind: "$offer" },
        {
            $match: {
                "$and":
                    [
                        { "offer._id":  offer_id  }
                    ]
            }
        }], callback)
}

module.exports.getAllOffers = function (callback) {
    Brand.aggregate([
        { $unwind: "$offer" }
    ], callback)
}

module.exports.getBrandByMonthYear = function (year, month, callback) {
    Brand.find({
        "$expr": {
            "$and": [
                {"$eq": [{ "$year": "$timestamps.created_at" }, parseInt(year)]},
                {"$eq": [{ "$month": "$timestamps.created_at" }, parseInt(month)]}
            ]
        }
    }).lean().exec(callback);
}

module.exports.getHyperOffers = function (city_id, callback) {
    Brand.aggregate([
        {$unwind : "$offer"},
        {
            $match : {
                $and : [
                    { "status.is_deleted" : false },
                    { "offer.status.is_deleted" : false},
                    { "offer.hyper.is_hyper"  : true},
                    { "offer.city_id" : mongoose.Types.ObjectId(city_id) },
                    { "offer.hyper.expair_datetime" : {$gt : new Date()}}
                ]}
        },
        { $group : {
                _id : "$_id",
                categories : {$first : "$categories"},
                timestamps : {$first : "$timestamps"},
                status : {$first : "$status"},
                menuImages : {$first : "$menuImages"},
                is_show_at_package_screen : {$first : "$is_show_at_package_screen"},
                tags : {$first : "$tags"},
                views : {$first : "$views"},
                is_featured : {$first : "$is_featured"},
                sort_order : {$first : "$sort_order"},
                old_id : {$first : "$old_id"},
                name : {$first : "$name"},
                banner : {$first : "$banner"},
                icon : {$first : "$icon"},
                socialMediaLinks : {$first : "$socialMediaLinks"},
                phone_number : {$first : "$phone_number"},
                description : {$first : "$description"},
                specialties : {$first : "$specialties"},
                facilities : {$first : "$facilities"},
                webUrl : {$first : "$webUrl"},
                offer : { "$push": "$offer" }
            }}
    ], callback)
}

module.exports.getBrandlimitedData = function (city_id, callback) {
    Brand.aggregate([
        { $unwind : "$offer" },
        { $match : { "offer.city_id" : mongoose.Types.ObjectId(city_id)}},
        { $group : {
                _id : "$_id",
                name : {$first : "$name"},
                icon : {$first : "$icon"}
            },

        }
    ], callback)
}

module.exports.FeaturedBrands = function (city_id, callback) {
    Brand.aggregate([
        { $match : {
            $and : [
                { "status.is_deleted" : false },
                { "offer.city_id" : mongoose.Types.ObjectId(city_id) },
                { "is_featured" : true }
            ]
            }},
        { $project : { _id : 1, "name" : 1, "views": 1, "description": 1, "icon":1, "banner": 1, "tags" : 1} }
    ], callback);
}
