import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;
let activationPattranSchema = mongoose.Schema({
    prefix: {
        type: String,
        required: true
    },
    type: {
        type: String,
        required: true
    },
    serial: {
        type: String,
        required: true
    },
    code: {
        type: String,
        required: true
    },
    _id: false
});
let activationCodeSchema = mongoose.Schema({
    package_id: {
        type: ObjectId,
        required: false
    },
    code : {
        type : Number,
        default : 0,
        required : true
    },
    prefix : {
        type : Number,
        default : 0,
        required : false
    },
    type : {
        type : String,
        default : null,
        required : false
    },
    is_used: {
        type: Boolean,
        default: false
    },
    verified: {
        type: Boolean,
        default: false
    },
    validity: {
        type: String,
        required: true
    },
    // activation_code: activationPattranSchema,
    timestamps: TIME_STAMPES,
    status: FLAGS,
    old_id : {
        type : Number,
        default : 0
    }
});

let activationCodeExtendSchema = mongoose.Schema({
    activation_code : {
        type : String,
        required : true
    },

    previousEndDate : {
        type: Date,
        required : true
    },
    currentEndDate : {
        type: Date,
        required : true
    },
    comments : {
      type : String,
      required : true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
})

let Activationcode = module.exports = mongoose.model('activationcodes', activationCodeSchema);
// let ActivationCodeExtend = module.exports = mongoose.model('activationdateextends', activationCodeExtendSchema);

module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Activationcode.find(findFilter, callback);
};
// module.exports.get = function (filter, callback) {
//     if (!filter) {
//         filter = {};
//     }
//     filter["status.is_deleted"] = false;
//     Activationcode.find(filter).lean().exec(callback);
// };
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Activationcode.find(filter).lean().exec(callback);
};

module.exports.getMax = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Activationcode.findOne(filter).sort({ "activation_code.serial": -1 }).exec(callback);
};

module.exports.add = function (code, callback) {
    Activationcode.create(code, callback);
};

module.exports.remove = function (id, code, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Activationcode.updateOne({ _id: id }, code, callback);
};

module.exports.update = function (id, activation, callback) {
    activation.$set = {
        "timestamps.updated_at": new Date(),
    }
    Activationcode.updateOne({ "_id": id }, activation, callback);
};

// module.exports.addExtendDate = function (code, callback) {
//     ActivationCodeExtend.create(code, callback);
// };

module.exports.addMigrate = function (code, callback) {
    Activationcode.create(code, callback);
};

module.exports.getCodeByOldId = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Activationcode.find(filter).lean().exec(callback);
};

module.exports.updateCodeCsv = function (code_id, package_id, callback) {
    Activationcode.updateOne(
        { _id: code_id },
        { $set:
                {
                    package_id : mongoose.Types.ObjectId(package_id)
                }
    }, callback);
};

module.exports.getMaxPrefix = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Activationcode.findOne(filter).sort({ "prefix": -1 }).exec(callback);
};
