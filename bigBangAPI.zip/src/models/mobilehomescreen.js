import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;

let screenSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
    // _id : false if i want to keep id disable
});
let Mobilehomescreen = module.exports = mongoose.model('screens', screenSchema);

module.exports.getRecord = function (find, filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    var findFilter = {};
    findFilter[find] = {
        $in: filter
    };
    Mobilehomescreen.find(findFilter, callback);
};
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    Mobilehomescreen.find(filter).lean().exec(callback);
};
module.exports.add = function (mobilehomescreen, callback) {
    Mobilehomescreen.create(mobilehomescreen, callback);
};
module.exports.update = function (id, mobilehomescreen, callback) {
    mobilehomescreen.$set = {
        "timestamps.updated_at": new Date(),
    }
    Mobilehomescreen.updateOne({ _id: id }, mobilehomescreen, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    Mobilehomescreen.updateOne({ _id: id }, remove, callback);
};

