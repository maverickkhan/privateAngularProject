import mongoose from 'mongoose';
import { TIME_STAMPES, FLAGS } from '../utilites/constants';
import { isEmail } from 'validator';
let ObjectId = mongoose.Schema.Types.ObjectId;
let bannerCategorySchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    timestamps: TIME_STAMPES,
    status: FLAGS
});
let BannerCategory = module.exports = mongoose.model('bannerCategorys', bannerCategorySchema);
module.exports.get = function (filter, callback) {
    if (!filter) {
        filter = {};
    }
    filter["status.is_deleted"] = false;
    BannerCategory.find(filter).lean().exec(callback);
};
module.exports.add = function (bannerCategory, callback) {
    BannerCategory.create(bannerCategory, callback);
};
module.exports.remove = function (id, callback) {
    let remove = {
        'status.is_deleted': true,
        'status.is_activated': false,
        'timestamps.updated_at': new Date()
    };
    BannerCategory.updateOne({ _id: id }, remove, callback);
};
module.exports.update = function (id, bannerCategory, callback) {
    let update = {
        'name': bannerCategory.name,
        'timestamps.updated_at': new Date()
    };
    BannerCategory.updateOne({ _id: id }, update, callback);
};
