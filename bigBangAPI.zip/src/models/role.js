import mongoose from 'mongoose';
import { searchQuery, getCountOfRecords } from '../utilites/query-module';
import { TIME_STAMPES, FLAGS, SYSTEM_ROLES } from '../utilites/constants';
import Country from "./country";
let CRUD = {
    module_name: {type: String,required: true},
    c: { type: Boolean, default: false },
    r: { type: Boolean, default: false },
    u: { type: Boolean, default: false },
    d: { type: Boolean, default: false },
}
let roleSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    permissions: [CRUD],
    status: FLAGS,
    timestamps: TIME_STAMPES
});

let Role = module.exports = mongoose.model('Role', roleSchema);
function getQueryParams(queryParams) {

    let findParams = {
        'status.is_deleted': false,
        'name': { $nin: SYSTEM_ROLES}
    };
    return findParams;
}
module.exports.addRole = function (role, callback) {
    Role.create(role, callback);
};
module.exports.getSpecificRole = function (param, callback) {
    Role.find(param, callback);
}
module.exports.getSpecificRoleByName = function (id,param, callback) {
    // Role.find(param, callback);
    // console.log(param,id); return;
    Role.aggregate([
        { $unwind: "$permissions" },
        { $match : {
                $and:[
                    {'permissions.module_name' : param },
                    {'_id' :id }
                ]
            }
        }


    ],callback)

}
module.exports.getRoles = function (queryParams, callback){

    let sortObj = {};
    if (queryParams.sort != '' && queryParams.sortby != '') {
        sortObj[queryParams.sort] = queryParams.sortby;
    }
    searchQuery(Role, callback, queryParams.limit, queryParams.page, sortObj, getQueryParams(queryParams));
}
module.exports.getAll  = function (callback){
    Role.find().exec(callback);
}
module.exports.countRoles = function (queryParams, callback) {
    getCountOfRecords(Role, callback, getQueryParams());
}
module.exports.updateRole = function (role, callback) {

    let role_id = role._id;

    let update = {
        'name' : role.name,
        'permissions' : role.permissions,
        'timestamps.updated_at': new Date()
    };
    Role.update({ _id: role_id }, update, callback);
}
module.exports.deleteRole = function (roleid, callback) {

    let updateDeleteFlag = {
        'status.is_deleted': true
    };
    Role.updateOne({ _id: roleid }, updateDeleteFlag, callback);
}

module.exports.updateall = function (id,data,callback) {
    // // var bulk =  Role.collection.initializeUnorderedBulkOp();
    // data.forEach(function (role) {
    //     // console.log(role.permissions);
    //     // bulk.find( { _id: role._id } ).update( { $set: { permissions: role.permissions } } );
    //     var rolebody = {$push : role}
    //     console.log(rolebody)
    //     rolebody.$set = {
    //         // 'permissions' : role.permissions,
    //         'timestamps.updated_at': new Date()
    //     };
    //     Role.updateOne({ _id: role._id },  rolebody , callback );
    //     // Role.update({ _id: role._id }, update, callback);
    //     // Role.find({_id: role._id}).lean().exec(function(err, collection) {})
    // });
    // // bulk.find( { status: "D" } ).update( { $set: { status: "I", points: "0" } } );
    // // bulk.find( { item: null } ).update( { $set: { item: "TBD" } } );
    // console.log(data); return;
    let ext = {}
    for (var key in data){
        ext = data[key]
        // console.log(data[key])
    }
    ext.$set = {
        'timestamps.updated_at': new Date()
    }
    // console.log(ext)

    Role.updateOne({ _id: id }, {$push: {permissions : ext}}, callback);
}
