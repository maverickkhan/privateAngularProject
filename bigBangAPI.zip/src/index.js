const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const express = require('express');
const config = require('./conf');
const http = require('http');
const https = require('https');
const fs = require('fs');
const cors = require('cors');
const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
/* var Raven = require('raven'); */
const Api = require('./api');
//import async from 'async';

// const roles = require("user-groups-roles");

//import { log } from './middlewares/index';


mongoose.connect(config.database['path'], { useNewUrlParser: true });
let port = config.app['port'];
let app = express();
let whitelist = Object.keys(config.whitelist).map(k => config.whitelist[k]);

/* Raven.config('https://ef7e4dfed8a0410da6886ed00b1aaaf4:296725e28813410184bd8d2b78f126d8@sentry.io/194688').install();
app.use(Raven.requestHandler()); */

app.set("port", port);
app.use(bodyParser.json({ limit: config.app['bodyLimit'] }));
app.use(express.urlencoded({extended : false}));
app.use('/uploads', express.static('uploads'));

app.use(cookieParser(config.app['cookie_secret']));


app.use(cors({
    origin: (origin, callback) => {
        console.log(origin);
        let originIsWhitelisted = whitelist.indexOf(origin) !== -1 || typeof origin === "undefined";
        let failureResp = 'You are not authorized to perform this action';
        callback(originIsWhitelisted ? null : failureResp, originIsWhitelisted);
    }
}));
/* app.use('/api', api); */

new Api(app).registerGroup();
app.use(express.static(config.app['file_directory']))

// Certificate
const privateKey = fs.readFileSync('/etc/letsencrypt/live/bigbang.pk/privkey.pem', 'utf8');
const certificate = fs.readFileSync('/etc/letsencrypt/live/bigbang.pk/cert.pem', 'utf8');
const ca = fs.readFileSync('/etc/letsencrypt/live/www.bigbang.pk/chain.pem', 'utf8');

const credentials = {
	key: privateKey,
	cert: certificate,
	ca: ca
};
const httpsServer = https.createServer(credentials, app);

httpsServer.listen(8000, () => {
	console.log('HTTPS Server running on port 8000');
});

http.createServer(app).on('error', function () {
    console.log('Can\'t connect to server.');
})
.listen(port, () => console.log(`Server Started :: ${port}`));

/*
    Roles declaratations
*/
// roles
// roles.createNewRole("admin");
// roles.createNewRole("sub");
// roles.createNewRole("author");
// roles.createNewRole("subscriber");


////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////
// var glob = [];
// var priv= [];
// var promise1 = new Promise((resolve, reject) => {
//
//     setTimeout(() => {
//         Usergroup.get((err, groups) => {
//             // roles
//             console.log(groups);
//             for (var i = 0; i < groups.length; i++) {
//                 roles.createNewRole(groups[i].name);
//                 glob.push(groups[i].name)
//             }
//             console.log(console.log('1'));
//             console.log("Get all privilege");
//             console.log(roles.getAllPrivileges());
//             console.log("Get all Role");
//             console.log(roles.getAllRoles());
//             console.log("Get all Role Privileges");
//             console.log(roles.getRolePrivileges());
//             resolve(glob);
//         })
//     }, 1000)
// })
// var promise2 = new Promise((resolve, reject) => {
//     var privilegess = Privileges.get((err, privilege) => {
//             for(var i=0; i < privilege.length; i++){
//                 var url = privilege[i].url;
//                 var method = privilege[i].method;
//                 var description = privilege[i].description;
//                 var default_value = privilege[i].default_value;
//                 roles.createNewPrivileges([url, method], description, default_value);
//                 priv[i] = {
//                     url : url,
//                     method : method,
//                     description : description,
//                     default_value : default_value
//                 }
//                 glob.push(priv[i])
//             }
//         console.log(console.log('2'));
//     }, 1000)
// })
// var promise2 = new Promise((resolve, reject) => {
//     var privilegess = Privileges.get((err, privilege) => {
//             for(var i=0; i < privilege.length; i++){
//                 var url = privilege[i].url;
//                 var method = privilege[i].method;
//                 var description = privilege[i].description;
//                 var default_value = privilege[i].default_value;
//                 roles.createNewPrivileges([url, method], description, default_value);
//                 priv[i] = {
//                     url : url,
//                     method : method,
//                     description : description,
//                     default_value : default_value
//                 }
//                 glob.push(priv[i])
//             }
//         console.log(console.log('2'));
//         console.log("Get all privilege");
//         console.log(roles.getAllPrivileges());
//         console.log("Get all Role");
//         console.log(roles.getAllRoles());
//         console.log("Get all Role Privileges");
//         console.log(roles.getRolePrivileges());
//         resolve(priv);
//         // resolve(name);
//     }, 3000)
// })
// var promise3 = new Promise((resolve, reject) => {
//     setTimeout(() => {
//         Usergroup.get((err, groups) => {
//             // roles
//             for(var i=0; i < groups.length; i++){
//                 var name = groups[i].name;
//                 var url;
//                 var method;
//                 var value;
//                 // console.log(groups[i].privilege);
//                 for(var j=0; j < groups[i].privilege.length; j++){
//                     url = groups[i].privilege[j].url;
//                     method = groups[i].privilege[j].method;
//                     value = groups[i].privilege[j].value;
//                     // console.log("Privilege to Admin >>> " + name + " "+ url + " "+ method + " "+ value + " ");
//                     roles.addPrivilegeToRole(name,[url, method],value);
//                     // roles.addPrivilegeToRole("admin",['/city/get','GET'],true);
//
//                 }
//         }
//             // roles.addPrivilegeToRole("sub",['/city/get','GET'],true);
//             console.log(console.log('3'));
//             console.log("Get all privilege");
//             console.log(roles.getAllPrivileges());
//             console.log("Get all Role");
//             console.log(roles.getAllRoles());
//             console.log("Get all Role Privileges");
//             console.log(roles.getRolePrivileges());
//             console.log("================================================================================")
//             resolve(glob);
//         })
//     }, 50000)
// })
//
// var printResult = (results) => {
//     // console.log("Roles = ", results);
//         console.log("Get all privilege");
//         console.log(roles.getAllPrivileges());
//         console.log("Get all Role");
//         console.log(roles.getAllRoles());
//         console.log("Get all Role Privileges");
//         console.log(roles.getRolePrivileges());
// }
//
// Promise.all([promise1,promise2,promise3]).then(printResult);
//////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////

// var usergroups = Usergroup.get((err, groups) => {
//         // roles
//         var glob = []
//         for(var i=0; i < groups.length; i++){
//             roles.createNewRole(groups[i].name);
//         }
//
//         // privileges
//         var privilegess = Privileges.get((err, privilege) => {
//             for(var i=0; i < privilege.length; i++){
//                 var url = privilege[i].url;
//                 var method = privilege[i].method;
//                 var description = privilege[i].description;
//                 var default_value = privilege[i].default_value;
//                 roles.createNewPrivileges([url, method], description, default_value);
//                 // console.log('==================')
//                 // console.log(roles.getAllPrivileges());
//             }
//
//             // Assign Role to users
//             for(var i=0; i < groups.length; i++){
//                 var name = groups[i].name;
//                 var url;
//                 var method;
//                 var value;
//                 // console.log(groups[i].privilege);
//                 for(var j=0; j < groups[i].privilege.length; j++){
//                     url = groups[i].privilege[j].url;
//                     method = groups[i].privilege[j].method;
//                     value = groups[i].privilege[j].value;
//                     roles.addPrivilegeToRole(name,[url, method],value);
//                 }
//             }
//             console.log("Get all privilege");
//             console.log(roles.getAllPrivileges());
//             console.log("Get all Role");
//             console.log(roles.getAllRoles());
//             console.log("Get all Role Privileges");
//             console.log(roles.getRolePrivileges("admin"));
//         });
//
//
//         // console.log("Get all privilege");
//         // console.log(roles.getAllPrivileges());
//         // console.log("Get all Role");
//         // console.log(roles.getAllRoles());
//         // console.log("Get all Role Privileges");
//         // console.log(roles.getRolePrivileges());
//
//     });


// var usergroups = Usergroup.get((err, groups) => {
//     // roles
//     for(var i=0; i < groups.length; i++){
//         roles.createNewRole(groups[i].name);
//     }
//
//     // privileges
//     var privilegess = Privileges.get((err, privilege) => {
//         for(var i=0; i < privilege.length; i++){
//             var url = privilege[i].url;
//             var method = privilege[i].method;
//             var description = privilege[i].description;
//             var default_value = privilege[i].default_value;
//             roles.createNewPrivileges([url, method], description, default_value);
//             // console.log('==================')
//             // console.log(roles.getAllPrivileges());
//         }
//
//         // Assign Role to users
//         for(var i=0; i < groups.length; i++){
//             var name = groups[i].name;
//             var url;
//             var method;
//             var value;
//             // console.log(groups[i].privilege);
//             for(var j=0; j < groups[i].privilege.length; j++){
//                 url = groups[i].privilege[j].url;
//                 method = groups[i].privilege[j].method;
//                 value = groups[i].privilege[j].value;
//                 roles.addPrivilegeToRole(name,[url, method],value);
//             }
//         }
//         console.log("Get all privilege");
//         console.log(roles.getAllPrivileges());
//         console.log("Get all Role");
//         console.log(roles.getAllRoles());
//         console.log("Get all Role Privileges");
//         console.log(roles.getRolePrivileges("admin"));
//     });
//
//
//     // console.log("Get all privilege");
//     // console.log(roles.getAllPrivileges());
//     // console.log("Get all Role");
//     // console.log(roles.getAllRoles());
//     // console.log("Get all Role Privileges");
//     // console.log(roles.getRolePrivileges());
//
// });
// add privileges with url
// privileges
// roles.createNewPrivileges(["/city/get", "GET"], "get article", false);
// roles.createNewPrivileges(["/city/create", "PUT"], "inserts article", false);
// roles.createNewPrivileges(["/city/update", "PUT"], "edits article", false);
// roles.createNewPrivileges(["/city/remove", "DELETE"], "deletes article", false);



// admin all add, edit delete select
// roles.addPrivilegeToRole("admin",["/city/get", "GET"],true);
// roles.addPrivilegeToRole("admin",["/city/create", "PUT"],true);
// roles.addPrivilegeToRole("admin",["/city/update", "PUT"],true);
// roles.addPrivilegeToRole("admin",["/city/remove", "DELETE"],true);


